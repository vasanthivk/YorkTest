<?php

class ar{
    
    static $data=array();
    static $original=array();
    static $table='';
    static $ref='';
    static $updates=array();
    
    
    static function newRecord($table){
    	
    }
    
    static function map($inData){
    	self::$data=$inData;
    	self::$original=$inData;
    }
    
    static function find($table='',$ref='',$searchField='ref'){
    	self::$data=array();
    	self::$updates=array();
    	self::$original=array();
        self::$table=$table;
        self::$ref=$ref;
        if(strpos($ref,'%')===false){
        	$sql='select * from '.$table.' where '.$searchField.'=:ref limit 1;';	
        }else{
        	$sql='select * from '.$table.' where '.$searchField.' like :ref limit 1;';	
        }
        
        $parms=array(':ref'=>$ref);
        self::$data=dbpdo::getQuery($sql,$parms);
        self::$original=self::$data;
        return self::$data;
    }
    
    static function get($fieldName='',$original=false){
    	if(sizeOf(self::$data)>0){
	       	if($fieldName==''){
	    		return self::$data;
	    	}else{
	    		return h::sa(self::$data,$fieldName);	
	    	}
    	}else{
    		return '';
    	}
    }
    
    static function set($field,$data){
    	self::$updates[$field]=$data;
    	self::$data[$field]=$data;
    }
    
    static function save(){
    	$currentRef=h::sa(self::$data,'ref');
    	if($currentRef!=''){
    		return dbpdo::dbUpdate(self::$table,$currentRef,self::$updates);
    	}else{
    		return dbpdo::dbInsert(self::$table,self::$updates);
    	}
    }
    
    static function debug(){
    	$ret='';
    	foreach(self::$data as $key=>$data){
    		$ret.='<b>'.$key.'</b> '.$data.' <span style="color:red;">'.h::sa(self::$updates,$key).'</span><br/>';
    	}
    	return $ret;
    }
    
    
    
}

?>