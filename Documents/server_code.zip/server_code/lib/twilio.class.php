<?php


class twilio{
    
    static function sendSMS($to,$body,$from=''){
        // resource url & authentication
        $sid=settings::getSettings('twilio','sid');
        $token=settings::getSettings('twilio','token');
        if($from==''){
            $from=settings::getSettings('twilio','from');
        }
        $uri = 'https://api.twilio.com/2010-04-01/Accounts/' . $sid . '/SMS/Messages';
        $auth = $sid . ':' . $token;
     
        $fields = 
            '&To=' .  urlencode( $to ) . 
            '&From=' . urlencode( $from ) . 
            '&Body=' . urlencode( $body );
        $res = curl_init();
        curl_setopt( $res, CURLOPT_URL, $uri );
        curl_setopt( $res, CURLOPT_POST, 3 ); // number of fields
        curl_setopt( $res, CURLOPT_POSTFIELDS, $fields );
        curl_setopt( $res, CURLOPT_USERPWD, $auth ); // authenticate
        curl_setopt( $res, CURLOPT_RETURNTRANSFER, true ); // don't echo
        $result = curl_exec( $res );
         curl_close( $res );
        return $result;        
    }
    
    
    
}


?>