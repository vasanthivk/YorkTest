<?php



class feedback{
    
    
    static function save($tokenData){
    	
    	$device=explode(':',clean::post('device'));
    	
    	slack::message($tokenData->email.' '.clean::post('feedback').' '.clean::post('device'),'#feedback');
    	
    	
    	
        $fields=array('message'=>clean::post('feedback'),
        	'device'=>clean::post('device'),
        	'version'=>clean::post('version'),
        	'os'=>$device[0],
        	'osversion'=>$device[1],
        	'model'=>$device[2],
        	'maker'=>$device[3],
        'email'=>$tokenData->email,
        'msgdate'=>dbpdo::now());
        print_r($fields);
        dbpdo::dbInsert('feedback',$fields,'',false,true);
        echo 'Thank you for your feedback';

    }
    
     static function listIssues($email){
     	$ret=array();
     	if($email!=''){
	    	$sql='select * from feedback where email=:email order by msgdate desc';
	    	$parms=array(':email'=>$email);
	    	$order=1;
	 		if($stmt=dbpdo::query($sql,$parms)){
			    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			    	$row['msgdate']=date('h:i jS M y',strtotime($row['msgdate']));
			    	$ret[$order]=$row;
			    	$order++;
			    	
			    }
	 		}
     	}
     	return json_encode($ret);
   	
    }
    

    
    
    
}



?>