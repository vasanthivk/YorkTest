<?php



class sendgrid{
    

    
    
    static function send($subject,$html,$toAddress,$toName,$from='noreply@clevertech.tv',$path='',$file=''){
        $json_string = array(
          'to' => array(
            'andy@clevertech.tv', 'andy.derrick@me.com'
          ),
          'category' => 'bulk'
        );
        
        $sendgrid_apikey=settings::getSettings('sendgrid','key');
        
        
        $params = array(
            //'api_user'  => settings::getSettings('sendgrid','Username'),
            //'api_key'   => settings::getSettings('sendgrid','Password'),
            //'x-smtpapi' => json_encode($json_string),
            'to'        => 'andy@clevertech.tv'.' <'.$toAddress.'>',
            'subject'   => $subject,
            'html'      => $html,
            'text'      => str_replace('<br/>',PHP_EOL,strip_tags($html,'<br>')),
            'from'      => settings::getSettings('sendgrid','From'),
          );
          //echo $attachments.'<br/>';
         // $d=pathinfo($attachments);
          //$fpath=$d['dirname'];
          //$fname=$d['basename'];
          //print_r($d);
          if($file!=''){
              $params['admin.css'] = curl_file_create('admin.css');
              //$params['files['.$file.']']='@'.$path.$file;
          }
          
         // print_r($params);
        
        
        $request =  settings::getSettings('sendgrid','url').'api/mail.send.json';
        
// Generate curl request
$session = curl_init($request);
// Tell PHP not to use SSLv3 (instead opting for TLS)
curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
curl_setopt($session, CURLOPT_HTTPHEADER, array('Authorization: Bearer ' . $sendgrid_apikey));
// Tell curl to use HTTP POST
curl_setopt ($session, CURLOPT_POST, true);
// Tell curl that this is the body of the POST
curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
// Tell curl not to return headers, but do return the response
curl_setopt($session, CURLOPT_HEADER, false);
curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($session);
        curl_close($session);

        if(strpos($response,'success')===false){
        	return false;	
        }else{
        	return true;
        }

    }
    
}



