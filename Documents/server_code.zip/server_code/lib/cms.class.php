<?php


class cms{
	

	static function checkAuth(){
			return loginsimple::hasAdminRight('cms');
		
	}
	
	static function languagePath(){
		if(session::get('cms','lang')!=''){
			if(session::get('cms','lang')=='en'){
				return '../cmsdata/';	
			}else{
				return '../cmsdata/'.session::get('cms','lang').'/';
			}
		}else{
			return '../cmsdata/';
		}
	}
    
    static function get($frag){
        $ff=self::languagePath().$frag.'.html';
        if(file_exists($ff)){
            if($ff==''){
                return '...';
            }else{
                return file_get_contents($ff);
            }
        }else{
            return '...';
        }
        
    }
    
    static function save($ref,$html){
		if(loginsimple::isLoggedIn()){
		    if(file_put_contents(self::languagePath().$ref.'.html',$html)){
		    	echo '<script>alert("Update ok");</script>';	
		    }else{
		    	echo '<script>alert("Update failed");</script>';
		    }
		}else{
			
		}
    	
    }
    
    static function image($imgName,$class='',$size='300x300'){
        $class='cmsimg '.$class;
        $img='<img ';
        $img.='src="'.$imgName.'" ';
        $img.=' alt="'.$alt.'" ';
        $img.=' data-size="'.$size.'" ';
        $img.=' class="'.$class.'"/>';
        return $img;
    }
    
    static function wrap($frag,$class,$wrap='div',$extra=''){
    	$f=self::get($frag);
    	//$m=md5($frag);
    	$ret='<'.$wrap.' class="'.$class.' editable cmssave" data-cms="'.$frag.'" '.$extra.'>';
    	$ret.=$f;
    	$ret.='</'.$wrap.'>';
    	return $ret;
    }
    
    static function e($frag){
        $f=self::get($frag);
        return '<span class="cmssave" data-cms="'.$frag.'">'.$f.'</span>';
    }
    
    static function frag($frag='main',$class,$wrap){
    	
    }
    
    
}

?>