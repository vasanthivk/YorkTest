<?php
$autloaded=true;
require_once 'debug.class.php';
// function __autoload($class_name) {
//     debug::add('autoloading',$class_name);
//     $class_name=str_replace('_','/',$class_name);
//     require_once ''.$class_name . '.class.php';
// }

function pgc_autoloader($class_name) {
	if(notAnAWSClass($class_name)){

	    debug::add('autoloading',$class_name);
	    	//echo 'Loading ['.$class_name.']<br/>';
		    $class_name=str_replace('_','/',$class_name);
		    require_once ''.$class_name . '.class.php';
	    }
}

spl_autoload_register('pgc_autoloader');

// Need to exclude AWS classes from autoload
function notAnAWSClass($class_name){
	$excl_array = array('S3Client');
	$include = false;
		if(strpos($class_name, '\\')==false && in_array($class_name, $excl_array)==false){
			$include = true;
		}
	return $include;
}
?>