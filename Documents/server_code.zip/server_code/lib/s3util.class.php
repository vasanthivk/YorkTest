<?php

require_once(__DIR__.'../../content/aws/aws.phar');

use Aws\S3\S3Client;
use Aws\Credentials\Credentials;

class s3util{
	
	// ACL flags
	const ACL_PRIVATE = 'private';
	const ACL_PUBLIC_READ = 'public-read';
	const ACL_PUBLIC_READ_WRITE = 'public-read-write';
	const ACL_AUTHENTICATED_READ = 'authenticated-read';
	
	private static $client;
	
	static function init($reload=false){
    	if(!isset(self::$client) or $reload){  
		try {
				$credentials = new Credentials(settings::getSettings('amazons3', 'accesskey'), settings::getSettings('amazons3', 'Secretkey'));
			    $s3 = new S3Client([
			    'credentials' => $credentials,
    			'version' => 'latest',
    			'region'  => 'eu-west-2'
				]);
				self::$client = $s3;
			} catch (Exception $e) {
				debug::add('AWS S3 error',$e->getMessage());
			    die();
			}
        	return self::$client;
    	}
	}
	
	public static function getObject($bucket, $key){
		self::init();

		try{	
			$result = self::$client->getObject(array(
			    'Bucket' => $bucket, // REQUIRED
			    'Key' => $key, // REQUIRED
			    // 'IfMatch' => 'File found',
			    // 'IfNoneMatch' => 'File not found'
			));	
						echo 'Get object';
		}catch (Exception $e) {
			debug::add('AWS S3 error',$e->getMessage());
			$result=null;
		}
		return $result;
	}
	
	public static function putObjectString($source,$bucket,$uri,$permissions){
		self::init();
		$result=self::$client->putObject(array(
		    'Bucket' => $bucket,
		    'Key'    => $uri,
		    'Body'   => $source,
		    'ACL' => $permissions
		));
		return $result;
	}
	
	/*
	 * Adds an object to a bucket.
	 *
	 * @param string $file The name of the file e.g. test.txt
	 * @param string $bucket The name of the bucket you're adding the object to e.g. pgcgroup.com
	 * @param string $uri The path and filename of the file you want to add e.g. 'library/Commuter Benefits.pdf'
	 * @param s3util const The access level of the object e.g. s3util::ACL_PUBLIC_READ
	 * @param array $metadata Associative array of custom strings keys (MetadataKey) to strings
	 * @param string $contentType A standard MIME type describing the format of the object data. 
	 *
	 */

	public static function putObjectFile($file, $bucket, $uri, $acl = self::ACL_PRIVATE, $metaHeaders = array(), $contentType = null)
	{
		self::init();

		self::$client->putObject(array(
			'ACL' => $acl,
	    	'Bucket'     => $bucket,
	    	'SourceFile' => $file,
		  	'Key'  => $uri,
	    	'Metadata' => $metaHeaders,
	    	'ContentType' => $contentType
		));
	}
	
	/*
	 * Get a signature v4 signed request uri.
	 * 
	 * @param string $keyname The path and filename of the file you want to access e.g. 'onboard/logo-home.png'
	 * @param integer $timeout The value in seconds for the timeout e.g. '+30 seconds'. If ommitted, defaults to 20 minutes.
	 * @param string $bucket The bucket which holds the file you want to access e.g. 'pgcgroup.com'
	 *
	 * @return string
	 * 
	 */
	
	public static function getPresignedUri($keyname, $timeout='+20 minutes', $bucket='pgcgroup.com')
	{
		self::init();
		
		$cmd = self::$client->getCommand('GetObject', [
		    'Bucket' => $bucket,
		    'Key'    => $keyname
		]);
		
		$request = self::$client->createPresignedRequest($cmd, $timeout);

		$presignedUrl = (string) $request->getUri();
		
		return $presignedUrl;
	}
	

	/*
	 * Copy a single file from one s3 bucket to another
	 *
	 * echo print_r(copyToBucket('pgcpublic.com', 'logo-home.png','pgcgroup.com', 'onboard/logo-home-copy.png'));
	 * 
	 * @param string $sourceBucket The bucket you're copying the file from e.g. 'pgcpublic.com'
	 * @param string $sourcecKeyname The path and filename of the file you want to copy e.g. 'onboard/logo-home.png'
	 * @param string $targetBucket The destination bucket you're copying the file to e.g. 'pgcgroup.com'
	 * @param string $targetKeyname The path and filename of the file you want to create e.g. 'onboard/logo-home-copy.png'
	 * 
	 * @return array
	 * 
	 */

	public static function copyToBucket($sourceBucket, $sourceKeyname, $targetBucket, $targetKeyname)
	{
		self::init();

		try{
			// Copy an object.
			$response = self::$client->copyObject(array(
		    'Bucket'     => $targetBucket,
		    'Key'        => $targetKeyname,
		    'CopySource' => "{$sourceBucket}/{$sourceKeyname}",
			));
		}catch (Exception $e) {
				debug::add('AWS S3 error',$e->getMessage());
			    die();
		}
	    
	    return $response;
	}

}