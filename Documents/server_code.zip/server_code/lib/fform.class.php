<?php


class fform{
	
	static $data=array();
	static $map=array();
	
	static function load($inData){
		self::$data=$inData;
	}
	
	static function get($field){
		return h::safeArray(self::$data,$field);
	}
	
	
	static function dispField($field,$cols=3,$opt=array()){
		$opt=self::setDefaults($opt);

		$ret='<div class="col s12 m'.$cols.'">';
			if(!$opt['label']){
				$ret.='<label>'.fields::fieldTitle($field).'</label>';
			}
			$ret.='<div class="">'.self::get($field).'</div>';
		$ret.='</div>';
		return $ret;
	}
	
	static function field($field,$cols=3,$opt=array()){
		$opt=self::setDefaults($opt);
		$ret='<div class="col s12 m'.$cols.'">';
			if($opt['label']!=false){
				$ret.='<label>'.fields::fieldTitle($field).'</label>';
			}
		$disabled='';
		if($opt['readonly']){
			$disabled=' disabled ';
		}

		
		if($opt['dropdown']==true){
			$ret.=self::dropDown($field,$opt);	
		}elseif($opt['date']==true){
			$ret.=self::datePicker($field,$opt);
		}elseif($opt['textarea']==true){
			$ret.=self::textarea($field,$opt);	

		}else{
			$ret.='<input '.$disabled.' class="ffield" type="text" id="'.$field.'" name="'.$field.'" value="'.h::safeArray(self::$data,$field).'" placeholder="'.$opt['place'].'"/>';
			
		}
		$ret.='</div>';
		if($opt['hidden']){
			$ret='';
		}
		return $ret;
	}
	
	static function textarea($field,$opt){
		$ret='<textarea class="materialize-textarea '.$opt['class'].'" placeholder="'.$opt['place'].'">'.h::safeArray(self::$data,$field).'</textarea>';
		return $ret;
	}
	
	static function dropDown($field,$opt){
		$ret='<select id="'.$field.'" placeholder="'.$opt['place'].'" class="ffield">';
			$ret.=fields::getDrop($field);
		$ret.='</select>';
		return $ret;
	}
	
	
	static function setDefaults($opt){
		$defaults=array('readonly'=>false,
					'hidden'=>false,
					'textarea'=>false,
					'dropdown'=>false,
					'date'=>false,
					'label'=>true,
					'class'=>'',
					'place'=>'...',
					'cols'=>3
		);
		return array_merge($defaults,$opt);
	}

	

	static function show($viewFile){
		$map=self::getTemplate($viewFile);
		foreach($map as $field=>$options){
			echo self::field($field,$options['cols'],$options).'<hr/>';
		}
	}
	

	
	static function getTemplate($viewFile){
		$map=array();
		$loadedFile=file($viewFile);
		$line=1;
		foreach($loadedFile as $line){
			$items=explode('##',$line);
			if(sizeof($items)==2){
				$options=self::setDefaults(json_decode($items[1],true));
				$map[$items[0]]=$options;
			}else{
				log::logError('Faulty line in field view '.$viewFile.' ['.$line.']');
			}
			$line++;
		}
		foreach($map as $field=>$options){
			echo self::field($field,$options['cols'],$options);
		}

		return $map;
	}
	
	static function createTemplate(){
		$sql='select * from worker_onboard';
		$parms=array();
		if($stmt=dbpdo::query($sql,$parms)){
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				foreach($row as $key=>$val){
					echo $key.'##{"cols":4}<br/>';
				}
			}
		}		
		
	}
	
	static function showTemplate(){
		foreach(self::$data as $key=>$value){
			echo $key.'##{"cols":4}<br/>';	
		}
	}
	

    static function datePicker($name,$class='s12',$title='',$options=array()){
    	$rawDate=self::get($name);
    	if($rawDate!=''){
        	$d=strtotime($rawDate);
        	$dd=date('m/d/Y',$d);
    	}else{
    		$dd='';
    	}
        $field='<input type="date" title="'.self::get($name).'" name="'.$name.'" id="'.$name.'" value="'.$dd.'" class="act-date ffield">';
        return $field;
    }


	
	
}


?>