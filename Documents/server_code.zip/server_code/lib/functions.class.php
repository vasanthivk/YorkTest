<?php 

	class functions{
		
		static function divWrap($classes,$content){
			return '<div class="'.$classes.'">'.$content.'</div>';
		}

		static function redirect(){
			if(!array_key_exists('nextpage',$_SESSION)){
        		$_SESSION['nextpage']='../main/index.php';
		    }
			header("Location: ".$_SESSION['nextpage']);
			echo '<script type="text/javascript">window.location = "'.$_SESSION['nextpage'].'"';
			exit();
		}

		static function startForm($dbtable,$ref){
			$ret='';
			$ret.='<div class="row">';
			$ret.='<form class="col s12 bkoff">';
			$ret.='<div class="row">';
			$row=array('_tablename'=>$dbtable,'_ref'=>$ref);
			$ret.=self::showHidden('_tablename',$row);
			$ret.=self::showHidden('_ref',$row);
			return $ret;
		}
		static function endForm(){
			$ret='';
			$ret.='</div>';
			$ret.='</form>';
			$ret.='<div class="content-update"></div>';
			$ret.='</div>';
			return $ret;
		}
		static function formButton($div){
			$ret='';
			$ret.='<div class="input-field col s12">';
				$click="'".$div."'";
				$ret.='<a onclick="contentUpdate('.$click.');return false;" class="btn waves-effect waves-light" name="action">Update';
    			$ret.='<i class="mdi-content-send right"></i>';
			 	$ret.='</a>';
			$ret.='</div>';
  			return $ret;
		}

		static function showContentEditable($id,$row,$label=''){
			$ret='';
			$value='';
			if(is_array($row)){
				if(array_key_exists($id,$row)){
					$value=$row[$id];
				}
			}
			$ret.='<div class="input-field col s12">';
				$ret.="<textarea class='materialize-textarea editable' id='".$id."'>".$value."</textarea>";
				if($label!=''){
					$ret.='<label class="active" for="'.$id.'">'.$label.'</label>';	
				}
			$ret.='</div>';
			return $ret;
		}

		static function showInput($id,$row,$label='',$class='',$break=false){
			$ret='';
			$value='';
			if(is_array($row)){
				if(array_key_exists($id,$row)){
					$value=$row[$id];
				}
			}
			$ret.='<div class="input-field col s12">';
				$ret.='<input type="text" class="validate '.$class.'" type="input" id="'.$id.'" value="'.$value.'"/>';
				if($label!=''){
					$ret.='<label class="active" for="'.$id.'">'.$label.'</label>';	
				}
			$ret.='</div>';
			if($break){
				$ret.='<div class="hrdiv"></div>';
			}
			return $ret;
		}
		static function showHidden($id,$row){
			$ret='';
			$value='';
			if(is_array($row)){
				if(array_key_exists($id,$row)){
					$value=$row[$id];
				}
			}
			$ret.='<input type="hidden" id="'.$id.'" value="'.$value.'"/>';
			return $ret;
		}
		static function showYesNoDrop($id,$row,$label=''){
			$ret='';
			$value='No';
			if(array_key_exists($id,$row)){
				$value=$row[$id];
			}
			$ret.='<div class="input-field col s12">';
				$ret.= '<select class="browser-default" id="'.$id.'" name="'.$id.'">';
				$sel='';
				if($value==true){$sel='selected="selected"';}
				$ret.= '<option value="Yes" '.$sel.'>Yes</option>';
				if($value=='No'){$sel='selected="selected"';}else{$sel='';}
				$ret.= '<option value="No" '.$sel.'>No</option>';
				$ret.= '</select>';
				if($label!=''){
					$ret.='<label class="active">'.$label.'</label>';	
				}
			$ret.= '</div>';
			return $ret;
		}

		static function showDate($id,$row,$label='',$class='',$break=false){
			$ret='';
			$value='';
			if(is_array($row)){
				if(array_key_exists($id,$row)){
					$value=$row[$id];
				}
			}
			$ret.='<div class="input-field col s12">';
				$ret.='<input type="date" class="datepicker validate '.$class.'" id="'.$id.'" value="'.$value.'"/>';
				if($label!=''){
					$ret.='<label class="active" for="'.$id.'">'.$label.'</label>';	
				}
			$ret.='</div>';
			if($break){
				$ret.='<div class="hrdiv"></div>';
			}
			return $ret;
		}
		static function zzzshowSimpleDrop($id,$row,$dropvalues,$label=''){
			$ret='';
			$value='';
			if(is_array($row)){
				if(array_key_exists($id,$row)){
					$value=$row[$id];
				}
			}
			if($label!=''){
				$ret.='<label>'.$label.'</label>';	
			}
			$ret.= '<select class="browser-default" id="'.$id.'" name="'.$id.'">';
			foreach($dropvalues as $key){
				$sel='';
				if($value==$key){$sel='selected="selected"';}
				$ret.= '<option value="'.$key.'" '.$sel.'>'.$key.'</option>';
			}
			$ret.= '</select>';
			return $ret;
		}
		
		
		static function showDBDrop($id,$row,$droptable,$label='',$blankrow=false,$minvalue=false){
			$ret='';
			$value='';
			if(array_key_exists($id,$row)){
				$value=$row[$id];
			}
			$sql='select * from dropdowns where fieldname=:name ';
			$parm=array(':name'=>$droptable);
			if($minvalue){
				$sql.=' and ref >=:ref';
				$parm[':ref']=$value;				
			}
			$stmt=dbpdo::query($sql,$parm);
			$ret.='<div class="input-field col s12">';
				if($label!=''){
					$ret.='<label class="active">'.$label.'</label>';	
				}
				$ret.= '<select class="" id="'.$id.'" name="'.$id.'">';
				if($blankrow){
					$ret.= '<option value="" ></option>';
				}
				if ($stmt) {
					while($row=$stmt->fetch()){
						$sel='';
						if($value==$row['ref']){$sel='selected="selected"';}
						$ret.= '<option value="'.$row['ref'].'" '.$sel.'>'.$row['fielddata'].'</option>';
					}
				}
				$ret.= '</select>';
			$ret.= '</div>';
			return $ret;
		}

		static function showMutliLangEditable($id,$lang='en'){
			products::initProduct($id);
			$ret='';
			$ret.='<div class="row col bkoff languageChange">';
				$ret.='<div class="input-field col s12">';
    				$ret.='<select class="browser-default langselect">';
	    			$selected=false;
	    			if('jp'==$lang){$selected=true;$sel='selected';}else{$sel='';}
	      			$ret.='<option value="jp" '.$sel.'>Japanese</option>';
	    			if('cn'==$lang){$selected=true;$sel='selected';}else{$sel='';}
	      			$ret.='<option value="cn" '.$sel.'>Chinese</option>';
	    			if('en'==$lang){$selected=true;$sel='selected';}else{$sel='';}
	    			if($selected===false){$sel='selected';}
	      			$ret.='<option value="en" '.$sel.'>English</option>';
	    			$ret.='</select>';
					$ret.='<label class="active">Language</label>';
				$ret.='</div>';			
				$ret.='<div class="input-field col s12">';
					language::initText(products::field('title'));
					$ret.='<input type="text" class="validate langtitle" type="input" id="ztitle" value="'.language::getLanguage($lang).'"/>';
					$ret.='<label class="active" for="ztitle">Title</label>';	
				$ret.='</div>';			
				$ret.='<div class="input-field col s12">';
					language::initText(products::field('shorttitle'));
					$ret.='<input type="text" class="validate langshorttitle" type="input" id="zshorttitle" value="'.language::getLanguage($lang).'"/>';
					$ret.='<label class="active" for="zshorttitle">Short Title</label>';	
				$ret.='</div>';	
				$ret.='<div class="input-field col s12">';
					language::initText(products::field('shortdesc'));
					//$ret.="<textarea data-ref='".$id."' class='materialize-textarea langdescription editable'>".language::getLanguage($lang)."</textarea>";
					$ret.="<div data-ref='".$id."' id='shortdesc' class='stextedit langdescription editable'>".nl2br(language::getLanguage($lang))."</div>";
					$ret.='<label class="active" for="shortdesc">Short Description</label>';	
				$ret.='</div>';			

				$ret.='<div class="input-field col s12">';
					language::initText(products::field('description'));
					//$ret.="<textarea data-ref='".$id."' class='materialize-textarea langdescription editable'>".language::getLanguage($lang)."</textarea>";
					$ret.="<div data-ref='".$id."' id='description' class='stextedit langdescription editable'>".nl2br(language::getLanguage($lang))."</div>";
					$ret.='<label class="active" for="description">Description</label>';	
				$ret.='</div>';			
				$ret.='<div class="input-field col s12">';
					$ret.='<a onclick="descUpdate();return false;" class="btn waves-effect waves-light" name="action">Update';
    				$ret.='<i class="mdi-content-send right"></i>';
				 	$ret.='</a>';
				$ret.='</div>';			
				$ret.='<br/><div class="descriptionupd"></div>';
			$ret.='</div>';
			return $ret;
		}

		static function subcategories($prodref){
		
			$subsql='select * from coursecategory where productref=:ref;';
			$subparms=array(':ref'=>$prodref);
			$substmt=dbpdo::query($subsql,$subparms);
			$arr=array();
			if ($substmt) {
				while($subrow = $substmt->fetch()){
					$arr[$subrow['subcategoryref']]='Yes';
				}
			}

			$ret='';
			$ret.='<div class="input-field col s12 bkoff">';
				$ret.='<label>Sub Categories</label><br/>';	
				$sql='select * from dropdowns where fieldname=:fieldname order by sortorder asc;';
				$parms=array(':fieldname'=>'subcategory');
				$stmt=dbpdo::query($sql,$parms);
				if ($stmt) {
					while($row=$stmt->fetch()){
						$chk='';
						if(array_key_exists($row['ref'],$arr)){
							$chk='checked="checked"';							
						}
						$ret.='<div class="col s6 m3"><input type="checkbox" id="zcourse'.$row['ref'].'" '.$chk.' class="chkselect" 
								data-catref='.$row['ref'].' data-prodref='.$prodref.' />';
	      				$ret.='<label for="zcourse'.$row['ref'].'">'.$row['fielddata'].'</label></div>';
								
					}
				}
				$ret.='<br/><div class="subcatupd"></div>';
			$ret.='</div>';
			return $ret;

			
		}


		static function tableTitles($inTitleArray){
			$retVal='<tr>';
			foreach($inTitleArray as $item){
				$data=explode('|',$item);
				$span='';
				if(array_key_exists(1,$data)){
					$span='colspan='.$data[1];
				}
				$retVal.='<td '.$span.'>'.$data[0].'</td>';
			}
			$retVal.='</tr>';
			return $retVal;
		}

		static function td($inData, $style=''){
			return '<td '.$style.'>'.$inData.'</td>';
		}
		static function tableRow($arr, $style=''){
			$retVal='<tr>';
			foreach ($arr as $key){
				$retVal.=self::td($key, $style);
			}
			$retVal.='</tr>';
			return $retVal;
		}

}