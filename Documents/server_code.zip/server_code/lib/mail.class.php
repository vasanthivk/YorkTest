<?php


class mail{
    
    static function send($subject,$html,$toAddress,$toName,$from='noreply@clevertech.tv'){
        log::logInfo('Mail send to '.$toAddress.' '.$toName);
    	$headers  = 'MIME-Version: 1.0' . "\r\n";
    	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    	$headers .= 'To: '.$toName.' <'.$toAddress.'>' . "\r\n";
    	$headers .= 'From: ' .$from. "\r\n";
    	if(mail($toAddress, $subject, $html, $headers)){
    	    log::logInfo('Mail send completed');
    	    debug::add('Email send ok');
    	    return true;
    	}else{
    		debug::add('Email send FAILED');
    	    log::logError('Mail error sending to '.$toAddress);
    	    return false;
    	}
    }
    
    static function getFormHtml(){
        $html='';
        foreach(clean::post() as $key=>$value){
	        $html.=$key.' <b>'.$value.'</b><br/>';
        }
        return $html;
    }
    
}


?>
