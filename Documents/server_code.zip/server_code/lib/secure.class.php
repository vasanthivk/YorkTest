<?php



class secure{

	static function redirect($target){
		$cpage=$_SERVER['SCRIPT_NAME'];
		log::logError('Redirect from '.$cpage.' to '.$target);
		debug::add('Redirect from '.$cpage,$target);
		header("Location: $target");
		echo '<script type="text/javascript">window.location = '.$target.'</script>';
		die();

	}

}


?>