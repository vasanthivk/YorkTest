<?php

class form{
	
	static $row=array();
	static $form=array();
	static $ref=0;
    
    static function setTable($tableName){
        $encrypted=self::buildHash($tableName,self::$ref);
        $ret='<input type="hidden" name="formhash" id="formhash" value="'.$encrypted.'"/>';
        return $ret;
    }
    
    static function setDetailFile($file){
        $_SESSION['form']['detailfile']=$file;
    }
    
    static function loadDetail(){
        debug::add('loading form detail');
        $file=session::get('form','detailfile');
        debug::add('file is ',$file);
        if($file!=''){
            debug::add('including');
            include $file;
        }
    }
    
    static function load($table,$updateMsg='Update',$saveMsg='Save'){
	    $ret='';
	    self::$row=array();
		if(clean::get('ref')>0){
			$ret.= '<h4>'.$updateMsg.'</h4>';
			$parms=array(':ref'=>clean::get('ref'));
			$sql='select * from '.$table.' where ref=:ref limit 1';
			if($stmt=dbpdo::query($sql,$parms)){
				self::$row = $stmt->fetch();
				debug::add(self::$row,'data row');
			}
			self::$form['button']=$updateMsg;
			self::$ref=clean::get('ref');
		}else{
			$ret.= '<h4>'.$saveMsg.'</h4>';
			self::$form['button']=$saveMsg;
			self::$ref=0;

		}
		return $ret;
    	
    }
    
    static function delete(){
		$data=self::unHash(clean::post('formhash'));
		dbpdo::dbDelete($data['table'],$data['ref']);
    }
    
    
    static function save(){
    	
    	$fields=array();
        $jsonarr=array();
    	$data=self::unHash(clean::post('formhash'));
    	foreach(clean::post() as $key=>$value){
    		if(strpos($key,'date')===0){
	            $date=strtotime($value);
	            $value=date('Y-m-d',$date);
	            $fields[$key]=$value;
        	}elseif(strpos($key,'json|')===0){
	            $key=str_replace('_',' ',$key);
	            $arr=explode('|',$key);
	            $jsonarr[$arr[1]]=0;
	            $fields[$arr[1]][$arr[2]]=$value;
        	}elseif($key!='formhash'){
        		$fields[$key]=$value;
        	}
    	}
    	foreach($jsonarr as $key=>$val){
    	    $fields[$key]=json_encode($fields[$key]);
    	}
    	print_r($fields);
    	debug::add('data passed ref',$data['ref']);
    	debug::add($data,'data');
	    $ref=dbpdo::dbInsertUpdate($data['table'],$data['ref'],$fields);
	    
	    if($data['table']=='shows' && $data['ref']==0){
	        include '../admin/_addshifts.php';
	    }
	    
	    echo 'Updated';
    }
    
    static function row($row=array()){
    	self::$row=$row;
    }
    
    static function button($class='',$title=''){
    	if($title==''){
    		$title=self::safeKey('button',self::$form);
    	}
    	$ret='<div class="col s12">';
    	$ret.='<button class="btna act-form-save '.$class.'" type="submit">'.$title.'</button>';
    	$ret.=' <button class="btna act-form-cancel">Cancel</button>';
    	if(self::$ref!=0){
    		$ret.=' <button class="btna act-form-del" data-ref="'.self::$ref.'">Delete</button>';
    	}
    	$ret.="</div>";
    	return $ret;
    }
    
    static function input($name,$class='s12',$title='',$options=array(),$validation=''){
        $field='<input class="validate" data-validate="'.$validation.'" value="'.self::safeKey($name,self::$row).'"  id="'.$name.'" type="text" >';
        return self::fieldWrap($name,$class,$title,$options,$field);
    }
    
    static function jsoninput($name,$class='s12',$title='',$options=array()){
        $ret='';
        $roles=self::getDropDownData('Role');
        $json=self::safeKey($name,self::$row);
        $arr=json_decode($json,true);
        if($arr==''){$arr=array();}
        $jsondata=array_merge($roles,$arr);
        foreach ($jsondata as $key => $val){
            $field='<input value="'.$val.'"  id="json|'.$name.'|'.$key.'" type="text" >';
            $ret.=self::fieldWrap($name,$class,$key,$options,$field);
        }
        return $ret;
    }
    
    static function textarea($name,$class='s12',$title='',$options=array()){
        $field='<textarea id="'.$name.'" class="materialize-textarea">'.self::safeKey($name,self::$row).'</textarea>';
        return self::fieldWrap($name,$class,$title,$options,$field);
    }
    
    static function datePicker($name,$class='s12',$title='',$options=array()){
        $d=strtotime(self::safeKey($name,self::$row));
        $dd=date('j F, Y',$d);
        $field='<input type="date" name="'.$name.'" id="'.$name.'" value="'.$dd.'" class="datepicker">';
        return self::fieldWrap($name,$class,$title,$options,$field);
    }

    static function dropdownYesNo($name,$class='s12',$title='',$options=array()){
        $val=self::safeKey($name,self::$row);
        $sel='';
        $field='<select id="'.$name.'" type="text" >';
        	if($val=='Yes'){$sel='selected';}
        	$field.='<option value="Yes" '.$sel.'>Yes</option>';
        	if($val==''){$sel='selected';}else{$sel='';}
        	$field.='<option value="No" '.$sel.'>No</option>';
        $field.='</select>';
        return self::fieldWrap($name,$class,$title,$options,$field);
    }
    
    
    static function fieldWrap($name,$class,$title,$options,$field){
    	if($title==''){
    		$title=$name;
    	}
 		$ret='<div class="input-field col '.$class.'">';
            $ret.=$field;
			$ret.='<label for="'.$name.'" class="active">'.$title.'</label>';
		$ret.='</div>';
		return $ret;
    }

    static function formStart($name){
        $ret='<form class="form-detail main-save">';
        $ret.=self::setTable($name);
        return $ret;
    }    
    static function formEnd(){
        $ret='</form>';
        return $ret;
    }    

    
    static function getDropDownData($field){
        $ret=array();
        $parm=array('fieldname'=>$field);
        $sql='select fielddata from dropdowns where fieldname=:fieldname';
    	if($stmt=dbpdo::query($sql,$parm)){
    	    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                $ret[$row['fielddata']]=0;
    	    }
    	}
        return $ret;
        
    }    
    

    
    static function hidden($name,$value=''){
		if($value==''){
		    $val=self::safeKey($name,self::$row);
		}else{
		    $val=$value;
		}
		$ret='<input  value="'.$val.'"  id="'.$name.'" name="'.$name.'" type="hidden" >';
		return $ret;

    }
    
    static function safeKey($key,$array){
    	if(is_array($array)){
    		if(array_key_exists($key,$array)){
    			return $array[$key];
    		}else{
    			return '';
    		}
    	}else{
    		return '';
    	}
    }
    
    static function unHash($encrypted){
        $hash=self::decrypt($encrypted);
        debug::add('decrypted',$hash);
        list($table,$ref,$xss,$time)=explode(':',$hash);
        if(!self::checkXss($xss)){
            //echo $hash.'<br/>';
            debug::add('xss mismatch');
            
            //print_r($_SESSION);
            //die('hash issue');
        }
        $tdiff=time()-$time;
        debug::add('Hash time gap',$tdiff);
        if($tdiff>900){
            debug::add('form timeout');
            die('hash issue.');
            
        }
        debug::add('tdiff',$tdiff);
        return array('table'=>$table,'ref'=>$ref);
    }
    
    static function ajaxHash($tableName='',$ref=''){
        $hash=self::buildHash($tableName,$ref);
        return '<div id="hash" class="qitem hide">'.$hash.'</div>';
    }
    
    static function showHash($tableName='',$ref=''){
        $hash=self::buildHash($tableName,$ref);
        return '<input type="hidden" name="hash" id="hash" class="hide" value="'.$hash.'"/>';
    }
    
       static function buildHash($tableName='',$ref=''){
        $xss=self::getXss();
        $toHash=$tableName.':'.$ref.':'.$xss.':'.time();
        debug::add('Raw table hash',$toHash);
        $encrypted=self::encrypt($toHash);
        debug::add('encrypted',$encrypted);
        return $encrypted;
        
    }

    
    static function checkXss($xss){
        if($_SESSION['xss']==$xss){
            debug::add('XSS Check OK');
            return true;
        }else{
            return false;
        }
    }
    
    
    static function getXss(){
        if(array_key_exists('xss',$_SESSION)){
            debug::add('xss picked from session',strlen($_SESSION['xss']));
            if(strlen($_SESSION['xss'])==50){
            }else{
                $_SESSION['xss']=self::generateRandomHexString(50);    
            }
        }else{
            $_SESSION['xss']=self::generateRandomHexString(50);   
        }
        return $_SESSION['xss']; 
    }
    
    
    static function generateRandomHexString($length) {
    	return substr(bin2hex(openssl_random_pseudo_bytes(ceil($length / 2))), 0, $length);
    }
    
    static function randomPin(){
        $hex=self::generateRandomHexString(8);
        $dec=hexdec($hex);
        return substr($dec,0,6);
    }
    
	static function encrypt($data){
	    $key=settings::getSettings('database','password');
	    $iv = mcrypt_create_iv(16, MCRYPT_RAND);
		$enc = openssl_encrypt($data, 'AES-256-CBC', $key,0,$iv);
		return base64_encode($iv.$enc);
	}
	
	static function decrypt($encrypted){
	    $wrap=base64_decode($encrypted);
	    $iv = substr($wrap, 0, 16);
	    $data=substr($wrap, 16);
	    $key=settings::getSettings('database','password');
	    return openssl_decrypt($data,'AES-256-CBC',$key,0,$iv);
	}
	
	static function viewQuick($data,$viewFile='../admin/views/_candidates.txt'){
	    debug::add($data,'data');
	    $view=self::loadView($viewFile);
        $ret='';
	    foreach($view as $field=>$layout){
	        $d=h::safeArray($data,$field);
	        $ret.=self::qfield($field,$d,$layout[0],$layout[1],$layout[2]);        
	    }
	    return $ret;
	}

	
	static function allQuick($data){
	    $view=self::loadView('../admin/views/_candidates.txt');
	    $fields=array();
	    foreach($data as $key=>$item){
	        $fields[]=$key;
	    }
	    return self::quick($data,$fields);
	}
	
	static function quick($data,$fields){
	    $ret='';
	    foreach($fields as $key){
	        if(substr($key,0,1)=='#'){
	            $key=substr($key,1);
	        }else{
	            $ret.='<div class="qlabel">'.fields::fieldTitle($key).'</div>';    
	        }
	        //$ret.='<input type="text" class="qitem" id="'.$key.'" value="'.$data[$key].'"/>';
	        $ret.='<div id="'.$key.'" class="qitem" contenteditable=true>'.$value.'</div>';
	    }
	    return $ret;
	}
	
	static function qfield($key,$value,$col=6,$readOnly='F',$dropDown='N',$rawData='',$extra=''){
	        $value=nl2br($value);
            $rd='';
            if($rawData!=''){
                $rd='data-rawdata="'.$rawData.'"';
            }
	        if($readOnly=='H'){
	            $col.=' hidden';
	        }
	        $small=12;
	        if($col<=2){
	            $small=6;
	        }
	        $ret='<div class="col s'.$small.' m'.$col.' relative">';
	        $desc=$col.' '.$readOnly.' '.$dropDown; 
	        if(substr($key,0,1)=='#'){
	            $key=substr($key,1);
	        }else{
	            $ret.='<div class="qlabel">'.fields::fieldTitle($key).'</div>';    
	        }
	        $type='text';
	        $class="";
	        if($readOnly=='E'){
	            $class.=' editable';
	        }
	        if($dropDown=='D'){
	            $class.=' drop';
	        }
	        if($dropDown=='DU'){
	            $class.=' dropusers';
	            if($value==''){
	                $value=$_SESSION['user']['ref'];
	            }
	        }
	        if($dropDown=='DA'){
	            $class.=' dropacc';
	        }
	        if($dropDown=='DP'){
	            $class.=' act-date';
	            $type='date';
	            $value=dbpdo::usaDate($value);
	        }
	        $desc='';
	        if($value==''){
	            //$value='&nbsp;';
	        }
	        if($readOnly=='R'){
	            $ret.='<div '.$rd.' id="'.$key.'" title="'.$desc.'" class="qitem readonly '.$class.'">'.$value.'</div>';
	        }else{
	            $ret.='<div type="'.$type.'" 
	                placeholder="'.self::tidyLabel($key).'" 
	                id="'.$key.'"
	                '.$rd.'
	                title="'.$desc.'" 
	                class="qitem '.$class.'" 
	                contenteditable=true>'.$value.'</div>';
	        }
	        $ret.=$extra;
	        $ret.='</div>';
	        return $ret;
	}
	
	static function tidyLabel($label){
	    $ret=str_replace('_',' ',$label);
	    $ret=ucfirst($ret);
	    return $ret;
	}
	
	static function loadView($viewFile){
	    $va=file($viewFile);
	    $fieldMap=array();
	    foreach($va as $item){
	        $ii=explode(',',$item);
	        $key=array_shift($ii);
	        $ii=array_pad($ii,6,'');
	        foreach($ii as $skey=>$sub){
	            $ii[$skey]=rtrim($sub);
	        }
	        $fieldMap[$key]=$ii;
	    }
	    return $fieldMap;
	}


    
    
}



?>