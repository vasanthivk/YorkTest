<?php

class productxml
{
	private static $dirPaths =  ['/var/www/html/cxx/workspace/quicr/content/xml/'];
	//private static $dirPaths =  ['/var/www/html/cxx/workspace/quicr/content/tmp/'];
	private static $bucket = 'brandbank.data';
	
	public static function archive()
	{
		foreach(self::$dirPaths as $dirPath){
			$dir = new DirectoryIterator($dirPath);
			foreach ($dir as $fileinfo) {
			 	if (!$dir->isDot() & $dir->isFile() ) {
				//	$content = file_get_contents($dirPath . $fileinfo->getFilename() );
					$trimmedFilename = self::getBrandbankFileRefName($fileinfo->getFilename());
					if(self::ageInDays($fileinfo->getFilename()) > 6){
						$fullpath = $dirPath . $fileinfo;
						self::saveToS3($fullpath, self::$bucket, $trimmedFilename, s3util::ACL_PUBLIC_READ, array(), 'text/xml');
						self::deleteFile($fullpath);
						echo 'ARCHIVED: ' . $trimmedFilename . "\n";
			//			log::logInfo('Archived Brandbank xml: ' . $trimmedFilename);
					}else{
						echo 'KEPT: ' . $trimmedFilename . "\n";
			//			log::logInfo('Kept Brandbank xml: ' . $trimmedFilename);
					}
				}
			}
		}
	}
	
	
	public static function ageInDays($filename){
		$filecreated = self::getFileCreatedTime($filename);
		$fileCreatedTime = new DateTime($filecreated);
		$now = new DateTime(date('Y-m-d H:i:s'));
		$oDiff = $fileCreatedTime->diff($now);
		// echo $oDiff->y." Years \n";
		// echo $oDiff->m." Months \n";
		// echo $oDiff->d." Days \n";
		// echo $oDiff->h." Hours \n";
		// echo $oDiff->i." Minutes \n";
		// echo $oDiff->s." Seconds \n";
		return $oDiff->d;
	}

	public static function saveToS3($filepath, $bucket, $uri, $acl, $metaHeaders = array(), $contentType = null){
		$ret = s3util::putObjectFile($filepath, $bucket, $uri, $acl, $metaHeaders, $contentType);
		return $ret;
	}

	public static function getBrandbankFileRefName($filepath){
		$pos = strpos($filepath, 'productdata_');
		return substr($filepath, $pos+12, strlen($filepath));
	}
		
	public static function getFileCreatedTime($filepath){
		$pos = strpos($filepath, 'productdata_');
		$start = $pos+12;
		$length = strlen($filepath) - ($start + 4);
		return substr($filepath, $start, $length);
	}
	
	public static function deleteFile($filename){
		unlink($filename);
	}
	
	public static function generateS3SignedUri($uri){
		$signedUri = s3util::getPresignedUri($uri,'+20 minutes', self::$bucket);
		return $signedUri; 
	}
	
}