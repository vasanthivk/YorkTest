<?php



class import{
	
	static $data;
	static $extract=array();

	static function setData($indata){
        $start= strpos($indata,'products-product-details-uom');
        $end= strpos($indata,'products-product-details-uom',$start+10);
        $subdata=substr($indata,$start,$end-$start);
	    self::$data=$subdata;
	}
	
	static function showExtracted(){
	    print_r(self::$extract);
        echo '<br/><br/><br/>========================<br/><br/>';
        echo self::$data;

	}
	
	static function dbInsert(){
	    $fieldList=self::$extract;
	    $fieldList['date_added']=dbpdo::now();
        $fieldList['productref']=clean::post('productref');
        $fieldList['barcode']=clean::post('barcode');
        $fieldList['category']=clean::post('category');
	    dbpdo::dbInsert('products',$fieldList,'',false);
	}
	
    static function getAllergens($ingredients){
        $ret='';
        $arr=array();
        $cnt=substr_count($ingredients,'<STRONG>');
        $pos=0;
        for ($i = 1; $i <= $cnt; $i++) {
            $startpos=strpos($ingredients,'<STRONG>',$pos)+8;
            $endpos=strpos($ingredients,'</STRONG>',$startpos);
            $pos=$startpos+8;
            $arr[substr($ingredients,$startpos,$endpos-$startpos)]='';
            
        }
        foreach($arr as $key=>$val){
        	$ret.=$key.',';
        }
        return substr($ret,0,-1);
    }
    
    static function getInfo(){

        //image
        $pos=strpos(self::$data,'main-image');
        $startpos=strpos(self::$data,'src="//',$pos)+7;
        $endpos=strpos(self::$data,'"',$startpos+10);
        $path=substr(self::$data,$startpos,$endpos-$startpos);
        $pic=file_get_contents('http://'.$path);
        file_put_contents('../productfiles/'.clean::post('productref').'.jpg',$pic);
        self::$extract['imgpath']='http://'.$path;
        
        //title
        $startpos=strpos(self::$data,'<h1><em>',$pos)+8;
        $endpos=strpos(self::$data,'</em>',$startpos+10);
        $title=substr(self::$data,$startpos,$endpos-$startpos);
        self::$extract['title']= $title;    

        //description
        $pos=strpos(self::$data,'class="summary"');
        $startpos=strpos(self::$data,'<p>',$pos)+3;
        $endpos=strpos(self::$data,'</p>',$startpos);
        $desc=substr(self::$data,$startpos,$endpos-$startpos);
        self::$extract['description']= $desc;
        
        //ingrediants
        $pos=strpos(self::$data,'<h2>Ingredients</h2>');
        $startpos=strpos(self::$data,'<p>',$pos)+3;
        $endpos=strpos(self::$data,'</p>',$startpos);
        $ingredients=substr(self::$data,$startpos,$endpos-$startpos);
        self::$extract['ingredients']= $ingredients;
        self::$extract['allergens']= self::getAllergens($ingredients);
        
        
        //nutrition
        $pos=strpos(self::$data,'<h2>Nutrition</h2>');
        $startpos=strpos(self::$data,'<tbody>',$pos);
        $endpos=strpos(self::$data,'</tbody>',$startpos);
        $nutrition=substr(self::$data,$startpos,$endpos-$startpos);
        self::$extract['nutrition']= self::stripChars(strip_tags($nutrition));
        
        //cook
        $pos=strpos(self::$data,'<h3>Oven Cook</h3>');
        $startpos=strpos(self::$data,'<p>',$pos+3);
        $endpos=strpos(self::$data,'</p>',$startpos);
        $cook=substr(self::$data,$startpos,$endpos-$startpos);
        self::$extract['cook']= self::stripChars(strip_tags($cook));
        
        //recycling
        $pos=strpos(self::$data,'<h2>Recycling</h2>');
        $startpos=strpos(self::$data,'<tbody>',$pos);
        $endpos=strpos(self::$data,'</tbody>',$startpos);
        $recycling=substr(self::$data,$startpos,$endpos-$startpos);
        self::$extract['recycling']= self::stripChars(strip_tags($recycling));
        
        //ataglance
        $pos=strpos(self::$data,'<h2>At a glance</h2>');
        $startpos=strpos(self::$data,'<ul>',$pos+4);
        $endpos=strpos(self::$data,'</ul>',$startpos);
        $ataglance=substr(self::$data,$startpos,$endpos-$startpos);
        self::$extract['ataglance']= self::stripChars(strip_tags($ataglance));
        
        //additives
        $pos=strpos(self::$data,'<dt>Additives</dt>');
        $startpos=strpos(self::$data,'<ul>',$pos+4);
        $endpos=strpos(self::$data,'</ul>',$startpos);
        $additives=substr(self::$data,$startpos,$endpos-$startpos);
        self::$extract['additives']= self::stripChars(strip_tags($additives));
        
		return $path;
    }
	
	static function stripChars($data){
        $data=trim(preg_replace('/\t+/', '', $data));
        //$data=str_replace('\t','',$data);
        return $data;
	}	
}

?>