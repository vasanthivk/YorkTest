<?php

class slack{
    
    
    static function message($message, $channel='',$hookUrl=''){
        $message=loginsimple::getUserx().' | '.$message;
        if($hookUrl!=''){
            $url=$hookUrl;   
        }else{
            $url="https://hooks.slack.com/services/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";
        }
        $inData=array('text'=>$message);
        if($channel!=''){
            $inData['channel']=$channel;
        }
        $json=json_encode($inData);
        $ch = curl_init($url);
        $data = http_build_query([
            "payload"=>$json
            ]);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
    
    
}


?>