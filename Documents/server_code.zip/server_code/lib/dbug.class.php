<?php


class dbug{
	
	static $output=array();
	
	static function start(){
		$op['session']=$_SESSION;
		$op['cookies']=$_COOKIE;
		$op['list']=array();
		$op['errors']=array();
		$op['warnings']=array();
		$op['get']=clean::get();
		$op['post']=clean::post();
		self::$output=$op;
	}
	
	
	static function add($title,$data='',$item='list'){
		self::$output[$item][]=array($title,$data);
	}
	
	static function write(){
		$date=date('h:i:s');
		$ff=explode('/',$_SERVER['PHP_SELF']);
		$file=array_pop($ff);
		$path=array_pop($ff);
		$full=$date.' '.$path.':'.$file;
		if(substr($file,0,4)!='dbug'){
		    file_put_contents('../../dbug/'.$full.'.log',json_encode(self::$output));
		}
	}
	
	static function listItems(){
		$d=scandir('../../dbug');
		$d=array_reverse($d);
		$cc=0;
		foreach($d as $item){
			if($item!='.' && $item!='..'){
				echo '<a href="#" class="dbug-item">'.$item.'</a>';
				$cc++;
			}
			if($cc>40){
				return;
			}
		}
	}
	
	static function tidyUp(){
	    $time=time();
	    echo 'Time '.$time;
		$d=scandir('../../dbug');
		foreach($d as $file){
		    if($file!='.' && $file!='..'){
    		    $fname='../../dbug/'.$file;
    		    echo ($time-filemtime($fname)).' '.$file.'<br/>';
    		    if(($time-filemtime($fname))>3600){
    		        unlink($fname);
    		        echo 'deleted';
    		    }
		    }
		    
		}
	    
	}
	
	static function walker($inArray,$offset=0,$open=false){
	    if($open){
	        $ret='<div class="dbug-panel level'.$offset.'">';    
	    }else{
	        $ret='<div class="dbug-panel level'.$offset.'">';    
	    }
        
        foreach($inArray as $key=>$value){
            if(is_array($value)){
                $ret.='<a href="" class="dbug-x"><b>'.$key.'</b></a><br/>';
                $ret.=self::walker($value,$offset+1,$open);
            }else{
                $ret.=$key.' <i>'.$value.'</i><br/>';
            }
        }
        $ret.='</div>';
        return $ret;
    }
    
	static function logErrors($showDebug=false){
		self::$showDebug=$showDebug;
		set_error_handler(array('debug','localerror'),E_ALL);
		register_shutdown_function(array('dbug','shutdown'));
	}




    static function localerror($errNo,$errString){
        self::add('PHP ERROR '.$errNo,$errString,'errors');
        self::add('ERROR TRACE',self::trace(debug_backtrace()),'errors');
        return false;
    }
    
	static function shutdown() {
	    $isError = false;
	    $errorType='Unknown';
	    if ($error = error_get_last()){
	    switch($error['type']){
	        case E_ERROR:
	        	$errorType='E_ERROR';
	        case E_CORE_ERROR:
	        	$errorType='E_CORE_ERROR';
	        case E_COMPILE_ERROR:
	        	$errorType='E_COMPILE_ERROR';
	        case E_WARNING:
	        	$errorType='E_WARNING';
	        case E_NOTICE:
	        	$errorType='E_NOTICE';
	        case 8:
	            $errorType='Not Sure'; 
	        case E_USER_ERROR:
	        	$errorType='E_USER_ERROR';
	            $isError = true;
	            break;
	        }
	    }

	    $errorType.=' '.$error['type'];

	    if ($isError){
	    	debug::log('SHUTDOWN ERROR '.$errorType.' '.$error['message'].' line '.$error['line']);
	    	$appname=settings::get('slack','appname');
	    	log::logError(basename($_SERVER["PHP_SELF"]).' ERROR '.$appname.' '.$error['line'].' '.$error['message']);
	    	slack::message(basename($_SERVER["PHP_SELF"]).' ERROR '.$appname.' '.$error['line'].' '.$error['message'].' :confused:','#debug');
	    	debug::add('SHUTDOWN ERROR '.$errorType,$error['message'].' line '.$error['line']);

	    	
	    	//echo debug::show();
	    }
	    if(self::$showDebug){
		    debug::log('### START OF STORED DEBUG OUTPUT ###');
		    debug::log(debug::show());
		    debug::log('### END OF STORED DEBUG OUTPUT ###');	    	
	    }

	}
	
        static function trace($bt='',$min=true){
            if($bt==''){
                $bt=debug_backtrace();
            }
            $bt=array_reverse($bt);
            $ret='';
            if($min){
                $rr=array_pop($bt);
                $p=array_pop($bt);
                $q=array_pop($bt);
                
                $x=array($p);
                $x[]=$q;
            }else{
                $x=$bt;
            }
            foreach($x as $trace){
                $type=self::sa($trace,'type');
                $class=self::sa($trace,'class');
                $line=self::sa($trace,'line');
                $function=self::sa($trace,'function');
                $aa=self::sa($trace,'args');
                if($function!=''){
                    $ret.='<b>'.$class.$type.$function.'()</b> ['.$line.'] >>';
                }
            }
            return $ret;
        }
        
    static function sa($ar){
        $numargs = func_num_args();
        $arg_list = func_get_args();
        if(!is_array($arg_list[0])){
            return '';
        }
        $numargs = func_num_args();
        $arg_list = func_get_args();
        $aritterator = $ar;
        for($i = 1; $i < $numargs; $i++){
            if (isset($aritterator[$arg_list[$i]]) || array_key_exists($arg_list[$i], $aritterator)){
                $aritterator = $aritterator[$arg_list[$i]];
            }else{
                return '';
            }
        }
        return($aritterator);
}




	
	
	
	
	
	
	
}


?>