<?php


class dropdowns{
    
    static function get($table,$fields){
        //$sql='select * from ';
    }
    
    
}

?>