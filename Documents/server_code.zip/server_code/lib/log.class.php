<?php


class log{

	static $pageStart;
	
static function read_last_lines($fp, $num)
{
    $idx   = 0;
    $lines = array();
    while(($line = fgets($fp)))
    {
        $lines[$idx] = $line;
        $idx = ($idx + 1) % $num;
    }
    $p1 = array_slice($lines,    $idx);
    $p2 = array_slice($lines, 0, $idx);
    $ordered_lines = array_merge($p1, $p2);
    return $ordered_lines;
}

    static function tail($max=50,$lastTime=0){
        $ret='';
        
        $ftime=filemtime(self::logFileName());
        $ret.='<div class="last-log-time">'.$ftime.'</div>';
        $fp    = fopen(self::logFileName(), 'r');
        $lines = self::read_last_lines($fp, $max);
        fclose($fp);
        $lines=array_reverse($lines);
        $div="<div class='ll'>";
        foreach($lines as $line){
            $line=str_replace('ERROR','<b>ERROR</b>',$line);
            $line=str_replace('SECURITY','<I>SECURITY</I>',$line);
            if(strpos($line,'ERROR')==false){
            }else{
                $div="<div class='ll error'>";    
            }
            if(strpos($line,'INFO')==false){
            }else{
                $div="<div class='ll info'>";    
            }
            if(strpos($line,'SECURITY')==false){
            }else{
                $div="<div class='ll security'>";    
            }
            if(strpos($line,'MAILGUN')==false){
            }else{
                $div="<div class='ll mailgun'>";    
            }


            
            $ret.=$div.'<span>'.$line.'</span></div>';
        }
        if($lastTime==$ftime){
            return '';
        }else{
            return $ret;    
        }
        
    }
    
    static function logFileName($filePrefix=''){
		$fname=$filePrefix.date('d-m-y').'.log';
		$pi=pathinfo(__DIR__);
		$di=$pi['dirname'];
		return $di.'/logs/'.$fname;
        
    }



	static function setPageStartTime(){
		self::$pageStart=microtime();
		//self::logg('PAGESTART',self::$pageStart);
	}

	static function showPageLoadTime(){
		$end=microtime();
		$diff=$end-self::$pageStart;
		if($diff>0.1){
			self::logg('++PAGETIME++',$diff);
		}else{
			self::logg('PAGETIME',$diff);
		}
		

	}


	static function logg($type,$data,$user='',$notify=false,$filePrefix=''){
		$fname=$filePrefix.date('d-m-y').'.log';
		
		$pi=pathinfo(__DIR__);
		$di=$pi['dirname'];
		$path=$di.'/logs/'.$fname;
		$path=self::logFileName($filePrefix);
		//debug::add('log path',$path);

		$fh=fopen($path,'a');

		$now=date('d-m-y H:i:s');

		$logLine=$now.' | ';
		$logLine.=str_pad($type,8,' ',STR_PAD_RIGHT).' | ';
		$logLine.=str_pad('{'.$user.'}',8,' ',STR_PAD_RIGHT);
		$logLine.=' | '.self::arrayCheck($data);
		$logLine.='  {'.$_SERVER['PHP_SELF'].'}';
		$logLine.=PHP_EOL;
		fwrite($fh,$logLine);
		fclose($fh);
		if($notify){
			//self::sendPushover($logLine);
		}
	}

	static function arrayCheck($data){
		if(is_array($data)){
			$op='Array : ';
			foreach($data as $key=>$value){
				$op.=$key.'=>'.$value.',';
			}
			return $op;
		}else{
			return 'String : '.$data;
		}
	}

	static function logErrorPlus($data,$user='',$notify=false,$filePrefix=''){
		$bt=debug_backtrace();
		$btsub=self::getSubArray($bt,2);
		$trace=self::getSubArray($btsub,'class').' / '.self::getSubArray($btsub,'function').' / '.self::getSubArray($btsub,'line');


		self::logg('PHP_ERROR',$trace.' :::'.$data,$user,$notify,$filePrefix='');
	}

	static function logError($data,$user='',$notify=false,$filePrefix=''){
		self::logg('ERROR',$data,$user,$notify,$filePrefix='');
	}

	static function logWarning($data,$user='',$notify=false,$filePrefix=''){
		self::logg('WARNING',$data,$user,$notify,$filePrefix='');
		
	}

	static function logInfo($data,$user='',$notify=false,$filePrefix=''){
		self::logg('INFO',$data,$user,$notify,$filePrefix);	
	}

	static function logDebug($data,$user='',$notify=false,$filePrefix=''){
		self::logg('DEBUG',$data,$user,$notify,$filePrefix='');
	}

	static function logKeyStep($data,$user='',$notify=false,$filePrefix=''){
		self::logg('KEYSTEP',$data,$user,$notify,$filePrefix='');
	}
	
	static function logSecurity($data,$user='',$notify=false,$filePrefix=''){
		self::logg('SECURITY',$data,$user,$notify,$filePrefix='');
	}
	
	static function logJSError($data,$user='',$notify=false,$filePrefix=''){
		self::logg('JSERROR',$data,$user,$notify,$filePrefix='');
	}



	static function startErrorLogs(){
		set_error_handler(array('log','logPHPError'),E_ALL);

	}

	static function logPHPError($errno, $errstr, $errfile, $errline){

		self::logErrorPlus($errno.':'.$errstr.'...'.$errfile.': ('.$errline.') ','',true);
	}


		private static function getSubArray($inArray,$target){
			$retVal='';
			if(is_array($inArray)){
				if(array_key_exists($target,$inArray)){
					$retVal=$inArray[$target];
				}				
			}
			return $retVal;
		}





}


?>