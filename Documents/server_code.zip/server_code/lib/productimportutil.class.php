<?php

class productimportutil
{

    public static function downloadFile($dir, $newFileContent, $filename=''){

	    $newFilemame = $dir . $filename;
	    
//	    echo $newFilemame . "\n";

	    $ret = null;
	
	    if (file_put_contents($newFilemame, $newFileContent) !== false) {
	    	$ret = $newFilemame;
	    	echo "File created (" . basename($newFilemame) . ")" . "\n";
		} else {
	    	echo "Cannot create file (" . basename($newFilemame) . ")" . "\n";
		}
			
	    return $ret;
    }
    
    
    public static function randomString( $length = 32 ) {
	    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	    $max = strlen($chars)-1;
	    $str='';
	    for ($i = 0; $i < $length; $i++) {
			$str .= $chars[mt_rand(0, $max)];
		}
	    return $str;
	}
	
		 //public static function downloadFile($dir, $newFileContent, $filename=''){

	  //      $newFilemame = $dir . $filename;
	  //      $ret = false;
	
	  //  	if (file_put_contents($newFilemame, $newFileContent) !== false) {
	  //  		$ret = $newFilemame;
	  //  		echo "File created (" . basename($newFilemame) . ")" . "\n";
	  //  		$ret=true;
			// } else {
	  //  		echo "Cannot create file (" . basename($newFilemame) . ")" . "\n";
			// }
			
	  //      return $ret;
   // }
}