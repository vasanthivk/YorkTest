<?php

class push{
    
    static $pusher=false;
    
    static function init(){
        if(!self::$pusher){
            $options = array(
                'cluster' => 'eu',
                'encrypted' => true
              );
              self::$pusher = new Pusher(
                '934d3572d544c91c47f8',
                'dc76c467f48495d28aa2',
                '259585',
                $options
                );        
            
        }
    }
    
    static function send($message,$topic='livechanges',$sub='events'){
        self::init();
        self::$pusher->trigger($topic, $sub, $message);
    }
    
    
    
}



?>