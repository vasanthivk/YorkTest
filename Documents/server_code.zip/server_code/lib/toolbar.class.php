<?php

class toolbar{
    
    static function show($extra=''){
        $ret='<div class="mini-nav row nopad">';
            $ret.='<div class="col s12 m8">';
                $ret.=self::showTopNav($extra);
            $ret.='</div>';
            $ret.=self::showPaging();
        $ret.='</div>';
        $ret.='<div class="pop-line"></div>';
        return $ret;
        
    }
    
    static function showTopNav($extra=''){
        $ret='<a href="#clear" class="bt inv act-search-tools">Clear</a>';
        $ret.='<a href="#my" class="bt act-search-tools">Assigned</a>';
        $ret.='<a href="#created" class="bt act-search-tools">Created</a>';
        $ret.='<a href="#updated" class="bt act-search-tools">Updated</a>';
        $ret.=$extra;
       return $ret; 
    }
    
    static function extra($title,$class='',$href=''){
        $ret='<a href="#'.$href.'" class="bt act-search-tools '.$class.'">'.$title.'</a>';
        return $ret;
        
    }
    
	static function showPaging(){
	    $ret='<div class="col s12 m4 right-align">';
	    $ret.='<i class="material-icons">view_list</i>';
	        $ret.='<small class="targ-rowcount"></small>';
	        $ret.='<a href="#down" class="act-page"><i style="vertical-align:middle;" class="material-icons">chevron_left</i></a>';
	        $ret.='<span id="ctrl-page-no" contenteditable=true>1</span> /';
	        $ret.='<span id="ctrl-page-max">1</span>';
	        $ret.='<a href="#up" class="act-page"><i class="material-icons">chevron_right</i></a>';
	    $ret.='</div>';
	    return $ret;
	}


    
    
    
}


?>