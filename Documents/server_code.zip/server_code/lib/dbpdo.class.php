<?php


class dbpdo{

	private static $instance;
	private static $dbsetting='database';
	private static $lastRows=0;
	private static $lastError='';
	private static $bulkLoad='';
	
	static function getSet($name){
	    $settings=settings::getSettings('database');
	    //$settings=settings::remoteDbSettings('/mnt/stor8-wc2-dfw1/478117/code.clevertech.tv/web/content/cxx/workspace/profiles/settings/_settings.php');
	    return $settings[$name];
	}
	
	static function setDB($inDb='database'){
	    self::$dbsetting=$inDb;
	    self::loadInstance(true);
	    debug::add('DB Change',$inDb);
	}

	static function loadInstance($reload=false){
    	if(!isset(self::$instance) or $reload){  
    		debug::add('PDO Info','Loading Instance');
    		$host=self::getSet('hostname');
    		$dbname=self::getSet('dbname');
			debug::add('db name',$dbname);
			try {
			    self::$instance = new PDO("mysql:host=$host;dbname=$dbname", self::getSet('username'), self::getSet('password'));
			} catch (PDOException $e) {
				debug::add('PDO Connection error',$e->getMessage());
				echo $e->getMessage();
			    die();
			}
        return self::$instance;
    	}else{
    		debug::add('PDO Info','Instance pre loaded');
    	}
	}
	
	
	public static function tables(){
	    $sql='show tables';
	    if($stmt=dbpdo::query($sql)){
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			    print_r($row);
			}
	    }
	    

	}



    public static function query($sql,$parms=array()){
		self::loadInstance();
		self::debugSql($sql,$parms);
		if(!self::validateSQL($sql,$parms)){return false;}
		$stmt = self::$instance->prepare($sql);
		return self::runStatement($sql,$stmt,$parms,'Prepared completed');

    }

    public static function getQuery($sql,$parms=array()){
 		self::loadInstance();
		self::debugSql($sql,$parms);
		$stmt = self::$instance->prepare($sql);
		if(self::runStatement($sql,$stmt,$parms,'Prepared completed')){
			if($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
	    		return $row;
	  		}else{
	  			debug::add('PDO failed','No rows to return');
	  			return false;
	  		}
		}else{
			debug::add('PDO failed','stmt object not created');
			return false;
		}    
    }
    
    public static function getColumns($sql,$parms=array()){
 		self::loadInstance();
		self::debugSql($sql,$parms);
		$stmt = self::$instance->prepare($sql);
		if(self::runStatement($sql,$stmt,$parms,'Prepared completed')){
            return $stmt;
		}else{
			debug::add('PDO failed','stmt object not created');
			return false;
		}    
    }


    private static function validateSQL($sql,$parm){
		if(strrpos($sql, '"'>0)){
			debug::add('PDO ERROR','Must use prepared statements 1');
			return false;
		}
		if(strrpos($sql, "'">0)){
			debug::add('PDO ERROR','Must use prepared statements 2');
			return false;
		}
		//now split on the wehere statement and check the rest
		$where=explode('where',strtolower($sql));

		if(array_key_exists(1,$where)){
			$toCheck=$where[1];
		}else{
			//$toCheck=$where[0];
			$toCheck='';
		}
		$eqs=explode('=',$toCheck);
		$first=array_shift($eqs);
		$parmCount=0;
		$valueList='';
		foreach($eqs as $value){
			$valueList.=$value.',';
			debug::add($value);
			debug::add(substr($value,0,1));
			if(substr(trim($value),0,1)!=':'){
				debug::add('PDO ERROR','Must use prepared statements 3');
				return false;				
			}
			$parmCount++;
			
		}
		debug::add('Value List ',$valueList);
		if(stripos($sql, "insert into"===0)){
			if($parmCount!=sizeof($parm)){
				debug::add('PDO ERROR','Parameter count mismatch '.sizeof($parm).' passed, expecting '.$parmCount);
				return false;		
			}
		}
		return true;
    }



    public static function dbUpdate($table,$ref,$fields,$key='ref',$reason='',$trackChanges=true){
        self::loadInstance();
        $parm=array(':ref'=>$ref);
    	$sql='select * from '.$table.' where '.$key.'=:ref limit 1';
    	$data=dbpdo::getQuery($sql,$parm);
    	$changes=array();
    	foreach($data as $akey=>$value){
    		if(array_key_exists($akey,$fields)){
    			if(strip_tags($fields[$akey])!=strip_tags($value)){
    				$changes[$akey]=$value;
    			}
    		}
    	}
    	if(sizeOf($changes)>0){
    		$backup=json_encode($changes);
    	}else{
    		$backup='';
    	}
        $sql='update '.$table;
        $sql.=' set ';
        $partSql='';
        
        if($table=='hshshchanges'){
            $fields['date_modified']=dbpdo::now();
            $fields['modified_user_id']=h::safeArray($_SESSION,'user','ref');
        }
        
        foreach($fields as $fieldName=>$value){
            $partSql.=' '.$fieldName.'=:'.$fieldName.',';
            debug::add($fieldName,$value);
        }
        $fields['passedRef']=$ref;
        $partSql=substr($partSql,0,-1);
        $sql.=$partSql.' where '.$key.'=:passedRef limit 1;';
        debug::add('sql',$sql);
        //echo $sql;
        $stmt = self::$instance->prepare($sql);
        self::runStatement($sql,$stmt,$fields,'Update Completed');
        if($trackChanges){
            self::logChanges($table,$ref,$mode='update',$reason,$backup);
        }

    }

    public static function fieldsFromPost($valid){
    	//pull valid field values from the post array
    	$retArr=array();
    	foreach($valid as $name){
    		if(clean::post($name)!=''){
    			$retArr[$name]=clean::post($name);
    		}
    	}
    	return $retArr;
    }

     public static function dbInsert($table,$fieldList,$reason='',$trackChanges=true,$simpleRef=false){
        self::loadInstance();
        $sql='insert into '.$table.' ';
        log::logInfo($fieldList);
        if(h::safeArray($fieldList,'ref')=='New'){
            unset($fieldList['ref']);
            $simpleRef=true;
        }
//        if(!array_key_exists('ref',$fieldList) and !$simpleRef){
        if(!$simpleRef){
            $fieldList['ref']=self::createKey();
        }
       
        if($table=='hshshchanges'){
            $fieldList['date_entered']=dbpdo::now();
            $fieldList['created_by']=$_SESSION['user']['ref'];
            $fieldList['date_modified']=dbpdo::now();
            $fieldList['modified_user_id']=h::safeArray($_SESSION,'user','ref');

        }
        $fields='(';
        $values='(';
        foreach($fieldList as $fieldName=>$value){
            debug::add($fieldName,$value);
            $fields.=$fieldName.',';
            $values.=':'.$fieldName.',';
        }
        $fields=substr($fields,0,-1).')';
        $values=substr($values,0,-1).')';
        
        $sql.=$fields.' values '.$values;
        debug::add('PDO sql',$sql);
        $stmt = self::$instance->prepare($sql);
        self::runStatement($sql,$stmt,$fieldList,'Insert Completed');
        $insertRef=self::$instance->lastInsertId();
        if($trackChanges){
            self::logChanges($table,self::$instance->lastInsertId(),$mode='insert',$reason='');
        }
		return $insertRef;
		
    }

    public static function dbDelete($table,$ref,$refField='ref',$reason='', $trackChanges=true){
    	self::loadInstance();
    	$parm=array('ref'=>$ref);
    	$sql='select * from '.$table.' where '.$refField.'=:ref limit 1';
    	$data=dbpdo::getQuery($sql,$parm);
    	$backup=json_encode($data);
    	//print_r($backup);
    	$sql='DELETE FROM '.$table.' WHERE '.$refField.'=:ref limit 1';
    	$stmt = self::$instance->prepare($sql);
    	self::runStatement($sql,$stmt,$parm,'Delete Completed');
    	if($trackChanges){
    		self::logChanges($table,$ref,$mode='delete',$reason='',$backup);
    	}
    }
    
    public static function dbMultiDelete($table,$ref,$refField='ref',$reason=''){
    	self::loadInstance();
    	$parm=array('ref'=>$ref);
    	$sql='select * from '.$table.' where '.$refField.'=:ref';
    	$data=dbpdo::getQuery($sql,$parm);
    	$backup=json_encode($data);
    	print_r($backup);
    	$sql='DELETE FROM '.$table.' WHERE '.$refField.'=:ref';
    	$stmt = self::$instance->prepare($sql);
    	self::runStatement($sql,$stmt,$parm,'Delete Completed');
    	self::logChanges($table,$ref,$mode='delete',$reason='',$backup);


    }

    
    public static function lastRows(){
        return self::$lastRows;
    }
    
    public static function lastError(){
        return self::$lastError;
    }

    private static function runStatement($sql,$stmt,$fields,$text){
 		self::$lastRows=0;
 		$lastError='';
 		$start=microtime();
 		if ($stmt->execute($fields)) {
		  debug::add('PDO'.$text.' Rows affected',$stmt->rowCount());
		  self::$lastRows=$stmt->rowCount();
		  debug::addDB($sql,$fields,'OK',$stmt->rowCount(),microtime()-$start);
		  return $stmt;
		}else{
			$error=$stmt->errorInfo();
			debug::addDB($sql,$fields,'ERROR '.$error[2],0,microtime()-$start);
			debug::add('PDO ERROR',$error[2]);
			self::$lastError=$error[2];
			debug::add('PDO SQL',$sql);
			log::logInfo('PDO ERROR '.$error[2]);
			slack::message('PDO Error '.$error[2],'#debug');
			return false;
		}   	
    }

    private static function debugSql($sql,$parms){
    	$retVal=$sql;
    	if(sizeof($parms)>0){
	    	foreach($parms as $key=>$value){
	    		$retVal=str_ireplace($key, "'".$value."'", $retVal);
	    	}    		
    	}

    	debug::add('SQL Debug',$retVal);

    }

    private static function shortPath(){
    	$pi=pathinfo(__FILE__);
    	$dn=explode('\\',$pi['dirname']);
    	$f=array_pop($dn);
    	$ret=implode('\\',$dn);
    	return $ret;
    	
    }
	public static function openSession($cmsprefix=''){
		session_name($cmsprefix.settings::getSettings('project','sessionname'));
		@session_start();
	}
	public static function now($offset=''){
		if($offset!=''){
		    return date('Y-m-d H:i:s',strtotime($offset));   
		}else{
		    return date('Y-m-d H:i:s');
		}
	}
	
	public static function dbDate($inTime){
	    return date('Y-m-d H:i:s',$inTime);    
	}
	
	public static function usaDate($inTime,$showTime=false){
	    if($inTime==''){
	        $inTime=time();
	    }
	    if($inTime=='0000-00-00 00:00:00' || $inTime=='0000-00-00'){
	        //if($showTime){
	        //    return '00/00/0000&nbsp;00:00';    
	        //}else{
	        //    return '00/00/0000';
	        //}
	        return '';
	    }else{
    	    $format='m/d/y';
    	    $pre='';
    	    if(!is_numeric($inTime)){
    	        $inTime=strtotime($inTime);
    	    }
    	    if(date($format,$inTime)==date($format)){
    	        $format='';
    	        $pre='Today ';
    	    }
    	    if($showTime){
    	        $ret=$pre.date($format,$inTime);
    	        $ret.='&nbsp;<b>'.date('g:i',$inTime).'&nbsp;'.date('a',$inTime).'</b>';
    	        return $ret;   
    	    }else{
    	        return $pre.date($format,$inTime);    
    	    }
	        
	    }
	}


    public static function dbInsertUpdate($table,$ref,$fields,$refField='ref',$insertFunction=''){
        self::loadInstance();
		$parms=array(':ref'=>$ref);
		$sql="select * from $table where $refField=:ref limit 1";
		$stmt=dbpdo::query($sql,$parms);
		if ($stmt) {
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
	    	if($row[$refField]>0){
	    		self::dbUpdate($table,$ref,$fields);
			}else{
				if($insertFunction!=''){
					$fields=call_user_func($insertFunction,$fields);
				}
				self::dbInsert($table,$fields);
			}
		}
		return self::$instance->lastInsertId();
	}
	
	
    static function logChanges($table,$ref,$mode='insert',$reason='',$backup=''){
    	if($table!='changes' && $table!='history' && $table!='stars'){
	    	$user=loginsimple::getUser('ref');
		    $fields=array(
		        'tablename'=>$table,
		        'tableref'=>$ref,
		        'mode'=>$mode,
		        'timeupdated'=>self::now(),
		        'reason'=>$reason,
		        'updatedby'=>$user,
		        'backup'=>$backup
		        );
		        self::dbInsert('changes',$fields);
    	}
	}
	
	static function createKey(){
	    //create unique key based on logged in user email and php uniq funtion
	    $email=h::safeArray($_SESSION,'user','email');
	    if($email==''){
	        $email=uniqid('email',true);
	    }
	    return md5($email.uniqid('x',true));
	    
	}


    public static function clearBulkSQL(){
        self::$bulkLoad='';
    }
    public static function buildBulkSQL($values){
        self::$bulkLoad.='('.$values.'),';
    }
    public static function runBulkSQL($table,$fields=array()){
        if(self::$bulkLoad!=''){
            $sql='INSERT INTO '.$table.' (';
            foreach($fields as $key){
                $sql.=$key.',';
            }
            $sql=substr($sql, 0, -1);        
            $sql.=') VALUES ';
            $sql.=substr(self::$bulkLoad, 0, -1);
            self::query($sql);
        }
    }
    
    
    
}



?>