<?php


class menu{
	
	function products(){
		$sql='select * from  _productsdl';
		//$parms=array(':company'=>'David Lloyd');
		if($stmt=dbpdo::query($sql)){
    		while($row = $stmt->fetch()){
    			echo '<li class="menu-drag-item" data-barcode="'.$row['barcode_number'].'">';
    				echo $row['product_title'];
    			echo '</li>';
    			//print_r($row);
    		}
		}

		
	}
	
	function show(){
		$sql='SELECT _productsdl.barcode_number,menu,submenu,description,product_title
FROM _productsdl
left join menu_products on (_productsdl.barcode_number = menu_products.barcode_number)
left join menu on (menu.ref=menu_products.menu_ref)
order by product_title asc';
		//$parms=array(':company'=>'David Lloyd');
		$ret=array();
		if($stmt=dbpdo::query($sql)){
    		while($row = $stmt->fetch()){
    			$ret[$row['menu']][$row['submenu']][]=$row;
    		}
		}
		//print_r($ret);
		foreach($ret as $key=>$submenu){
			if($key!=''){
				echo '<h2 class="menu">'.$key.'</h2>';
				echo '<div class="sortit"></div>';
				foreach($submenu as $title=>$items){
					echo '<h4 class="submenu">'.$title.'</h4>';
					echo '<div class="sortit">';
					foreach($items as $item){
		    			echo '<span class="menu-sort-item" data-barcode="'.$item['barcode_number'].'">';
		    				echo $item['product_title'];
		    			echo '</span>';
					}
					echo '</div>';
				}

			}
			
		}
		
	}
	
	
}

?>