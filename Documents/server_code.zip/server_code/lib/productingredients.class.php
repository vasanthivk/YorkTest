<?php

class productingredients
{
	
	private static $reader;
    private static $count = 0;
    
    public static function initialise($filepath=''){
    	
    	self::$reader = new XMLReader(); // initialize
    	
    	if ($filepath != ''){
            self::$reader->open( $filepath ); // open file
    	}
    }
    
    public static function splitOutAndStoreProductIngredients($filepath)
    {
 	 	self::initialise($filepath);
        
        while(self::$reader->read())
        {
            if( self::$reader->nodeType == XMLReader::ELEMENT 
                &&  self::$reader->name == 'Product')
              {
                $doc = new DOMDocument('1.0', 'UTF-8');
                $xml = simplexml_import_dom($doc->importNode(self::$reader->expand(),true));
                
                switch(self::getUpdateType()){
                	case 'AddOrUpdate':
                		 self::addOrUpdate($xml);
                		break;
                    case 'Delete':
                    	self::markIngredientsAsDeleted($xml);
                    	break;
                    default:
                    	
                }
            }
        }
    }
    
    private static function addOrUpdate($xml){
    	$vals = self::getBarcodeAndIngredientsFromXml($xml);

    	$strIngredients = self::returnAsDelimitedString(self::checkForNullObject($vals['ingredients'], 'Text'));
    	$ingredients = explode(',', $strIngredients);
    
	    $count=1;
	         
	    foreach($ingredients as $ingredient){
    		$ingredientName = trim(self::removePercentage($ingredient));
	        $fieldlist=array('product_barcode'=>self::checkForEmptyValue($vals['barcode']),
   		      'name' => $ingredientName,
   		      'percentage' => trim(self::extractPercentage($ingredient)),
   		      'order_of_amount' => $count,
	           );
	           
	           if($fieldlist['name'] != 'Not Found'){
			   
				$ingredientRow = self::getProductIngredient($fieldlist, $ingredientName);
			    $count++;
			     if($ingredientRow==null){
			     	 $fieldlist['ref'] = productimportutil::randomString();
			     	 $fieldlist['date_entered']=dbpdo::now();
			//     	 echo var_dump($fieldlist); exit;
			     	 $ref=dbpdo::dbInsert('_product_ingredients', $fieldlist, '', false, true);
			    //  	 log::logInfo( 'Added product ingredient: ' . $fieldlist['product_barcode']);
			 		 //echo 'Added product ingredients: ' . $fieldlist['product_barcode'] . "\n";
			     }else{
				     $fieldlist['date_modified']=dbpdo::now();
					 dbpdo::dbUpdate('_product_ingredients',$ingredientRow['ref'],$fieldlist, 'ref', '', false);
				//	 log::logInfo( 'Updated product ingredient: ' . $fieldlist['product_barcode']);
				//	 echo 'Updated product ingredients: ' . $fieldlist['product_barcode'] . "\n";
			     }      
	        }
    	}
    }
    
    public static function recordExists($table, $ref,$refField){
    	$sql = 'SELECT * FROM ' . $table . ' WHERE ' . $refField. ' = :ref LIMIT 1';
    	$params = [':ref' => $ref];
    	$recordExists = false;
    
    	if ($stmt=dbpdo::query($sql, $params)) {
    		$count = $stmt->rowCount();
    		if($count > 0){
    			$recordExists=true;
    		}
    	}
    	
     	return $recordExists;
    	
    }

    public static function markIngredientsAsDeleted($xml){
    	$fields=array();
	    $fields['deleted']='Yes';
	    $fields['date_deleted']=dbpdo::now();
	    $fields['date_modified']=dbpdo::now();
    	$barcode = self::getNodeValueForAttribute($xml->Identity->ProductCodes->Code, 'Scheme', 'GTIN');

	    if($barcode !=''){
	    		$sql = 'SELECT * FROM _product_ingredients WHERE product_barcode = :barcode';
	    		$params = [':barcode'=>$barcode];
	    		if ($stmt=dbpdo::query($sql, $params)) {
				    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
				        dbpdo::dbUpdate('_product_ingredients',$row['ref'],$fields,'ref','',false);
		    			// log::logInfo('Marked product ingredient: ' . $row['name'] . ' as deleted.');
		    			// echo 'Marked product ingredient: ' . $row['name']  . ' as deleted.' . "\n";
				    }
				}

    	}
    }
    
    private static function deleteIngredient($xml){
    	$barcode = self::getNodeValueForAttribute($xml->Identity->ProductCodes->Code, 'Scheme', 'GTIN');
    	$ret=false;
    	if($barcode != ''){
    		$sql = 'DELETE FROM _product_ingredients WHERE product_barcode = :barcode';
    		$params = [':barcode'=>$barcode];
	    		if($stmt=dbpdo::query($sql, $params)){
						$ret = true;
			 	}
    		// log::logInfo('Deleting product ingredients for product: ' . $barcode);
    		// echo 'Deleting product ingredients for product: ' . $barcode . "\n";
    	}
    	return $ret;
    }
    
    private static function randomString( $length = 16 ) {
	    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	    $max = strlen($chars)-1;
	    $str='';
	    for ($i = 0; $i < $length; $i++) {
			$str .= $chars[mt_rand(0, $max)];
		}
	    return $str;
	}
    
    private static function getProductIngredient($ingredient, $ingredientName){

		$sql = "SELECT * FROM _product_ingredients WHERE product_barcode = :product_barcode AND name = :name limit 1";

		$params = [':product_barcode' => $ingredient['product_barcode'], ':name' => $ingredientName];
		$ret = null;
	 
		 if($stmt=dbpdo::query($sql, $params)){
			if($stmt->rowCount() > 0){
				$ret = $stmt->fetch();
			}
		 }
		return $ret;
    }
    
    public static function printout($filepath=''){
   	 	self::initialise($filepath);
    	  
         while(self::$reader->read())
         {
            if( self::$reader->nodeType == XMLReader::ELEMENT 
                &&  self::$reader->name == 'Product')
              {
                $doc = new DOMDocument('1.0', 'UTF-8');
                $xml = simplexml_import_dom($doc->importNode(self::$reader->expand(),true));
   
               if(self::getUpdateType() != 'Delete'){
                	self::printToScreen($xml);
                }
                self::$count++;
              }
              
        }
          echo 'Product count (including deletes): ' . self::$count . "\n";
    }
    
    public static function printToScreen($xml){
   		$vals = self::getBarcodeAndIngredientsFromXml($xml);
   		$ingredients = self::returnAsDelimitedString(self::checkForNullObject($vals['ingredients'], 'Text'));
   		if($ingredients != 'Not Found'){
	       echo '<b>Barcode: </b>' . self::checkForEmptyValue($vals['barcode']) . '<br/>';
	       echo '<b>Ingredients: </b>' . $ingredients . '<br/>';
   		}
    }
    
    public static function printToCli($xml){
   		$vals = self::getBarcodeAndIngredientsFromXml($xml);
   		$ingredients = self::returnAsDelimitedString(self::checkForNullObject($vals['ingredients'], 'Text'));
   		if($ingredients != 'Not Found'){
	       echo '<b>Barcode: </b>' . self::checkForEmptyValue($vals['barcode']) . "\n";
	       echo '<b>Ingredients: </b>' . $ingredients . "\n";
   		}
    }
    
    private static function getBarcodeAndIngredientsFromXml($xml){
    	$barcode=self::getNodeValueForAttribute($xml->Identity->ProductCodes->Code, 'Scheme', 'GTIN');
    	$ingredients=self::getIngredients($xml);
    	
    	return array('barcode'=>$barcode, 'ingredients'=>$ingredients);
    }
    
    private static function extractPercentage($ingredient){
		$percentageRegEx = '/\([+-]?(\d*\.)?\d+%\)/';
		$ret='n/a';
    	  
    	$match = preg_match($percentageRegEx, $ingredient, $matches, PREG_OFFSET_CAPTURE);
    	
    	if ($match){
    		$ret = $matches[0][0];
    	}
    	  return $ret;
    }
    
    private static function removePercentage($ingredient){
    	$percentageRegEx = '/\([+-]?(\d*\.)?\d+%\)/';
    	$ret = $ingredient;
    	
    	 $match = preg_match($percentageRegEx, $ingredient);
    	 
    	 if($match){
    	 	$ret = preg_replace($percentageRegEx, '', $ingredient);
    	 }
    	
    	return $ret;
    }
    
    public static function getUpdateType()
    {
	   return self::$reader->getAttribute('UpdateType');
    }
       
     /* Where you have several nodes with different attribute values
       e.g.
       <Code Scheme="GTIN">5000237111994</Code>
       <Code Scheme="BRANDBANK:PVID">3796187</Code>
       
       this method lets you get the node value of the attribute you want.
       
       @arg $domElements - the dom element of the nodes
       @arg $attributeName - the name of the attribute you want to get the node value for.
       @arg $attributeValue - the value of the attribute you want to get the node value for.
    */
    
    private static function getNodeValueForAttribute($domElements, $attributeName, $attributeValue){
    	 if (is_array($domElements) || is_object($domElements))
    	 {
            foreach($domElements as $elem) { 
                if($elem[$attributeName]==$attributeValue){
                    return $elem;
                }
            }
    	}
    }
    
    private static function getIngredients($xml){
    	$ingredients = self::getNodeValueForAttribute($xml->Data->Language->ItemTypeGroup->LongTextItems, 'Name', 'Ingredients');
    	
    	if(is_null($ingredients) & self::xmlChildExists($xml->Data->Language->Part->ItemTypeGroup)){
    			$ingredients = self::getNodeValueForAttribute($xml->Data->Language->Part->ItemTypeGroup->LongTextItems, 'Name', 'Ingredients');
    	}
    	return $ingredients;
    }
    
    
    public static function testRegex(){
    
    	$ingredient = 'Purple Chantenay Carrot (20%)';
    	  
    	echo 'Ingredient: ' . self::removePercentage($ingredient) . "\n";
    	
    	echo 'Percentage: ' . self::extractPercentage($ingredient);
    }
    
    private static function checkForEmptyValue($val){
        if(isset($val)){
            return $val;
        }else{
            return 'Not Found';
        }
    }
    
    private static function returnAsDelimitedString($domElements, $delimiter=', '){
        $ret='';
        $count=0;
        
        if(is_string($domElements)){
        	return $domElements;
        }
        
         if (is_array($domElements) || is_object($domElements))
         {
	           foreach($domElements as $elem) { 
	             $ret .= $elem;
	             if($count < sizeOf($domElements)-1){
	                $ret .= $delimiter;
	             }
	             $count++;
	        	}
         }
        return $ret;
    }
    
    private static function xmlChildExists($elem)
	{
	 	return isset($elem);
	}
	
	private static function checkForNullObject($obj, $prop){
        if(is_null($obj)){
            return 'Not Found';
        }else{
            return $obj->$prop;
        }
    }

}