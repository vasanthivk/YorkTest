<?php



class soap{
    
    
    static $lastRequest='';
    const BRANDBANK_API = 'live_guid';
    
    
    static function build(){
    	//echo file_get_contents("https://api.brandbank.com/svc/feed/extractdata.asmx");
		//die();
		
		$data = file_get_contents('https://api.brandbank.com/svc/feed/extractdata.asmx');
		print_r($data);
		$file = 'data://text/plain;base64,'.base64_encode($data);
		
		
		
        $client = new SoapClient($file,array("soap_version" => SOAP_1_1,'trace' => true));
        $client->namespaces = array(
                'xmlns:soap'=>"http://www.w3.org/2003/05/soap-envelope",
                'xmlns:ns'=>"http://www.i-label.net/Partners/WebServices/DataFeed/2005/11"
        );
        $ns='http://www.i-label.net/Partners/WebServices/DataFeed/2005/11';
        $GUID=settings::getSettings('brandbank',soap::BRANDBANK_API);
        $headerbody = array('ExternalCallerId' => $GUID); 
        $header = new SOAPHeader($ns, 'ExternalCallerHeader', $headerbody);        
        $client->__setSoapHeaders($header); 
        return $client;
    }
    
    static function GetUnsentProductData(){
        $client=self::build();
        $startTime=time();
        slack::message('Start GetUnsentProductData '.date('h:i:s',time()),'#brandbank');
        try {
            $response=$client->GetUnsentProductData();
            self::$lastRequest=htmlentities($client->__getLastRequest());
            $size=strlen($response->GetUnsentProductDataResult->any);
            slack::message('Download Complete '.$size.' '.date('h:i:s',time()),'#brandbank');
            return $response->GetUnsentProductDataResult->any;
        }
        catch (SoapFault $soapFault) {
            soap::showErrors($soapFault,$client);
        }
        
    }
    
    static function AcknowledgeMessage($lastMessageId){
        $client=self::build();
        try {
            $parms=array('messageGuid'=>$lastMessageId);
            $response=$client->AcknowledgeMessage($parms);            
            self::$lastRequest=htmlentities($client->__getLastRequest());
            return $response;
        }
        catch (SoapFault $soapFault) {
            soap::showErrors($soapFault,$client);
        }
    }
    
    
    static function showErrors($soapFault,$client){
        var_dump($soapFault);
        echo "Request :<br>", htmlentities($client->__getLastRequest()), "<br>";
        echo "Response :<br>", htmlentities($client->__getLastResponse()), "<br>";
    
    }

    public static function doXMLCurl($url,$postXML){
	    $CURL = curl_init();
	
	    curl_setopt($CURL, CURLOPT_URL, $url); 
	    curl_setopt($CURL, CURLOPT_HTTPAUTH, CURLAUTH_BASIC); 
	    curl_setopt($CURL, CURLOPT_POST, 1); 
	    curl_setopt($CURL, CURLOPT_POSTFIELDS, $postXML); 
	    curl_setopt($CURL, CURLOPT_HEADER, false); 
	    curl_setopt($CURL, CURLOPT_SSL_VERIFYPEER, false);
	    curl_setopt($CURL, CURLOPT_HTTPHEADER, array('Accept: text/xml','Content-Type: text/xml'));
	    curl_setopt($CURL, CURLOPT_RETURNTRANSFER, true);
	    $xmlResponse = curl_exec($CURL); 
	
	    return $xmlResponse;
	}
    
}



?>