<?php


class chart{
    
    
    static function buildData($inArr){
        $ret=array();
        $ret['titles']='';
        $ret['data']='';
        foreach($inArr as $key=>$item){
            if($key==''){
                $key='blank';
            }
            $ret['titles'].=$key.',';
            $ret['data'].=$item.',';
        }
        $ret['titles']=rtrim($ret['titles'],',');
        $ret['data']=rtrim($ret['data'],',');
        return $ret;
    }
    
    
    static function getPieData($labels='red,blue,green',$data='',$bgColor='00f2e6,e4f3f7,303030',$hoverColor='FF6384,36A2EB,FFCE56'){
        $ret='{
            labels: [
                '.self::qList($labels).'
            ],
            datasets: [
                {
                    data: ['.$data.'],
                    backgroundColor: [
                        '.self::qList($bgColor,'#').'
                    ],
                    hoverBackgroundColor: [
                        '.self::qList($hoverColor,'#').'
                    ]
                }]
        };';  
        return $ret;
    }
    
    static function qList($inList,$prefix=''){
        $ll=explode(',',$inList);
        $op='';
        foreach($ll as $l){
            $op.='"'.$prefix.$l.'",';
        }
        $op=rtrim($op,',');
        return $op;
    }
    
    
}



?>