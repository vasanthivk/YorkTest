<?php



class forms{
    
    
    static function field($name,$label,$value='',$placeholder='',$col=12,$class=''){
        $ret='';
        $ret.='<div class="input-field col s'.$col.'">';
          $ret.='<input placeholder="'.$placeholder.'" id="'.$name.'" name="'.$name.'" type="text"  class="'.$class.'" value="'.$value.'"/>';
          $ret.='<label for="'.$name.'" class="active">'.$label.'</label>';
        $ret.='</div>';
        return $ret;
        
    }
    
    static function textarea($name,$label,$value='',$placeholder='',$col=12){
        $ret='';
        $ret.='<div class="input-field col s'.$col.'">';
          $ret.='<textarea id="'.$name.'" placeholder="'.$placeholder.'">'.$value.'</textarea>';
          $ret.='<label for="'.$name.'" class="active">'.$label.'</label>';
        $ret.='</div>';
        return $ret;
        
    }
    
    static function checkbox($name,$label,$col=12){
    	$ret='<div class="input_field col s'.$col.'">';
    		$ret.='<input type="checkbox" id="'.$name.'" />';
      		$ret.='<label for="'.$name.'">'.$label.'</label>';
      	$ret.='</div>';
      	return $ret;
    }
    
    static function select($name,$label,$items,$value='',$placeholder='',$col=12){
        $itemList=explode(',',$items);
        $ret='<div class="input-field col s'.$col.'">';
        $ret.='<select id="'.$name.'" name="'.$name.'">';
            foreach($itemList as $item){
                $ret.='<option value="'.$item.'">'.$item.'</option>';
            }
        $ret.='</select>';
        $ret.='<label>'.$label.'</label>';
        $ret.='</div>'; 
        return $ret;
    }




    static function hidden($name,$value=''){
		if($value==''){
		    $val=self::safeKey($name,self::$row);
		}else{
		    $val=$value;
		}
		$ret='<input  value="'.$val.'"  id="'.$name.'" name="'.$name.'" type="hidden" >';
		return $ret;

    }
    
    static function safeKey($key,$array){
    	if(is_array($array)){
    		if(array_key_exists($key,$array)){
    			return $array[$key];
    		}else{
    			return '';
    		}
    	}else{
    		return '';
    	}
    }
    
    static function unHash($encrypted){
    	//decrypt the hash string..grab the hash and any other data then also sheck the time for timeout
        $hash=self::decrypt($encrypted);
        debug::add('decrypted',$hash);
        list($table,$ref,$xss,$time)=explode(':',$hash);
        if(!self::checkXss($xss)){
            debug::add('xss mismatch');
            //die('hash issue');
        }
        $tdiff=time()-$time;
        debug::add('Hash time gap',$tdiff);
        if($tdiff>1200){
            debug::add('form timeout');
            secure::redirect('../login/login.php');
            die('hash issue.');
            
        }
        debug::add('tdiff',$tdiff);
        return array('table'=>$table,'ref'=>$ref);
    }
    
    static function ajaxHash($tableName='',$ref=''){
        $hash=self::buildHash($tableName,$ref);
        return '<div id="hash" class="qitem hide">'.$hash.'</div>';
    }
    
    static function showHash($tableName='',$ref=''){
        $hash=self::buildHash($tableName,$ref);
        return '<input type="hidden" name="hash" id="hash" class="hide" value="'.$hash.'"/>';
    }
    
    static function buildHash($tableName='',$ref=''){
        $xss=self::getXss();
        $toHash=$tableName.':'.$ref.':'.$xss.':'.time();
        debug::add('Raw table hash',$toHash);
        $encrypted=self::encrypt($toHash);
        debug::add('encrypted',$encrypted);
        return $encrypted;
        
    }

  
    static function checkXss($xss){
        if($_SESSION['xss']==$xss){
            debug::add('XSS Check OK');
            return true;
        }else{
            return false;
        }
    }
    
    
    static function getXss(){
        if(array_key_exists('xss',$_SESSION)){
            debug::add('xss picked from session',strlen($_SESSION['xss']));
            if(strlen($_SESSION['xss'])==50){
            }else{
                $_SESSION['xss']=self::generateRandomHexString(50);    
            }
        }else{
            $_SESSION['xss']=self::generateRandomHexString(50);   
        }
        return $_SESSION['xss']; 
    }
    
    
    static function generateRandomHexString($length) {
    	return substr(bin2hex(openssl_random_pseudo_bytes(ceil($length / 2))), 0, $length);
    }
    
    static function randomPin(){
        $hex=self::generateRandomHexString(8);
        $dec=hexdec($hex);
        return substr($dec,0,6);
    }
    
	static function encrypt($data){
	    $key=settings::getSettings('database','password');
	    $iv = mcrypt_create_iv(16, MCRYPT_RAND);
		$enc = openssl_encrypt($data, 'AES-256-CBC', $key,0,$iv);
		return base64_encode($iv.$enc);
	}
	
	static function decrypt($encrypted){
	    $wrap=base64_decode($encrypted);
	    $iv = substr($wrap, 0, 16);
	    $data=substr($wrap, 16);
	    $key=settings::getSettings('database','password');
	    return openssl_decrypt($data,'AES-256-CBC',$key,0,$iv);
	}


    
    
    
}


	?>