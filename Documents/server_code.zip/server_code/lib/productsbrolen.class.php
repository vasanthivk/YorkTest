<?php



class products{
	
	static $data=array();
	
	static function getBarcode($barcode,$email='...',$latLong='',$sliders='',$profileRef=-1){
		$miniCode=$barcode;
		$miniCode+='0';
		$table='_products_import2';
		$leftTwo=substr($barcode,0,2);
		switch($leftTwo){
			case '02':
	    	    $sql='select * from '.$table.' where barcode_number = :barcode limit 1';
	    	    $leftCode=substr($barcode,0,6);
	    	    $newCode=$leftCode.'000000';
	    	    $final=self::ean13_check_digit($newCode);
	    	    $parms=array(':barcode'=>$final);
				break;
			case '23':
	    	    $sql='select * from '.$table.' where barcode_number like :barcode limit 1';
	    	    $leftCode=substr($barcode,0,8);
	    	    $parms=array(':barcode'=>$leftCode.'%');
				
				break;
			case '20':
	    	    $sql='select * from '.$table.' where barcode_number like :barcode limit 1';
	    	    $leftCode=substr($barcode,0,6);
	    	    $parms=array(':barcode'=>$leftCode.'%');
				
				break;
			default:
	    	    $sql='select * from '.$table.' where barcode_min=:minicode limit 1';
	    	    $parms=array(':minicode'=>$miniCode);
				
				break;
		}
		
		
		

	        
	    if($data=dbpdo::getQuery($sql,$parms)){
            $ret=self::translateFields($data,$barcode);
            self::logScan($email,$barcode,$latLong,'Yes',$sliders,$profileRef,$data['barcode_number']);
    	    $referer=h::sa($_SERVER,'HTTP_REFERER');
    	    push::send($barcode.'|'.$ret['title'].'|'.$latLong.'|'.$email.'|'.$profileRef);
    	    return json_encode($ret);
	    }else{
	    	$sql='select * from _productsx where barcode_number=:bcode limit 1';
	    	$parms=array(':bcode'=>$barcode);
	    	if($data=dbpdo::getQuery($sql,$parms)){
	            $ret=self::translateFields($data,$barcode,'cutlery.svg');
	            self::logScan($email,$barcode,$latLong,'Yes',$sliders,$profileRef,$data['barcode_number']);
	    	    $referer=h::sa($_SERVER,'HTTP_REFERER');
	    	    push::send($barcode.'|'.$ret['title'].'|'.$latLong.'|'.$email.'|'.$profileRef);
	    	    return json_encode($ret);

	    	}else{
	    		push::send($barcode.'||'.$latLong.'|'.$email.'|'.$profileRef);
	    		self::logScan($email,$barcode,$latLong,'No',$sliders,$profileRef,$barcode);
	        	return 'failed';
	    	}
	    }
	    
	    
	}
	
	static function  ean13_check_digit($digits){
//first change digits to a string so that we can access individual numbers
$digits =(string)$digits;
// 1. Add the values of the digits in the even-numbered positions: 2, 4, 6, etc.
$even_sum = $digits{1} + $digits{3} + $digits{5} + $digits{7} + $digits{9} + $digits{11};
// 2. Multiply this result by 3.
$even_sum_three = $even_sum * 3;
// 3. Add the values of the digits in the odd-numbered positions: 1, 3, 5, etc.
$odd_sum = $digits{0} + $digits{2} + $digits{4} + $digits{6} + $digits{8} + $digits{10};
// 4. Sum the results of steps 2 and 3.
$total_sum = $even_sum_three + $odd_sum;
// 5. The check character is the smallest number which, when added to the result in step 4,  produces a multiple of 10.
$next_ten = (ceil($total_sum/10))*10;
$check_digit = $next_ten - $total_sum;
return $digits . $check_digit;
}
	
	static function logScan($email,$barcode,$latLong='',$found='Yes',$sliders='',$profileRef=-1,$altBarcode='...'){
	    $ll=explode(':',$latLong);
	    $fields=array('email'=>$email,
	                'type'=>'barcode',
	                'datakey'=>$altBarcode,
	                'date_created'=>dbpdo::now(),
	                'code_found'=>$found,
	                'latitude'=>h::sa($ll,0),
	                'longitude'=>h::sa($ll,1),
	                'slider_val'=>$sliders,
	                'profile_ref'=>$profileRef,
	                'barcode_number'=>$barcode
	    );
	    dbpdo::dbInsert('scannedcodes',$fields);
	}
	
	static function getCache($table='_productsx'){
	    $sql='select * from '.$table.' order by barcode_number limit 600';
	    $ret=array();
	    if($stmt=dbpdo::query($sql)){
    	    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
    	        $ret[$row['barcode_number']]=self::translateFields($row);
    	    }
	    }
        return json_encode($ret);
	}
	
	static function translateFields($data,$barcode,$holdimage=''){
	    $ret=array();
	    $ret['barcode']=$barcode;
	    $ret['barcode_alt']=$data['barcode_number'];
	    $ret['title']=$data['product_title'];
	    $ret['desc']=$data['regulated_product_name'];
	    //$ret['ingredients']=str_replace('<b>','#',$data['ingredients']);
	    $ret['ingredients']=strip_tags(str_replace('</b>','@',$ret['ingredients'])).'...';
	    //$ret['allergens']=$data['allergy_advice'];//change to contains once populated
	    $ret['allergens']=$data['allergy_contains'];//change to contains once populated
	    
	    //$ret['ingredients'].=$data['allergy_contains'].'...';
	    
	    if(array_key_exists('nutrition_numeric_calories',$data)){
	        $ret['calories']=$data['nutrition_numeric_calories'];    
	    }else{
	        $ret['calories']=$data['nutrition_numeric_energykcal'];
	    }
	    
	    $ret['totalfat']=$data['nutrition_numeric_fat'];
	    $ret['saturatedfat']=$data['nutrition_numeric_satfat'];
	    $ret['cholesterol']=$data['nutrition_numeric_cholesterol'];
	    $ret['salt']=$data['nutrition_numeric_sodium'];
	    $ret['sugar']=$data['nutrition_numeric_sugar'];
	    $ret['protein']=$data['nutrition_numeric_protein'];
	    $ret['carbs']=floatval($data['nutrition_textual_carbohydrate']);
	    $ret['fibre']=$data['nutrition_numeric_fibre'];
	    
	    $ret['contains']=$data['allergy_contains'];
	    $ret['maycontain']=$data['allergy_may'];
	    //if($holdimage!=''){
	    //	$ret['holdimage']=$holdimage;
	   // }
	    return $ret;
	    
	}
	
	static function translateFieldsCompressed($data){
	    $ret=array();
	    $ret['1']=$data['barcode_number'];
	    $ret['2']=$data['product_title'];
	    $ret['3']=$data['regulated_product_name'];
	    $ret['4']=str_replace('<b>','#',$data['ingredients']);
	    $ret['4']=strip_tags(str_replace('</b>','@',$ret['4']));
	    $ret['5']=$data['allergy_advice'];//change to contains once populated
	    
	    $ret['6']=$data['nutrition_numeric_calories'];
	    $ret['7']=$data['nutrition_numeric_fat'];
	    $ret['7']=$data['nutrition_numeric_fat'];
	    $ret['8']=$data['nutrition_numeric_cholesterol'];
	    $ret['a']=$data['nutrition_numeric_sodium'];
	    $ret['b']=$data['nutrition_numeric_sugar'];
	    $ret['c']=$data['nutrition_numeric_protein'];
	    $ret['d']=0;
	    $ret['e']=$data['nutrition_numeric_fibre'];
	    return $ret;
	    
	}
	
	static function compress(){
	    $compArray=array('chicken');
	}

	
	static function printCategory($inCat){
	    $ret='';
	    $sql='select * from products where category=:cat order by title asc';
	    $parms=array(':cat'=>$inCat);
		if($stmt=dbpdo::query($sql,$parms)){
		    while($row = $stmt->fetch()){
		        $ret.='<div class="half">';
		        $ret.='<h5>'.$row['title'].'</h5>';
		        //$ret.='<div class="half">';
		        //$ret.='<img src="../productfiles/'.$row['productref'].'.jpg" alt=""/>';
		        //$ret.='</div>';
		        //$ret.='<div class="half">';

		        $ret.='<div class="barcode">'.$row['barcode'].'</div>';
		        //$ret.='</div>';
		        $ret.='</div>';
		    }
		}else{
		}
return $ret;
	}
	
    static function listProducts(){
	    $sql='select * from products order by category asc,title asc;';
	    $parms=array();

	    $fields='Title,Barcode,Category,Description,Date Added';
	    $ret= table::head ('prod-tbl',$fields);
	    $category='';
	    $buffer='';
	    $cc=0;
		if($stmt=dbpdo::query($sql,$parms)){
		    while($row = $stmt->fetch()){
		        $row['image']='<img style="height:75px;" src="../productfiles/'.$row['productref'].'.jpg" />';
		        if($category!=$row['category']){
		            
		            $ret.=$buffer;
		            $ret.='<tr><td colspan="8"><h5>'.$row['category'].' <small></small></h5></td></tr>';
		            $category=$row['category'];
		            
		            $buffer='';
		            $cc=0;
		        }
		        $buffer.='<tr class="act-drill-down prod-list" data-ref="'.$row['ref'].'">';
		        $buffer.= table::dataRow($row,'title',false);
		        $buffer.='<td><div class="barcode">'.$row['barcode'].'</div></td>';
		        $buffer.= table::dataRow($row,'category,description,setting_vals,date_added,image',false);
		        $buffer.='</tr>';
		        $cc++;
		    }
		}
		$ret.=$buffer;
	    $ret.= table::close();
		return $ret;
    }
	
    static function byBarcode($barcode,$userref=''){
	    $sql='select * from products where barcode=:barcode limit 1';
	    $parms=array(':barcode'=>$barcode);
        $ret=array();
		
		if($row=dbpdo::getQuery($sql,$parms)){
		    $ret=$row;
		}else{
		    slack::message('Scan fail '.$barcode);
		}
		
		if($userref!=''){
    		$fieldList=array('type'=>'barcode',
    		                    'datakey'=>$barcode,
    		                    'userref'=>$userref,
    		                    'latitude'=>0.0,
    		                    'longitude'=>0.0,
    		                    'date_created'=>dbpdo::now());
    		
    		dbpdo::dbInsert('tracking',$fieldList);
		}
		return $ret;
    }
    
    static function byRef($ref){
	    $sql='select * from products where ref=:ref limit 1';
	    $parms=array(':ref'=>$ref);
        $ret=array();
		if($row=dbpdo::getQuery($sql,$parms)){
		    $ret=$row;
		}
		
		return $ret;
        
    }
    
    static function BBgetAll(){
        $ret=array();
        $sql='select product_code,barcode_number,product_title,regulated_product_name,ingredients,setting_vals from _productsx order by barcode_number desc';
        
        $translate=array('product_code'=>'productref',
                        'barcode_number'=>'barcode',
                        'product_title'=>'title',
                        'regulated_product_name'=>'description',
                        'setting_vals'=>'setting_vals',
                        'ingredients'=>'ingredients'
        );
        
        
        
		if($stmt=dbpdo::query($sql)){
		    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		        $sub=array();
		        foreach($row as  $key=>$val){
		            $nkey=$translate[$key];
		            $sub[$nkey]=strip_tags($val);
		        }
		        $ret['b'.$row['barcode_number']]=$sub;
		    }
		}
    	return $ret;
    }

    
    
    static function getAll(){
        $ret=array();
        $sql='select productref,barcode,title,description,ingredients,setting_vals from products order by barcode desc';
		if($stmt=dbpdo::query($sql)){
		    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		        $sub=array();
		        foreach($row as  $key=>$val){
		            $sub[$key]=strip_tags($val);
		        }
		        $ret['b'.$row['barcode']]=$sub;
		    }
		}
    	return $ret;
    }
    
    static function spaceTrim($intext){
        return str_replace('  ','..',$intext);    
    }
    
    
    
    static function valTitles(){
	    $sql='select concat(preferences.name, " / ",preferences_sub.name) as name , preferences_sub.ref,
	            preferences_sub.maxval,preferences_sub.category,preferences_sub.subcategory
	    		from preferences_sub
	    		inner join preferences on (preferences_sub.category=preferences.category)
	    		order by preferences_sub.category asc, preferences_sub.subcategory asc;';
        $simple=array();
    		if($stmt=dbpdo::query($sql)){
    		    while($row = $stmt->fetch()){
            	    $simple[$row['category'].':'.$row['subcategory']]=$row['name'];
    		    }
    		}
    	return $simple;
    }
    	    


}

?>


