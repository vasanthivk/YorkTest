<?php 


class html{
	
	
	static function breaker(){
		return '<div class="breaker">';
	}
	
	static function closediv(){	
		return closediv();
	}
	
	
}


?>