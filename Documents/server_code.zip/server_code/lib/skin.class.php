<?php



class skin{
	
	
	static function getSkin($email){
		$sql='select * from skins where emails like :email limit 1';
		$parms=array(':email'=>$email);
		if($data=dbpdo::getQuery($sql,$parms)){
			$ret=$data['apptitle'].'|';
			$ret.=$data['color1'].'|';
			$ret.=$data['color2'].'|';
			$ret.=$data['logo'];
			return $ret;
		}else{
			return '';
		}
	}
	
	
	
	
}


?>