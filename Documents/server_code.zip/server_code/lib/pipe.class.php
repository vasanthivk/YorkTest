<?php



class pipe{
	
    static function pipeRow($row){
        $ret='';
        foreach($row as $key => $val){
            if(is_numeric($key)){
            }else{
                $ret.=$val.'|';
            }
        }
        $ret.='##';
        return $ret;
    }
}
?>