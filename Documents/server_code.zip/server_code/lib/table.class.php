<?php

class table{
    
    
    static function head($class,$fields='',$start=true){
        if($start){
            $ret='<table class="'.$class.'">';
        }else{
            $ret='';
        }
        $ret.='<tr>';
            $ff=explode(',',$fields);
            foreach($ff as $field){
                $span='';
                if(strpos($field,'|')>0){
                    $arr=explode('|',$field);
                    $field=$arr[0];
                    $span=$arr[1];
                }
                $ret.='<th '.$span.'>'.$field.'</th>';    
            }
        $ret.='</tr>';
        return $ret;
    }
    
    static function dataRow($row,$fields='',$wrap=true){
        if($fields==''){
            foreach($row as $key=>$value){
                $flist[]=$key;
            }
        }else{
            $flist=explode(',',$fields);
        }
        $ret='';
        if($wrap){$ret.='<tr>';}
        foreach($flist as $keys){
            $keyList=explode('|',$keys);
            $key=$keyList[0];
            $class='';
            if(array_key_exists(1,$keyList)){
                $class=$keyList[1];
            }
            $ret.='<td class="'.$class.'">';
                if(substr($key,0,4)!='date' and stripos($key,'_date')===false ){
                    $ret.=$row[$key];   
                }else{
                    $ret.=dbpdo::usaDate($row[$key]);     
                    
                }
                
            $ret.='</td>';
            
        }
        if($wrap){$ret.='</tr>';}
        return $ret;
    }
    
    static function td($item){
        $ret='<td>';
            $ret.=$item;
        $ret.='</td>';
        return $ret;
    }
    
    static function close(){
        $ret='</table>';
        return $ret;
    }    
}


?>