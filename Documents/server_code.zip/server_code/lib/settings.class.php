<?php 
class settings{
	
	private static $settingsArray=array();
	private static $path='';
	
	

	private static function load_settings(){

		$pathinfo=pathinfo(__DIR__);
		if(self::$path==''){
		    debug::add('Loadsettings from','LOCAL');
		    $path=$pathinfo['dirname'].'/settings/_settings.php';
		}else{
		    debug::add('Load settings from ',self::$path);
		    $path=self::$path.'/settings/_settings.php';    
		}
		include $path;
		//debug::add($global_settings);



		self::$settingsArray=$global_settings;
	}
	
	static function setPath($inPath){
	    debug::add('Setting remote path to ',$inPath);
	    self::$path=$inPath;
	    self::load_settings();
	}
	
	static function clearPath(){
	    self::$path='';
	    self::$settingsArray=array();
	}
	
	static function get($section='',$item=''){
	    return self::getSettings($section='',$item='');
	}
	
	static function getSettings($section='',$item=''){
		debug::add('settings request',$section.' '.$item);
		if(sizeof(self::$settingsArray)==0){
		    debug::add('Reloading settings');
			self::load_settings();
		}
		if($item==''){
			return h::safeArray(self::$settingsArray,$section);
		}else{
			return h::safeArray(self::$settingsArray,$section,$item);
		}

	}	

	public static function openSession($cmsprefix=''){
		session_name($cmsprefix.settings::getSettings('project','sessionname'));
		debug::add('session id',session_id());
		session_start();
	}

	static function openSessionFailed($cmsprefix=''){
		$session=$cmsprefix.self::$settingsArray['project']['sessionname'];
		debug::add('Session Starting',$session);
		session_name($session);
		@session_start();
		debug::add('Session Id',session_id());
		debug::add($_SESSION,'session data');
		debug::add('Session Started',$session);
	}

	public static function session($inArr){
		$cArr=$_SESSION;
		foreach($inArr as $key){
			if(array_key_exists($key, $cArr)){
				//print_r($cArr);
				$cArr=$cArr[$key];
				
			}else{
				debug::add('WARNING','Missing session key '.$key);
				return '';
			}
		}
		debug::add($cArr,'c array');
		return $cArr;
	}
	
	static function remoteDbSettings($path){
        $ff=file_get_contents($path);
    	$name='';
    	$list=array();
        $tokens=token_get_all($ff);
        foreach($tokens as $key=>$value){
        	if($value[0]==318 or $value[0]==364){
        		$list[]=array($value[0],$value[1]);
        	}
        }
        $max=sizeof($list);
        $settings=array();
        for($i=0;$i<$max;$i++){
        	if($list[$i][0]==364){
        		if(array_key_exists($i+1,$list)){
    	    		$settings[str_replace("'",'',$list[$i-1][1])]=str_replace("'",'',$list[$i+1][1]);
        		}
        	}
        }
        return $settings;

	}

}



?>