<?php



class profile{
    
    static function APIlistSettings(){
        $ret=array();
        $sql='select short_code,name,type,exclude from settings order by type asc,sortorder asc,short_code asc';
		if($stmt=dbpdo::query($sql)){
		    while($row = $stmt->fetch()){
		        $ret[$row['short_code']]=$row;
		    }
		}else{
			slack::message('API LIst settings failed '.dbpdo::error());
		}
		return $ret;

    }
    
    static function utf8Array($inArray){
    	$ret=array();
    	foreach($inArray as $key=>$value){
    		$ret[$key]=$value;
    	}
    	return $ret;
    	
    }
	
    static function listUsers(){
	    $sql='select ref, concat(firstnames, " ", surname) as name from person order by name asc;';
	    $parms=array();
        $ret='';
		if($stmt=dbpdo::query($sql,$parms)){
		    while($row = $stmt->fetch()){
		        $ret.= pipe::pipeRow($row);
		    }
		}
		$ret=rtrim($ret,'#');
		return $ret;
    }
    
    static function  getRules(){
        $sql='select * from settings where type in ("allergens","kifestyle","religion","medical") order by type desc,sortorder desc';
        $ret=array();
		if($stmt=dbpdo::query($sql)){
		    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		        //$ret[]=$row;
		        $ret[$row['type']][]=$row;
		    }
		}
		return $ret;
    }
    
    static function getUser($userRef,$json=true){
        $sql='select * from person where ref=:ref limit 1';
        $parms=array(':ref'=>$userRef);
        if($data=dbpdo::getQuery($sql,$parms)){
            if($json){
                return json_encode($data);
            }else{
                return $data;
            }
        }else{
            return '';
        }
    }
    
    static function getSliderLabels(){
    	$sql='select name,category from preferences';
    	$ret=array();
		if($stmt=dbpdo::query($sql)){
		    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		    	$ret['categories'][$row['category']]=$row['name'];
		    }
		}
    	$sql='select category,subcategory,name,maxval,hint,unit from preferences_sub';
		if($stmt=dbpdo::query($sql)){
		    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		    	$key=$row['category'].':'.$row['subcategory'];
		    	$ret['subcat'][$key]=array('name'=>$row['name'],'unit'=>$row['unit'],'max'=>$row['maxval'],'hint'=>$row['hint']);
		    }
		}
		return $ret;
    }
    
    static function getUserAll($userRef){
        $ret=array();
        $ret['person']=self::getUser($userRef,false);
        $profiles=self::userProfiles($userRef);
        foreach($profiles as $key=>$value){
        	$ret['profile'][$key]['name']=$value['name'];
        	$ret['profile'][$key]['data']=self::profileDetail($value['ref']);
        }
        $ret['labels']=self::getSliderLabels();
        return $ret;
    }
	
    static function userProfiles($userRef){
	    $sql='select ref, name from profile where personref=:ref order by sortorder asc;';
	    $parms=array(':ref'=>$userRef);
        $ret=array();
		if($stmt=dbpdo::query($sql,$parms)){
		    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		        $ret[]= $row;
		    }
		}
		return $ret;
    }
    
    static function profileDetail($profileRef){
    	$sql='select profile_preferences.* 
    	        from profile_preferences 
    	        inner join preferences on (profile_preferences.category=preferences.category) 
    	        where profile_ref=:ref order by sortorder asc';	
    	$parms=array(':ref'=>$profileRef);
    	$ret=array();
		if($stmt=dbpdo::query($sql,$parms)){
		    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		    	$ret[]=$row;
		    }
		}
		return $ret;

    }
    


	
    static function settings($table){
	    $sql='select ref, name from '.$table.' order by name asc;';
	    $parms=array();
        $ret='';
		if($stmt=dbpdo::query($sql,$parms)){
		    while($row = $stmt->fetch()){
		        $ret.= pipe::pipeRow($row);
		    }
		}
		return $ret;
    }
	
    static function settingsTable($table){
	    $sql='select ref, name,exclude from settings where type=:type order by name asc;';
	    $parms=array('type'=>$table);

	    $fields=',Name,Excluded Foods';
	    $ret= table::head ('prod-tbl',$fields);
		if($stmt=dbpdo::query($sql,$parms)){
		    while($row = $stmt->fetch()){
		        $row['ref']= '<a href="#" class="sett-edit" data-ref="'.$row['ref'].'"  data-table="'.$table.'"  data-name="'.$row['name'].'"  data-exclude="'.$row['exclude'].'">Edit</a>';
		        $ret.= table::dataRow($row,'ref,name,exclude',true);
		    }
		}
	    $ret.= table::close();
		return $ret;
    }


    static function listUsersTable(){
	    $sql='select profile.ref, firstnames as name, profile.name as pname 
	    		from person 
	    		inner join profile on (person.ref=profile.personref)
	    		where surname like "Demo%"
	    		order by name asc;';
	    $parms=array();
        $ret='';
        $fields='Name,Profile Name,Edit';
	    $ret= table::head ('prod-tbl',$fields);

        
		if($stmt=dbpdo::query($sql,$parms)){
		    while($row = $stmt->fetch()){
		    	$row['edit']='<a href="../admin/profiles_edit.php?ref='.$row['ref'].'">Edit</a>';
		        $ret.= table::dataRow($row,'name,pname,edit',true);
		    }
		}
	    $ret.= table::close();
		return $ret;
    }
    
    static function listPerferences($preferenceRef){
	    $sql='select name ,score,preferences.ref as pref, preferences.category,
	            score1,score2,score3,score4,score5,score6,score7
	    		from preferences 
	    		left join profile_preferences on (preferences.category=profile_preferences.category and profile_ref="'.$preferenceRef.'")
	    		order by preferences.category asc;';
	    $parms=array(':ref'=>clean::get('ref'));
        $ret='';
		if($stmt=dbpdo::query($sql,$parms)){
		    while($row = $stmt->fetch()){
		        if($row['score']==''){
		            $row['score']=0;
		        }
    	    	$ret.= '<h4>'.$row['name'].'</h4>';
    	    	$ret.= '<input type="range" name="'.$row['pref'].'/'.$row['category'].'" min="1" value="'.$row['score'].'" max="10" />';
			    $ret.=self::subPreferences($row);	    	
		    }
		}
		return $ret;
	}

	private static function subPreferences($data){
	    $sql='select name , category, subcategory, ref, maxval, unit
	    		from preferences_sub
	    		where category=:category
	    		order by preferences_sub.subcategory asc;';
	    $parms=array(':category'=>$data['category']);
        $ret='';
		if($stmt=dbpdo::query($sql,$parms)){
		    while($row = $stmt->fetch()){
		        if($data['score'.$row['subcategory']]==''){
		            $data['score'.$row['subcategory']]=0;
		        }
    	    	$ret.= '<h5>'.$row['name'].'</h5>';
    	    	$max=10;
    	    	$step=1;
    	    	if($row['maxval']>0){
    	    		$max=$row['maxval'];
    	    		$step=$row['maxval']/10;
    	    	}
    	    	$ret.= '<input type="range" name="'.$row['category'].'='.$row['subcategory'].'='.$data['pref'].'" min="0" max="'.$max.'" step="'.$step.'" value="'.$data['score'.$row['subcategory']].'" max="10" />';
		    	if($row['maxval']>0){
		    		$ret.= $row['maxval'].$row['unit'];
		    	}
		    }
		}
		if($ret!=''){
		    $ret='<div class="col s12 m11">'.$ret.'</div>';

		}
		return $ret;
		
	}
	
	
	static function listSettings(){
	    $sql='select name , category,  ref, maxval, hint
	    		from preferences
	    		order by category asc;';
	    $parms=array();
        $ret='';
        $fields='Name, Maximum,Edit';
	    $ret= table::head ('prod-tbl',$fields);
		if($stmt=dbpdo::query($sql,$parms)){
		    while($row = $stmt->fetch()){
		    	$row['edit']='<a href="../admin/settings_edit.php?ref='.$row['ref'].'&type=main">Edit</a>';
		        $ret.= table::dataRow($row,'name,maxval,edit',true);
		    }
		}
	    //$ret.= table::close();
		return $ret;
	    
	}
	static function listSubSettings(){
	    $sql='select concat(preferences.name, " / ",preferences_sub.name) as name , preferences_sub.ref, preferences_sub.maxval
	    		from preferences_sub
	    		inner join preferences on (preferences_sub.category=preferences.category)
	    		order by preferences_sub.category asc, preferences_sub.subcategory asc;';
	    $parms=array();
        $ret='';
        //$fields='Name, Maximum,Edit';
	    //$ret= table::head ('prod-tbl',$fields);
		if($stmt=dbpdo::query($sql,$parms)){
		    while($row = $stmt->fetch()){
		    	$row['edit']='<a href="../admin/settings_edit.php?ref='.$row['ref'].'&type=sub">Edit</a>';
		        $ret.= table::dataRow($row,'name,maxval,edit',true);
		    }
		}
	    $ret.= table::close();
		return $ret;
	    
	}


	static function showJsonError(){	
		switch (json_last_error()) {
	        case JSON_ERROR_NONE:
	            echo ' - No errors';
	        break;
	        case JSON_ERROR_DEPTH:
	            echo ' - Maximum stack depth exceeded';
	        break;
	        case JSON_ERROR_STATE_MISMATCH:
	            echo ' - Underflow or the modes mismatch';
	        break;
	        case JSON_ERROR_CTRL_CHAR:
	            echo ' - Unexpected control character found';
	        break;
	        case JSON_ERROR_SYNTAX:
	            echo ' - Syntax error, malformed JSON';
	        break;
	        case JSON_ERROR_UTF8:
	            echo ' - Malformed UTF-8 characters, possibly incorrectly encoded';
	        break;
	        default:
	            echo ' - Unknown error';
	        break;
	    }
	}
	
	
}

?>