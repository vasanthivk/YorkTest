<?php


class school{
	
	static function menu(){
		$ret='<div class="schoolmenu">';
		$ret='<h4>Monday Menu</h4>';
		$sql='select * from _productsx where customer=:cust order by product_title desc';
		$parms=array(':cust'=>'Churchers');
		if($stmt=dbpdo::query($sql,$parms)){
		    while($row = $stmt->fetch()){
		    	$ret.='<div class="smenu-wrap act-smenu-click" data-bcode="'.$row['barcode_number'].'">';
		    		$ret.=$row['product_title'];
		    	
		    	$ret.='</div>';
		    }
		}
		$ret.='</div>';
		
		return $ret;

	}
	
	
}

?>