<?php

class search{
    
    static function prodsearch($search=''){
       $ret='';
       $barcodes='';
       $sql='select * from _products_import2 
       			where (product_title like "%'.$search.'%" 
       			or regulated_product_name like "%'.$search.'%" 
       			or ingredients like "%'.$search.'%"
       			or allergy_contains like "%'.$search.'%" 
       			or allergy_may like "%'.$search.'%" 
       			or barcode_number like "%'.$search.'%" )
       			order by product_title asc
       			limit 900;';
		if($stmt=dbpdo::query($sql)){
			$ret.='<h4>Products</h4>';
		    while($row = $stmt->fetch()){
		    	$class='';
		    	if($row['deleted']=='Yes'){
		    		$class.='search-deleted';
		    	}
		    	$ret.='<div class="search-row '.$class.'">';
				$ret.='<a href="#" class="act-barcode-drill" data-barcode="'.$row['barcode_number'].'">'.$row['barcode_number'].' '.$row['product_title'].' '.$row['regulated_product_name'].' '.$row['brandbank_filename'].'</a>';	    
				$ret.='</div>';
				$barcodes.='"'.$row['barcode_number'].'",';
		    }	
		}
		$barcodes=substr($barcodes, 0, -1); 
		$sql='select scannedcodes.*, product_title,deleted 
			from scannedcodes 
			left join _products_import2 on (datakey=_products_import2.barcode_number)
		   	where (datakey like "%'.$search.'%" 
		   	or email like "%'.$search.'%" ) or
		   	datakey in ('.$barcodes.')
		   	order by date_created desc
		   	limit 100;';
		if($stmt=dbpdo::query($sql)){
			$ret.='<h4>Scanned</h4>';
		    while($row = $stmt->fetch()){
				$ret.=$row['datakey'].' '.$row['barcode_number'].' '.$row['email'].' '.$row['product_title'].' '.$row['date_created'].' '.$row['deleted'].'<br/>';	    
		    }	
		}
		return $ret;
    }
    
    
    
}

?>