<?php


class users{
    
    static $team=false;
    static $activeTeam=false;
    
    static function loadUsers(){
        if(!self::$team){
            $fields='ref,firstnames,surname,status';//did have status to check for active
	        $sql='select '.$fields.' from person';
    		if($stmt=dbpdo::query($sql)){
    			while($row = $stmt->fetch()){
    			    self::$team[$row['ref']]=$row;
    			    if($row['status']=='Active'){
    			        self::$activeTeam[$row['ref']]=$row;
    			    }
    			}
    		}
        }
    }
    
    static function buildDrop(){
        self::loadUsers();
        $ret='';
        foreach(self::$activeTeam as $ref=>$item){
            $ret.='<a href="#'.$ref.'">'.$item['firstnames'].' '.$item['surname'].'</a>';
        }
        return $ret;
    }
    
    static function getName($id){
        self::loadUsers();
        if(array_key_exists($id,self::$team)){
            if(self::$team[$id]['status']!='Active'){
                $prefix='*';
            }else{
                $prefix='';
            }
            return $prefix.self::$team[$id]['firstnames'].' '.
            self::$team[$id]['surname'];
        }else{
            return $id;
        }
    }
    
    
    static function usersearch($search=''){
       $ret='';
       $emails='';
       $sql='select * from appusers 
       			where (email like "%'.$search.'%") 
       			limit 100;';
		if($stmt=dbpdo::query($sql)){
			$ret.='<h4>Accounts</h4>';
		    while($row = $stmt->fetch()){
				$ret.=$row['email'].' '.$row['lastlogin'].' '.$row['ipaddress'].'<br/>';	    
				$emails.='"'.$row['email'].'",';
		    }	
		}
		$emails=substr($emails, 0, -1); 
		$sql='select scannedcodes.*, product_title 
			from scannedcodes 
			left join _products_import2 on (datakey=_products_import2.barcode_number)
		   	where 
		   	email in ('.$emails.')
		   	order by date_created desc
		   	limit 100;';
		   
		if($stmt=dbpdo::query($sql)){
			$ret.='<h4>Scanned</h4>';
		    while($row = $stmt->fetch()){
				$ret.=$row['datakey'].' '.$row['email'].' '.$row['product_title'].' '.$row['date_created'].'<br/>';	    
		    }	
		}
		return $ret;
    }
    
    
}


?>