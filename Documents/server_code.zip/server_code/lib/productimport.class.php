<?php

/*
Due to the inconsistency of the xml, there are a few warnings where nodes are missing or named differently.
This is handled, so turning off the warnings.
*/
//error_reporting(0);

class productimport
{
    
    private static $reader;
    private static $count = 0;
    private static $brandbankFile = '';
    
    public static function initialise($filepath=''){
    	
    	self::$reader = new XMLReader(); // initialize
    	self::$brandbankFile = self::getBrandbankFileRefName($filepath);
    	
    	if ($filepath != ''){
            self::$reader->open( $filepath ); // open file
    	}
    }
    
    public static function archiveXML($filepath, $archiveFilePath){
    	if(file_exists($filepath)){
	    	if(rename($filepath, $archiveFilePath)){
	    		echo "\n Moved $filepath to $archiveFilePath \n";
	    	}else{
	    		echo "\n Move $filepath to $archiveFilePath FAILED \n";
	    	}
    	}else{
    		echo "\n $filepath doesn't exist";
    	}
    }
    
    public static function printout($filepath=''){
    	 
    	 self::initialise($filepath);

         while(self::$reader->read())
         {
            if( self::$reader->nodeType == XMLReader::ELEMENT 
                &&  self::$reader->name == 'Product')
              {
                $doc = new DOMDocument('1.0', 'UTF-8');
                $xml = simplexml_import_dom($doc->importNode(self::$reader->expand(),true));
   
               if(self::getUpdateType() != 'Delete'){
                	self::printToScreen($xml);
                }
                self::$count++;
              }
              
        }
        echo 'Product count (including deletes): ' . self::$count . "\n";
    }
    
    public static function import($filepath){

        self::initialise($filepath);
		$count=0;
        while(self::$reader->read())
 
        {
        	// echo 'Node Type: ' . self::$reader->nodeType . "\n";
         //   echo 'Name: ' . self::$reader->name . "\n";
            if( self::$reader->nodeType == XMLReader::ELEMENT 
                &&  self::$reader->name == 'Product')
              {
              	
                $doc = new DOMDocument('1.0', 'UTF-8');
                $xml = simplexml_import_dom($doc->importNode(self::$reader->expand(),true));
                switch(self::getUpdateType()){
                	case 'AddOrUpdate':
                		 echo 'Update type: ADD/Update' . "\n";
                		 self::addOrUpdate($xml);
                		break;
                    case 'Delete':
                    	echo 'Update type: DELETE' . "\n";
                    	self::markProductAsDeleted($xml);
                    	break;
                    default:
                    	
                }
            }

            $count++;
        }
    }
    
    public static function markProductAsDeleted($xml){
    	$barcode = self::getNodeValueForAttribute($xml->Identity->ProductCodes->Code, 'Scheme', 'GTIN');
    	
    	if($barcode !=''){
    		$productIsInDb = self::recordExists('_products_import2', $barcode,'barcode_number');
    		// if($productIsInDb){
    		// 	echo 'Prod in db' . "\n";
    		// }else{
    		// 	echo 'Prod not in db' . "\n";
    		// }
    		if($productIsInDb){
		    	$fields=array();
		    	$fields['deleted']='Yes';
		    	$fields['date_deleted']=dbpdo::now();
		    	$fields['date_modified']=dbpdo::now();
		    	dbpdo::dbUpdate('_products_import2',$barcode,$fields,'barcode_number','',false);
		    	// log::logInfo('Marked product: ' . $barcode . ' as deleted.');
		    	// echo 'Marked product: ' . $barcode . ' as deleted.' . "\n";
    		}else{
    			// echo 'Delete product: ' . $barcode . ' not in database.' . "\n";
    			// log::logInfo('Delete product: ' . $barcode . ' not in database.');
    		}
    	}
    }
    
    public static function recordExists($table, $ref,$refField){
    	$sql = 'SELECT * FROM ' . $table . ' WHERE ' . $refField. ' = :ref LIMIT 1';
    	$params = [':ref' => $ref];
    	$recordExists = false;
    
    	if ($stmt=dbpdo::query($sql, $params)) {
    		$count = $stmt->rowCount();
    		if($count==1){
    			$recordExists=true;
    		}
    	}
    	
     	return $recordExists;
    	
    }
    
    public static function deleteProduct($xml){
    	$barcode = self::getNodeValueForAttribute($xml->Identity->ProductCodes->Code, 'Scheme', 'GTIN');
    	if($barcode !=''){
    		dbpdo::dbDelete('_products_import2',$barcode,'barcode_number','',false);
    		// log::logInfo('Deleted product: ' . $barcode);
    		// echo 'Deleting product: ' . $barcode . "\n";
    	}
    }
    
    public static function getUpdateType()
    {
	   return self::$reader->getAttribute('UpdateType');
    }
    
    public static function getAcknowledgementId($filepath){
        $ackId='';
        self::initialise($filepath);
        
         while(self::$reader->read())
        {
        	  if( self::$reader->nodeType == XMLReader::ELEMENT 
                &&  self::$reader->name == 'Message')
              {
              	 $doc = new DOMDocument('1.0', 'UTF-8');
              	 $xml = simplexml_import_dom($doc->importNode(self::$reader->expand(),true));
			        if(!$xml){
			            $ackId='Invalid XML';
			        }else{
			            $ackId=self::xml_attribute($xml,'Id');
		            }
		            break;
              }
        }
        return $ackId;
    }
    
    // public static function sendBroadbankAcknoledgement($lastMessageId)
    // {
    // 	soap::AcknowledgeMessage($lastMessageId);
    // }
    
    public static function sendBrandbankAcknoledgement($lastMessageId, $xmlFilepath)
    {
    	$requestXml = str_replace('[MSGID]', $lastMessageId, file_get_contents($xmlFilepath));
    	$apiUrl = 'https://api.brandbank.com/svc/feed/extractdata.asmx?op=AcknowledgeMessage';
    //	echo $requestXml; exit;
    	
    	$response=soap::doXMLCurl($apiUrl, $requestXml);

    	echo "Brandbank acknowldgement sent for message: $lastMessageId\n";
		log::logInfo("Brandbank acknowldgement sent for message: $lastMessageId");
		return $response;
    }
    
    public static function test($filepath){
    	 self::initialise($filepath);
    	  
         while(self::$reader->read())
         {
            if( self::$reader->nodeType == XMLReader::ELEMENT 
                &&  self::$reader->name == 'Product')
              {
                $doc = new DOMDocument('1.0', 'UTF-8');
                $xml = simplexml_import_dom($doc->importNode(self::$reader->expand(),true));
                $nutritionTextSugar=self::getTextualNutrientValue($xml, array('of which sugars','- sugars'));
            }
        }
    }
    

    // Private methods
    private static function xml_attribute($object, $attribute)
    {
    if(isset($object[$attribute]))
        return (string) $object[$attribute];
    }
    
    private static function checkForEmptyValue($val){
        if(isset($val)){
            return $val;
        }else{
            return 'Not Found';
        }
    }
    
    private static function checkForNullObject($obj, $prop){
        if(is_null($obj)){
            return 'Not Found';
        }else{
            return $obj->$prop;
        }
    }
    
    private static function contains(array $needles,$haystack){
		$ret = false;
		
		foreach($needles as $needle){
			if (strpos(strtolower($haystack), strtolower($needle)) !== false) {
		    	$ret = true;
			}
		}
		return $ret;
	}
	
	private static function getBrandbankFileRefName($filepath){
		$pos = strpos($filepath, 'productdata_');
		return substr($filepath, $pos+12, strlen($filepath));
	}
    
    private static function addOrUpdate($xml){
        $product=self::getProductAsArray($xml);
        
        // Build fields as is done in printout() .. 
       $barcode = self::checkForEmptyValue($product['barcode']);
       $barcodeMin = self::checkForEmptyValue($product['barcode']);
       $barcodeMin +=0;
       
       	$containsNeedles = ['contains','may contain'];
       	$allergyInfo = array();
       	$allergyInfo['contains'] = '';
		$allergyInfo['may contain'] = '';
		if(self::contains($containsNeedles,$product['allergy_advice'])){
	         $allergyInfo = self::separateAllergyInfo($product['allergy_advice']);	
	   	}
	    
       $fieldlist=array('barcode_number'=>$barcode,
	       	  'barcode_min'=>$barcodeMin,
	          'product_code'=>self::checkForEmptyValue($product['product_code']) ,
	          'product_title'=> self::checkForEmptyValue($product['product_title']),
	          'category'=>self::checkForEmptyValue($product['category']),
	          'subcategory'=>self::checkForEmptyValue($product['sub_category']),
	          'subsubcategory'=>self::checkForEmptyValue($product['sub_sub_category']),
	          'lifestyle'=>self::checkForEmptyValue($product['lifestyle']),
	          'allergy_advice'=>self::checkForEmptyValue($product['allergy_advice']) ,
	          'allergy_contains'=>$allergyInfo['contains'],
	          'allergy_may'=>$allergyInfo['may contain'],
	          
	          'manufacturers_address'=>self::checkForEmptyValue($product['manufacturers_address']) ,
	          'further_description'=>self::checkForEmptyValue($product['further_description']),
	          'brand'=>self::checkForNullObject($product['brand'], 'Value') ,
	          'company_name'=>self::checkForNullObject($product['company_name'], 'Text'),
	          'ingredients'=>self::returnAsDelimitedString(self::checkForNullObject($product['ingredients'], 'Text')),
	                         
	          'nutrition_textual_energykcal'=>self::checkForEmptyValue($product['nutrition_txt_energykcal']),
	          'nutrition_textual_energykjoules'=>self::checkForEmptyValue($product['nutrition_txt_energykjoules']),
	          'nutrition_textual_fat'=>self::checkForEmptyValue($product['nutrition_txt_fat']),
	          'nutrition_textual_satfat'=> self::checkForEmptyValue($product['nutrition_txt_satfat']),
	          'nutrition_textual_sodium'=>self::checkForEmptyValue($product['nutrition_txt_salt']),
	          'nutrition_textual_sugar'=>self::checkForEmptyValue($product['nutrition_txt_sugar']),
	          'nutrition_textual_fibre'=>self::checkForEmptyValue($product['nutrition_txt_fibre']),
	          'nutrition_textual_protein'=>self::checkForEmptyValue($product['nutrition_txt_protein']),
	          'nutrition_textual_carbohydrate'=>self::checkForEmptyValue($product['nutrition_txt_carbohydrate']),
	          'nutrition_textual_cholesterol'=>self::checkForEmptyValue($product['nutrition_txt_cholesterol']),
	                         
	          'nutrition_numeric_energykcal'=>self::checkForEmptyValue($product['nutrition_num_energykcal']),
	          'nutrition_numeric_energykjoules'=>self::checkForEmptyValue($product['nutrition_num_energykjoules']),
	          'nutrition_numeric_fat'=>self::checkForEmptyValue($product['nutrition_num_fat']) ,
	          'nutrition_numeric_satfat'=>self::checkForEmptyValue($product['nutrition_num_satfat']),
	          'nutrition_numeric_sodium'=>self::checkForEmptyValue($product['nutrition_num_salt']),
	          'nutrition_numeric_sugar'=>self::checkForEmptyValue($product['nutrition_num_sugar']),
	          'nutrition_numeric_fibre'=>self::checkForEmptyValue($product['nutrition_num_fibre']),
	          'nutrition_numeric_protein'=> self::checkForEmptyValue($product['nutrition_num_protein']),
	          'nutrition_numeric_carbohydrate'=> self::checkForEmptyValue($product['nutrition_num_carbohydrate']),
	          'nutrition_numeric_cholesterol'=> self::checkForEmptyValue($product['nutrition_num_cholesterol']),
	                         
	          'brandbank_filename'=>self::$brandbankFile,               
	          'front_of_pack'=> self::checkForEmptyValue($product['front_of_pack']),
	          'allergy_text'=>self::checkForNullObject($product['allergy_text'], 'Content'),
	          'image_ref'=> self::checkForEmptyValue($product['image_ref']),
	          'regulated_product_name'=>self::checkForEmptyValue($product['regulated_product_name']),
	          'setting_vals'=>self::checkForEmptyValue($product['setting_vals']), 
	           );
	                        
			if(self::isNew($product['barcode'])){
				$fieldlist['date_entered']=dbpdo::now();
				$ref=dbpdo::dbInsert('_products_import2', $fieldlist, '', false, true);									// DB TABLE HERE
				// log::logInfo('Added NEW product: ' . $fieldlist['product_title']);
				// echo 'Added NEW product: ' . $fieldlist['product_title'] . "\n";
			}else{
				  $fieldlist['date_modified']=dbpdo::now();
				  dbpdo::dbUpdate('_products_import2',$product['barcode'],$fieldlist,'barcode_number','',false);		// DB TABLE HERE
		//		  log::logInfo('Updated EXISTING product: ' . $fieldlist['product_title'] );
			//	  echo 'Updated EXISTING product: ' . $fieldlist['product_title'] . "\n";
			}
	       
    }
    
    
    // Check if product already exists
    private static function isNew($barcode){
		$sql = "SELECT * FROM _products_import2 WHERE barcode_number = :barcode";

		$params = [':barcode' => $barcode];
		$ret = true;
	 
		 if($stmt=dbpdo::query($sql, $params)){
		 	if($stmt->rowCount() > 0){
		 		$ret = false;
		 	}
		 }

		return $ret;
    }
    
    // Helper used for dev/debugging
    private static function printToScreen($xml){
                $product=self::getProductAsArray($xml);
                echo '<b>Barcode: </b>' . self::checkForEmptyValue($product['barcode']) . '<br/>';
                echo '<b>Product Code: </b>' . self::checkForEmptyValue($product['product_code']) . '<br/>';
                echo '<b>Product Title: </b>' . self::checkForEmptyValue($product['product_title'])  . '<br/>';
                echo '<b>Category: </b>' . self::checkForEmptyValue($product['category']) .'<br/>';
                echo '<b>Sub Category: </b>' . self::checkForEmptyValue($product['sub_category']) . '<br/>';
                echo '<b>Sub Sub Category: </b>' . self::checkForEmptyValue($product['sub_sub_category']) . '<br/>';
                echo '<b>Lifestyle: </b>' . self::checkForEmptyValue($product['lifestyle']) . '<br/>';
                echo '<b>Allergy Advice: </b>' . self::checkForEmptyValue($product['allergy_advice']) . '<br/>';
                echo '<b>Manufacturers Address: </b>' . self::checkForEmptyValue($product['manufacturers_address']) . '<br/>';
                echo '<b>Further Description: </b>' . self::checkForEmptyValue($product['further_description']) .'<br/>';
                echo '<b>Brand: </b>' .  self::checkForNullObject($product['brand'], 'Value') . '<br/>';
                echo '<b>Company Name: </b>' . self::checkForNullObject($product['company_name'], 'Text') .'<br/>';
                echo '<b>Ingredients: </b>' . self::returnAsDelimitedString(self::checkForNullObject($product['ingredients'], 'Text')) . '<br/>';
                echo '<br/>';
                echo '<b>Nutrition (Textual) Energy kCal: </b>' . self::checkForEmptyValue($product['nutrition_txt_energykcal']) . '<br/>';
                echo '<b>Nutrition (Textual) Energy kJoules: </b>' . self::checkForEmptyValue($product['nutrition_txt_energykjoules'])  . '<br/>';
                echo '<b>Nutrition (Textual) Total Fat: </b>' . self::checkForEmptyValue($product['nutrition_txt_fat']) . '<br/>';
                echo '<b>Nutrition (Textual) Saturated Fat: </b>' . self::checkForEmptyValue($product['nutrition_txt_satfat']) . '<br/>';
                echo '<b>Nutrition (Textual) Salt/Sodium: </b>' . self::checkForEmptyValue($product['nutrition_txt_salt']) . '<br/>';
                echo '<b>Nutrition (Textual) Sugar: </b>' . self::checkForEmptyValue($product['nutrition_txt_sugar']) . '<br/>';
                echo '<b>Nutrition (Textual) Protein: </b>' . self::checkForEmptyValue($product['nutrition_txt_protein']) . '<br/>';
                echo '<b>Nutrition (Textual) Carbohydrate: </b>' . self::checkForEmptyValue($product['nutrition_txt_carbohydrate']) . '<br/>';
                echo '<b>Nutrition (Textual) Fibre: </b>' . self::checkForEmptyValue($product['nutrition_txt_fibre']) . '<br/>';
                echo '<b>Nutrition (Textual) Cholesterol: </b>' . self::checkForEmptyValue($product['nutrition_txt_cholesterol']) . '<br/>';
                echo '<br/>';
                echo '<b>Nutrition (Numeric) Energy kCal: </b>' . self::checkForEmptyValue($product['nutrition_num_energykcal']) . '<br/>';
                echo '<b>Nutrition (Numeric) Energy kJoules: </b>' . self::checkForEmptyValue($product['nutrition_num_energykjoules']) . '<br/>';
                echo '<b>Nutrition (Numeric) Total Fat: </b>' . self::checkForEmptyValue($product['nutrition_num_fat']) . '<br/>';
                echo '<b>Nutrition (Numeric) Using Saturated Fat: </b>' . self::checkForEmptyValue($product['nutrition_num_satfat']). '<br/>';
                echo '<b>Nutrition (Numeric) Salt/Sodium: </b>' . self::checkForEmptyValue($product['nutrition_num_salt']) . '<br/>';
                echo '<b>Nutrition (Numeric) Sugar: </b>' . self::checkForEmptyValue($product['nutrition_num_sugar']) . '<br/>';
                echo '<b>Nutrition (Numeric) Protein: </b>' . self::checkForEmptyValue($product['nutrition_num_protein']) . '<br/>';
                echo '<b>Nutrition (Numeric) Carbohydrate: </b>' . self::checkForEmptyValue($product['nutrition_num_carbohydrate']) . '<br/>';
                echo '<b>Nutrition (Numeric) Fibre: </b>' . self::checkForEmptyValue($product['nutrition_num_fibre']) . '<br/>';
                echo '<b>Nutrition (Numeric) Cholesterol: </b>' . self::checkForEmptyValue($product['nutrition_num_cholesterol'])  . '<br/>';
                echo '<br/>';
                echo '<b>Front of Pack : </b>' . self::checkForEmptyValue($product['front_of_pack']) . '<br/>';
                echo '<b>Allergy Text: </b>' .  self::checkForNullObject($product['allergy_text'], 'Content') . '<br/>';
                echo '<b>Image Ref: </b>' .  self::checkForEmptyValue($product['image_ref']) . '<br/>';
                echo '<b>Regulated Product Name: </b>' . self::checkForEmptyValue($product['regulated_product_name']) .'<br/>';
                echo '<b>Setting Vals: </b>' . self::checkForEmptyValue($product['setting_vals']) .'<br/>';
                echo '-----------------------------------------------------------------------------------------------<br/>' ;
    }
    
       // Helper used for dev/debugging
    private static function printToCli($xml){
                $product=self::getProductAsArray($xml);
                echo '<b>Barcode: </b>' . self::checkForEmptyValue($product['barcode']) . "\n";
                echo '<b>Product Code: </b>' . self::checkForEmptyValue($product['product_code']) . "\n";
                echo '<b>Product Title: </b>' . self::checkForEmptyValue($product['product_title'])  . "\n";
                echo '<b>Category: </b>' . self::checkForEmptyValue($product['category']) .'<br/>';
                echo '<b>Sub Category: </b>' . self::checkForEmptyValue($product['sub_category']) . "\n";
                echo '<b>Sub Sub Category: </b>' . self::checkForEmptyValue($product['sub_sub_category']) . "\n";
                echo '<b>Lifestyle: </b>' . self::checkForEmptyValue($product['lifestyle']) . "\n";
                echo '<b>Allergy Advice: </b>' . self::checkForEmptyValue($product['allergy_advice']) . "\n";
                echo '<b>Manufacturers Address: </b>' . self::checkForEmptyValue($product['manufacturers_address']) . "\n";
                echo '<b>Further Description: </b>' . self::checkForEmptyValue($product['further_description']) ."\n";
                echo '<b>Brand: </b>' .  self::checkForNullObject($product['brand'], 'Value') . "\n";
                echo '<b>Company Name: </b>' . self::checkForNullObject($product['company_name'], 'Text') ."\n";;
                echo '<b>Ingredients: </b>' . self::returnAsDelimitedString(self::checkForNullObject($product['ingredients'], 'Text')) . "\n";
                echo "\n";;
                echo '<b>Nutrition (Textual) Energy kCal: </b>' . self::checkForEmptyValue($product['nutrition_txt_energykcal']) . "\n";
                echo '<b>Nutrition (Textual) Energy kJoules: </b>' . self::checkForEmptyValue($product['nutrition_txt_energykjoules'])  ."\n";
                echo '<b>Nutrition (Textual) Total Fat: </b>' . self::checkForEmptyValue($product['nutrition_txt_fat']) . "\n";
                echo '<b>Nutrition (Textual) Saturated Fat: </b>' . self::checkForEmptyValue($product['nutrition_txt_satfat']) . "\n";
                echo '<b>Nutrition (Textual) Salt/Sodium: </b>' . self::checkForEmptyValue($product['nutrition_txt_salt']) . "\n";
                echo '<b>Nutrition (Textual) Sugar: </b>' . self::checkForEmptyValue($product['nutrition_txt_sugar']) . "\n";
                echo '<b>Nutrition (Textual) Protein: </b>' . self::checkForEmptyValue($product['nutrition_txt_protein']) . "\n";
                echo '<b>Nutrition (Textual) Carbohydrate: </b>' . self::checkForEmptyValue($product['nutrition_txt_carbohydrate']) . "\n";
                echo '<b>Nutrition (Textual) Fibre: </b>' . self::checkForEmptyValue($product['nutrition_txt_fibre']) . "\n";
                echo '<b>Nutrition (Textual) Cholesterol: </b>' . self::checkForEmptyValue($product['nutrition_txt_cholesterol']) . "\n";
                echo "\n";
                echo '<b>Nutrition (Numeric) Energy kCal: </b>' . self::checkForEmptyValue($product['nutrition_num_energykcal']) . "\n";
                echo '<b>Nutrition (Numeric) Energy kJoules: </b>' . self::checkForEmptyValue($product['nutrition_num_energykjoules']) . "\n";
                echo '<b>Nutrition (Numeric) Total Fat: </b>' . self::checkForEmptyValue($product['nutrition_num_fat']) . "\n";
                echo '<b>Nutrition (Numeric) Using Saturated Fat: </b>' . self::checkForEmptyValue($product['nutrition_num_satfat']). "\n";
                echo '<b>Nutrition (Numeric) Salt/Sodium: </b>' . self::checkForEmptyValue($product['nutrition_num_salt']) . "\n";
                echo '<b>Nutrition (Numeric) Sugar: </b>' . self::checkForEmptyValue($product['nutrition_num_sugar']) . "\n";
                echo '<b>Nutrition (Numeric) Protein: </b>' . self::checkForEmptyValue($product['nutrition_num_protein']) . "\n";
                echo '<b>Nutrition (Numeric) Carbohydrate: </b>' . self::checkForEmptyValue($product['nutrition_num_carbohydrate']) . "\n";
                echo '<b>Nutrition (Numeric) Fibre: </b>' . self::checkForEmptyValue($product['nutrition_num_fibre']) . "\n";
                echo '<b>Nutrition (Numeric) Cholesterol: </b>' . self::checkForEmptyValue($product['nutrition_num_cholesterol'])  . "\n";
                echo "\n";
                echo '<b>Front of Pack : </b>' . self::checkForEmptyValue($product['front_of_pack']) . "\n";
                echo '<b>Allergy Text: </b>' .  self::checkForNullObject($product['allergy_text'], 'Content') . "\n";
                echo '<b>Image Ref: </b>' .  self::checkForEmptyValue($product['image_ref']) . "\n";
                echo '<b>Regulated Product Name: </b>' . self::checkForEmptyValue($product['regulated_product_name']) ."\n";
                echo '<b>Setting Vals: </b>' . self::checkForEmptyValue($product['setting_vals']) ."\n";
                echo '-----------------------------------------------------------------------------------------------' . "\n"; ;
    }
    
    private static function getFrontOfPackInfo($xml){
   //     $domElements = $xml->Data->Language->ItemTypeGroup->FrontOfPackGDA->Reference->Lozenges->Lozenge;
        $domElements = null;
        
        if(self::xmlChildExists($xml->Data->Language->ItemTypeGroup->FrontOfPackGDA->Reference)){
        	 $domElements = $xml->Data->Language->ItemTypeGroup->FrontOfPackGDA->Reference->Lozenges->Lozenge;
        }else if(self::xmlChildExists($xml->Data->Language->Part->ItemTypeGroup)){
        	$domElements = $xml->Data->Language->Part->ItemTypeGroup->FrontOfPackGDA->Reference->Lozenges->Lozenge;
        }
        
		if(is_null($domElements)){
			return;
		}
		
     	$ret='';
     	
        $count=0;
         if (is_array($domElements) || is_object($domElements))
         {
        foreach($domElements as $elem) {
         //   echo print_r( $elem) . '<br/><br/>';
         $ret .= $elem['Name'];
     //    echo print_r($elem->Quantities->Quantity) . '<br/><br/>';
            $quantities = $elem->Quantities->Quantity;
            
             foreach($quantities as $quantity){
                
                 $ret .= ': Unit=' . $quantity->Unit['Name'] . ', Value=' . $quantity->Value . ', '; 
             }
             
                $ret .= 'Percentage=' . $elem->Percentage->Value;
                 if($count < sizeOf($domElements)-1){
                     $ret .= ', ';
                 }
                
                $count++;
        	}
        }	
        return $ret;
    }
        
    private static function getNumericNutritionValue($xml, $nutrient, $grams='100'){
        
     	$domElements = null;
		if(self::xmlChildExists($xml->Data->Language->ItemTypeGroup->NumericNutrition)){
			$domElements = $xml->Data->Language->ItemTypeGroup->NumericNutrition->NutrientValues;
		}else if(self::xmlChildExists($xml->Data->Language->Part->ItemTypeGroup)){
			$domElements = $xml->Data->Language->Part->ItemTypeGroup->NumericNutrition->NutrientValues;
		}
		
		if(is_null($domElements)){
			return;
		}
  
		 $productCode = self::getNodeValueForAttribute($xml->Identity->ProductCodes->Code, 'Scheme', 'BRANDBANK:PVID');
		 
		 //if($productCode=='2362898'){
		 //	echo 'Numeric Nutrition: ' . print_r($domElements); exit;
		 //}
		
         if (is_array($domElements) || is_object($domElements))
         {
	         foreach($domElements as $elem) {
	      //      echo print_r($elem['Name']) .'<br/><br/>';
	        $elemName = strtolower(trim($elem['Name']));
	         if(self::textNutrientMatch($elemName,$nutrient)){
	                 switch($grams){
	                    case 100:
	                         return $elem->Per100->Value; 
	                    case 30:
	                         return $elem->PerServing->Value; 
	                    default:
	                        return $elem->Per100->Value;
	                 }
	               
	             }
	         }
         }
    }
    
      private static function getTextualNutrientValue($xml, $nutrient, $grams='100'){
        
 //       $productCode = self::getNodeValueForAttribute($xml->Identity->ProductCodes->Code, 'Scheme', 'BRANDBANK:PVID');
		// On some products the node is in a different place.
		$domElements = null;
		if(self::xmlChildExists($xml->Data->Language->ItemTypeGroup->TextualNutrition->Nutrient)){
			$domElements = $xml->Data->Language->ItemTypeGroup->TextualNutrition->Nutrient;
		}else if (self::xmlChildExists($xml->Data->Language->Part->ItemTypeGroup)){
			 $domElements = $xml->Data->Language->Part->ItemTypeGroup->TextualNutrition->Nutrient;
		}
		
		if(is_null($domElements)){
			return;
		}
  
        if (is_array($domElements) || is_object($domElements))
		{
	         foreach($domElements as $elem) {
	         	$elemName = strtolower(trim($elem->Name));
	             if(self::textNutrientMatch($elemName,$nutrient)){
	                 switch($grams){
	                    case 100:
	                         return $elem->Values->Value[0]; 
	                    case 30:
	                         return $elem->Values->Value[1]; 
	                    default:
	                        return $elem->Values->Value[0]; 
	                 }
	               
	             }
	         }
		}
    }
    
    private static function textNutrientMatch($xmlNutrientValue, $searchNutrientValue){
    	$ret=false;
    	
    //	$productCode = self::getNodeValueForAttribute($xml->Identity->ProductCodes->Code, 'Scheme', 'BRANDBANK:PVID');
	    if(is_array($searchNutrientValue)){
	    	if(in_array($xmlNutrientValue, $searchNutrientValue)){
	    		$ret = true;
	    	}else{
	    		foreach($searchNutrientValue as $searchVal){
		    		if(strpos($xmlNutrientValue, $searchVal)){
		    			$ret = true;
		    			break;
	    			}
	    		}
	    	}
	    }else{
	    	if($xmlNutrientValue==$searchNutrientValue || strpos($xmlNutrientValue, $searchNutrientValue)){
    	 			$ret = true;
    	 	}
	    }
	      //if ($productCode=='3758425' & $ret){
	    	 //		 	echo 'MATCH!<br/>';
			    // 	 	echo 'Xml value: ' . $xmlNutrientValue . '<br/>';
			    // 	 	echo  'Search value: '. print_r($searchNutrientValue) . '<br/>';
    	 	// 		}
    	 return $ret;
    }
    
    private static function returnAsDelimitedString($domElements, $delimiter=', '){
        $ret='';
        $count=0;
        
        if(is_string($domElements)){
        	return $domElements;
        }
        
         if (is_array($domElements) || is_object($domElements))
         {
	           foreach($domElements as $elem) { 
	             $ret .= $elem;
	             if($count < sizeOf($domElements)-1){
	                $ret .= $delimiter;
	             }
	             $count++;
	        	}
         }
        return $ret;
    }
    
    private static function buildAllergyAdviceString($xml){
        $allergyAdvice = '';
        $domElements = $xml->Data->Language->ItemTypeGroup->NameLookups->NameValue;

		 if (is_array($domElements) || is_object($domElements))
		 {
	        foreach($domElements as $elem) { 
	             $allergyAdvice .= $elem->Value. ' - ' . $elem->Name . ', ';
	        }
	    }
        return $allergyAdvice;
    }
    
    /* Where you have several nodes with different attribute values
       e.g.
       <Code Scheme="GTIN">5000237111994</Code>
       <Code Scheme="BRANDBANK:PVID">3796187</Code>
       
       this method lets you get the node value of the attribute you want.
       
       @arg $domElements - the dom element of the nodes
       @arg $attributeName - the name of the attribute you want to get the node value for.
       @arg $attributeValue - the value of the attribute you want to get the node value for.
    */
    
    public static function getNodeValueForAttribute($domElements, $attributeName, $attributeValue){
    	 if (is_array($domElements) || is_object($domElements))
    	 {
            foreach($domElements as $elem) { 
                if($elem[$attributeName]==$attributeValue){
                    return $elem;
                }
            }
    	}
    }
    
    private static function getImageUrl($xml, $imageName){
    	 $domElements =$xml->Assets->Image;
    	 $$ret='';
    	  if (is_array($domElements) || is_object($domElements))
    	  {
    	  	foreach($domElements as $elem) { 
    	  		if($elem['ShotType']==$imageName){
    	  			$ret = $elem->Url;
    	  		}
    	  	}
    	  }
    	return $ret;
    }
    
   private static function getImageRef($xml, $imageName){
    	 $domElements =$xml->Assets->Image;
    	 $ret='';
    	  if (is_array($domElements) || is_object($domElements))
    	  {
    	  	foreach($domElements as $elem) { 
    	  		if($elem['ShotType']==$imageName){
    	  			$imageUrl = $elem->Url;
					$parts = parse_url($imageUrl);
					parse_str($parts['query'], $query);
					$ret=$imageFilename = $query['id'];
    	  		}
    	  	}
    	  }
    	return $ret;
    }
    
    private static function getIngredients($xml){
    	$ingredients = self::getNodeValueForAttribute($xml->Data->Language->ItemTypeGroup->LongTextItems, 'Name', 'Ingredients');
    	
    	if(is_null($ingredients) & self::xmlChildExists($xml->Data->Language->Part->ItemTypeGroup)){
    			$ingredients = self::getNodeValueForAttribute($xml->Data->Language->Part->ItemTypeGroup->LongTextItems, 'Name', 'Ingredients');
    	}
    	return $ingredients;
    }
    
    private static function getSettingVals($nutritionVals){
       $settingVals='';

          $settingVals .= $nutritionVals['category_number'] . ':1' . ',' . sprintf("%.2f", $nutritionVals['engerykcal']) .'|';
          $settingVals .= $nutritionVals['category_number'] . ':2' . ',' . sprintf("%.2f", $nutritionVals['fat']) .'|';
          $settingVals .= $nutritionVals['category_number'] . ':3' . ',' . sprintf("%.2f", $nutritionVals['satfat']) .'|';
          $settingVals .= $nutritionVals['category_number'] . ':4' . ',' . sprintf("%.2f", $nutritionVals['salt']) .'|';
          $settingVals .= $nutritionVals['category_number'] . ':5' . ',' . sprintf("%.2f", $nutritionVals['sugar']) .'|';
          $settingVals .= $nutritionVals['category_number'] . ':6' . ',' . sprintf("%.2f", $nutritionVals['fibre']);

       return $settingVals;
    }
    
    private static function getProductAsArray($xml){
        $barcode=self::getNodeValueForAttribute($xml->Identity->ProductCodes->Code, 'Scheme', 'GTIN');
        $productCode=self::getNodeValueForAttribute($xml->Identity->ProductCodes->Code, 'Scheme', 'BRANDBANK:PVID');
        $productTitle=$xml->Identity->DiagnosticDescription;
        
        $category=$xml->Data->Language->Categorisations->Categorisation->Level[0];
        $subCategory=$xml->Data->Language->Categorisations->Categorisation->Level[1];
        $subSubCategory=$xml->Data->Language->Categorisations->Categorisation->Level[2];
        $lifestyle=$xml->Data->Language->ItemTypeGroup->Statements->Statement;
        $allergyAdvice=self::buildAllergyAdviceString($xml);
        $manufacturersAddress=self::getNodeValueForAttribute($xml->Data->Language->ItemTypeGroup->Memo, 'Name', 'Manufacturers Address');
        $furtherDescription=self::getNodeValueForAttribute($xml->Data->Language->ItemTypeGroup->Memo, 'Name', 'Further Description');
        $brand=self::getNodeValueForAttribute($xml->Data->Language->ItemTypeGroup->NameLookups, 'Name', 'Standardised Brand')->NameValue;
        $companyName=self::getNodeValueForAttribute($xml->Data->Language->ItemTypeGroup->LongTextItems, 'Name', 'Company Name');
        $ingredients=self::getIngredients($xml);
        
        // Nutrition names MUST be in lowercase.
        $nutritionTextEnergyKCal=self::getTextualNutrientValue($xml, array('energy kcal','energy (kcal)', 'energy','kcal','(kca)','(kcal)'));
        $nutritionTextEnergyKJoules=self::getTextualNutrientValue($xml, array('energy (kj)', 'energy kj', 'energy','kj'));  
        $nutritionTextFat=self::getTextualNutrientValue($xml, array('fat (g)','fat'));
        $nutritionTextSatFat=self::getTextualNutrientValue($xml, array('of which saturates','saturates','of which are saturates','of which saturates (g)'));
        $nutritionTextSalt=self::getTextualNutrientValue($xml, array('salt (g)', 'salt')); 
        $nutritionTextSugar=self::getTextualNutrientValue($xml, array('of which sugars','- sugars', 'of which sugars', 'sugars','of which are sugars','of which sugars (g)','of which sugar'));
        $nutritionTextProtein=self::getTextualNutrientValue($xml, array('protein','protein (g)'));
        $nutritionTextCarbohydrate=self::getTextualNutrientValue($xml, array('carbohydrate', 'carbohydrate (g)',  'of which starch (g)', 'starch','carbohydrates','carbohydrates (g)')); 
        $nutritionTextFibre=self::getTextualNutrientValue($xml, array('fibre','fibre (g)','dietary fibers (g)'));
        $nutritionTextCholesterol=self::getTextualNutrientValue($xml, array('cholesterol'));
        
        $nutritionNumEnergyKCal=self::getNumericNutritionValue($xml, array('energy kcal','energy (kcal)', 'energy','kcal','(kca)','(kcal)'));
        $nutritionNumEnergyKJoules=self::getNumericNutritionValue($xml, array('energy (kj)', 'energy kj', 'energy','kj'));  
        $nutritionNumFat=self::getNumericNutritionValue($xml, array('fat (g)','fat'));
        $nutritionNumSatFat=self::getNumericNutritionValue($xml, array('of which saturates','saturates','of which are saturates','of which saturates (g)'));
        $nutritionNumSalt=self::getNumericNutritionValue($xml, array('salt (g)', 'salt')); 
        $nutritionNumSugar=self::getNumericNutritionValue($xml, array('of which sugars','- sugars', 'of which sugars', 'sugars','of which are sugars','of which sugars (g)','of which sugar'));
        $nutritionNumProtein=self::getNumericNutritionValue($xml, array('protein','protein (g)'));
        $nutritionNumCarbohydrate=self::getNumericNutritionValue($xml, array('carbohydrate', 'carbohydrate (g)',  'of which starch (g)', 'starch','carbohydrates','carbohydrates (g)')); 
        $nutritionNumFibre=self::getNumericNutritionValue($xml, array('fibre','fibre (g)','dietary fibers (g)'));
        $nutritionNumCholesterol=self::getNumericNutritionValue($xml, array('cholesterol'));
        
      
        $frontOfPack=self::getFrontOfPackInfo($xml);
        $allergyText=self::getNodeValueForAttribute($xml->Data->Language->ItemTypeGroup->TaggedMemo, 'Name', 'Taggable Allergy Text');
        $imageRef=self::getImageRef($xml, 'ID Shot');
        $regulatedProductName=self::getNodeValueForAttribute($xml->Data->Language->ItemTypeGroup->Memo, 'Name', 'Regulated Product Name');
        $nutritionVals = array('category_number'=>'1', 'engerykcal'=>$nutritionNumEnergyKCal, 'fat'=>$nutritionNumFat, 'satfat'=>$nutritionNumSatFat, 'salt'=>$nutritionNumSalt,
        'sugar'=>$nutritionNumSugar, 'fibre'=>$nutritionNumFibre);
        $settingVals=self::getSettingVals($nutritionVals);
                
        $product = array('barcode'=>$barcode, 
        'product_code'=>$productCode, 
        'product_title'=>$productTitle, 
        'category'=>$category, 
        'sub_category'=>$subCategory,
        'sub_sub_category'=>$subSubCategory, 
        'lifestyle'=>$lifestyle, 
        'allergy_advice'=>$allergyAdvice, 
        'manufacturers_address'=>$manufacturersAddress, 
        'further_description'=>$furtherDescription,
        'brand'=>$brand, 
        'company_name'=>$companyName, 
        'ingredients'=>$ingredients, 
        
        'nutrition_txt_energykcal'=>$nutritionTextEnergyKCal, 
        'nutrition_txt_energykjoules'=>$nutritionTextEnergyKJoules, 
        'nutrition_txt_fat'=>$nutritionTextFat,
        'nutrition_txt_satfat'=>$nutritionTextSatFat,
        'nutrition_txt_salt'=>$nutritionTextSalt, 
        'nutrition_txt_sugar'=>$nutritionTextSugar, 
        'nutrition_txt_fibre'=>$nutritionTextFibre,
        'nutrition_txt_protein'=>$nutritionTextProtein,
        'nutrition_txt_carbohydrate'=>$nutritionTextCarbohydrate,
        'nutrition_txt_cholesterol'=>$nutritionTextCholesterol,
        
        'nutrition_num_energykcal'=>$nutritionNumEnergyKCal, 
        'nutrition_num_energykjoules'=>$nutritionNumEnergyKJoules, 
        'nutrition_num_fat'=>$nutritionNumFat, 
        'nutrition_num_satfat'=>$nutritionNumSatFat,
        'nutrition_num_salt'=>$nutritionNumSalt, 
        'nutrition_num_sugar'=>$nutritionNumSugar, 
        'nutrition_num_fibre'=>$nutritionNumFibre, 
        'nutrition_num_protein'=>$nutritionNumProtein, 
        'nutrition_num_carbohydrate'=>$nutritionNumCarbohydrate, 
        'nutrition_num_cholesterol'=>$nutritionNumCholesterol, 
        
        'front_of_pack'=>$frontOfPack, 
        'allergy_text'=>$allergyText, 
        'image_ref'=>$imageRef, 
        'regulated_product_name'=> $regulatedProductName, 
        'setting_vals'=>$settingVals);
                
        return $product;
    }
    
    private static function separateAllergyInfo($allergyStr){
		$allergyStr = rtrim($allergyStr,',');
		$allergyExp = explode(',', $allergyStr);
		$ret = array();
		$ret['may contain']=''; $ret['contains']=''; $ret['neither']='';
		
		foreach($allergyExp as $allergy){
			$sep = strpos($allergy, ' - ');
			$type =  trim(strtolower(substr($allergy,0,$sep)));
			$ing = trim(substr($allergy,$sep+2,strlen($allergy)));
		
				if($type=='may contain'){
					$ret['may contain'] .= $ing . ',';
				}elseif($type=='contains'){
					$ret['contains'] .= $ing . ',';
				}else{
					$ret['neither'] .= $ing . ',';
				}
		}
		$ret['may contain'] = rtrim($ret['may contain'],',');
		$ret['contains'] = rtrim($ret['contains'],',');
		$ret['neither'] = rtrim($ret['neither'],',');
		return $ret;
	}
    
    private static function xmlChildExists($elem)
	{
	 	return isset($elem);
	}
    
}