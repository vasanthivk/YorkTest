<?php
class fields{


    private static $data=array(
    
                'name'=>'Name',
                'account_type'=>'Account Type',
                'billing_address_street'=>'Address',
                'billing_address_city'=>'City',
                'billing_address_state'=>'State',
                'billing_address_country'=>'Country',
                'billing_address_zip'=>'Zip',

                'firstnames'=>'First Name',
                'surname'=>'Last Name',
                'ee_id'=>'EE ID',
                'status'=>'Status',
                'pgc_company'=>'Company',
                'category'=>'Category',
                'contractor_type'=>'Contractor Type',
                'visa'=>'Visa',
                'visa_holder'=>'Visa Holder',
                'agency'=>'Client',

                'status'=>'Status',
                'contract_type'=>'Contract Type',
                'work_address_street'=>'Worksite Address',
                'work_address_city'=>'City',
                'work_address_state'=>'State',
                'work_address_country'=>'Country',
                'work_address_zip'=>'Zip',
                'start_date'=>'Start Date',
                'end_date'=>'End Date',
                'pay_rate'=>'Pay Rate',
                'pay_per'=>'Pay Per',
                'pay_currency'=>'Pay currency',
                'bill_rate'=>'Bill Rate',
                'management_fee'=>'Total PGC Fee %',
                'wc_rate'=>'WC Fee %',
                'er_tax_rate'=>'ER Burden Fee %',
                'pgc_mgmt_fee'=>'Mgmt Fee %',
                'job_title'=>'Job Title',
                'job_description'=>'Job Description',
                'notes'=>'Notes',
                'assigned_user_id'=>'Assigned User',
                'account_name'=>'Client',
                'client_name'=>'End Client',
                'account_id'=>'Client',
                'client_account_id'=>'End Client',
                'candidate_ref'=>'Candidate',
                'c2c_ref'=>'C2C',
                'invoice_frequency'=>'Invoice Frequency',
                'payment_frequency'=>'Payment Frequency',
                'exempt_status'=>'Exempt Status',
                'invoice_terms'=>'Invoice Terms',
                'date_entered'=>'Date Created',
                'created_by'=>'Created By',
                'date_modified'=>'Date Modified',
                'modified_user_id'=>'Modified User',
                'deleted'=>'Deleted',
                'contractname'=>'Name',

                'issue_no'=>'Issue No'
        );
        

    static function fieldTitle($field){
        $ret='';
        $f=h::safeArray(self::$data,$field);
        if($f==''){
            return form::tidyLabel($field);
        }else{
            return $f;
        }
    }
    
}
?>