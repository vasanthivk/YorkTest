<?php


class view2{

    static function viewData($table){
        $sort='';
        $limit='';
        if(h::sa($_SESSION,'view','order')!=''){
            $sort=' order by '.$_SESSION['view']['order'];
        }
        
        if(h::safeArray($_SESSION,'view','sql')!=''){
            $sql=$_SESSION['view']['sql'];
            $parms=$_SESSION['view']['parms'];
        }else{
        	$sql='select * from '.$table;
        	$parms=array();
        }
        
        
        
        $search='';
        $searchfield='';
        if(h::safeArray($_SESSION,'view','search')!=''){
                $column=$_SESSION['view']['column'];
            if(substr($_SESSION['view']['search'],0,1)=='#'){
                $search.=' and '.$column.' = :search';
                $searchfield=substr($_SESSION['view']['search'],1);
                $parms[':search']=$searchfield;
            }else{
                $search.=' and '.$column.' like :search';
                $parms[':search']='%'.$_SESSION['view']['search'].'%';
                $searchfield=$_SESSION['view']['search'];
            }
        }
        


        


        
        $countQ='select count(*) as cc from ('.$sql.$search.') as t1';
        $d1=dbpdo::getQuery($countQ,$parms);
        $searchTotal=$d1['cc'];
        $sql=$sql.$search.' '.$sort.' '.$limit;
        $dontShow=array('assigned_user_id','created_by','modified_user_id','deleted');
        $ret='<table class="table ana-tbl highlight" data-table="'.$table.'">';
        $first=true;
        $fields='[';
        $rowCount=0;
	    $dateFields=array('lastlogintime','start_date','end_date','date_entered');
    	if($stmt=dbpdo::query($sql,$parms)){
    	    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
    	    	$rowCount++;
    	    	if($first){
    	    		$ret.='<thead><tr class="act-col-search">';
    	    		foreach($row as $key=>$value){
    	    		    if(!in_array($key,$dontShow)){
        	    			$ret.='<th><a href="#" data-fname="'.$key.'">';
            	    			$ret.='<b>'.fields::fieldTitle($key).'</b>';
        	    			$ret.='</a>';
    	    		    }
    	    		$ss='';
    	    		$class=' ';
    	    		if(h::sa($_SESSION,'view','column')==$key){
    	    		    $ret.='<s class="act-reset">'.$searchfield.'</s>';   
    	    		}
    	    			$ret.='</th>';
    	    			$fields.='"'.$key.'",';
    	    		}
    	    		$ret.='<tr/></thead><tbody>';
    	    		$first=false;
    	    	}
    	    	$nowTime=time();
    	    	$rowClass="";
    	    	if(h::safeArray($row,'active')=='No'){
    	    	    $rowClass="del-row";    
    	    	}
    	    	$ret.='<tr class="'.$rowClass.'" data-ref="'.self::dbCode($table,h::sa($row,'ref')).'">';
    	    		foreach($row as $key=>$item){
    	    		    if(!in_array($key,$dontShow)){
    	    		    	$class="";
        	    		    if($key=='ref'){
        	    		        $dd='<a href="#'.self::dbCode($table,$item).'" class="act-detail"><i class="material-icons">mode_editt</i></a>';
        	    		    }else{
        	    		        $dd=self::mapId($key,$item);
        	    		    }
        	    		    if($key=='date_modified' or $key=='lastlogintime'){
        	    		        $dd=dbpdo::usaDate($item,true);
        	    		    }elseif(in_array($key,$dateFields)){
        	    		        $dd=dbpdo::usaDate($item);
        	    		    }
        	    		    if($key=='notes'){
        	    		        if($item!=''){
        	    		            $dd='<a href="#" class="act-notes"><i class="material-icons">comment</i></a>';
        	    		            
        	    		        }else{
        	    		            $dd='';
        	    		        }
        	    		    }
        	    		    $dd=self::linkField($dd);
        	    		    
            	    		if(strlen($item)>90 and $key!='issue'){
        	    		        $item=substr($item,0,20).'...';
        	    		    }
        	    		    $rss=0;
        	    		    $title='';
        	    		    $class='';
        	    		    $spike='';
        	    		    if($key=='start_date'){
        	    		    	$sd=strtotime($row['start_date']);
        	    		    	$ed=strtotime($row['end_date']);
        	    		    	if($nowTime>=$sd and $nowTime<=$ed){
        	    		    		$class="date-inrange";
        	    		    		$duration=round(($ed-$sd)/86400);
        	    		    		$soFar=round(($ed-$nowTime)/86400);
                                    $title=$soFar.'/'.$duration;
        	    		    		$perc=(round(($soFar/$duration)*100)*2);
                                   $spike='<p style="left:'.$perc.'%">.</p>';
        	    		    	}else{
        	    		    		if($nowTime<$sd){
        	    		    			$title='-'.round(($sd-$nowTime)/86400);
        	    		    			$class="date-before";
        	    		    		}
        	    		    	}
        	    		    }
        	    		    if($key=='end_date'){
        	    		    	$sd=strtotime($row['start_date']);
        	    		    	$ed=strtotime($row['end_date']);
        	    		    	if($nowTime>=$sd and $nowTime<=$ed){
        	    		    		$class="date-inrange";
        	    		    		$duration=round(($ed-$sd)/86400);
        	    		    		$soFar=round(($ed-$nowTime)/86400);
                                    $title=$soFar.'/'.$duration;
        	    		    	}else{
        	    		    		if($nowTime>$ed){
        	    		    			$title='+'.round(($nowTime-$ed)/86400);
        	    		    			$class="date-after";
        	    		    		}
        	    		    	}
        	    		    }
        	    		    $tt='';
        	    		    if($title!=''){
        	    		    	$tt=' data-extra="'.$title.'" ';
        	    		    }
							$cc='';
    	    		    	if($class!=''){
        	    		    	$cc=' class="'.$class.'" ';	
    	    		    	}
    	    		    	
    	    		    	$ret.='<td'.$tt.$cc.'>'.$spike.$dd.'</td>';
        	    		    
        	    		    
    	    		    }
    	    			
    	    		}
    	    	
    	    	$ret.='</tr>';
    	    }
    	}
    	$ret.='</tbody></table>';
    	
    	$fields=rtrim($fields,',').']';
    	echo '<script>';
    	echo 'var fields='.$fields.';';
    	echo 'var rowCount='. $searchTotal.';';
    	echo '</script>';
    	
    	return $ret;
    	
    }
    
    static function percent($num_amount, $num_total){
		$count1 = $num_amount / $num_total;
		$count2 = $count1 * 100;
		$count = number_format($count2, 0);
		return $count;
    }
    
    static function mapId($key,$item){
	    if(substr($key,-3)=='_id' or $key=='created_by'){
	        $dd=users::getName($item);
	        if($dd==$item){
	            $dd=team::getName($item);
	        }
	    }else{
	        $dd=$item;
	    }
	    return $dd;
        
    }
    
    static function linkField($dd){
	    if(strpos($dd,'||')===false){
	        
	    }else{
	        $x=explode('||',$dd);
	        $r='<a href="#'.$x[1].'" class="act-detail">';
	        if($x[0]==''){
	            $r='...';   
	        }else{
	            $r.=$x[0];    
	        }
	        $r.='</a>';
	        $dd=$r;
	    }
	    return $dd;
        
    }
    
    static function changesLine($data){
        $ret= '<div class="right changes-line">';
            $ret.= '<i class="material-icons">schedule</i>';
            $ret.= '<b class="targ-user">'.h::safeArray($data,'created_by').'</b> ';
            $ret.= dbpdo::usaDate(h::safeArray($data,'date_entered'),true).' ';
            $ret.= '<i class="material-icons">mode_edit</i>';
            $ret.= '<b class="targ-user">'.h::safeArray($data,'modified_user_id').'</b> ';
            $ret.= dbpdo::usaDate(h::safeArray($data,'date_modified'),true).' ';
            //$ret.= $data['date_modified'];
        $ret.= '</div>';
        return $ret;
        
    }
    

    static function showTopNav(){
        $ret='<a href="#clear" class="bt inv act-search-tools">Clear</a>';
        $ret.='<a href="#my" class="bt act-search-tools">Assigned to Me</a>';
        //$ret.='<a href="#stars" class="act-search-tools">My Stars</a>';
        $ret.='<a href="#created" class="bt act-search-tools">Recently Created</a>';
        $ret.='<a href="#updated" class="bt act-search-tools">Recently Updated</a>';
       return $ret; 
    }
    
	static function showPaging(){
	    $ret='<div class="col s12 m4 right-align">';
	    $ret.='<i class="material-icons">view_list</i>';
	        $ret.='<small class="targ-rowcount"></small>';
	        $ret.='<a href="#down" class="act-page"><i style="vertical-align:middle;" class="material-icons">chevron_left</i></a>';
	        $ret.='<span id="ctrl-page-no" contenteditable=true>1</span> /';
	        $ret.='<span id="ctrl-page-max">1</span>';
	        $ret.='<a href="#up" class="act-page"><i class="material-icons">chevron_right</i></a>';
	    $ret.='</div>';
	    return $ret;
	}
    
    static function dbCode($inTable,$ref){
    	log::logInfo('dbcode '.$inTable);
        $codes=array('_products'=>'A'
                    
                    );
        return $codes[$inTable].$ref;
    }
    
    static function rootTables($code){
        $tables=array('A'=>'_products'
        );
        return $tables[$code];
    }
    
    static $ref='';
    
    static function getRef(){
        return self::$ref;    
    }
    
    

    static function loadView($ref){
        $links=array('A'=>'productview.php'
                    );
        $dbCode=substr($ref,0,1);
        self::$ref=substr($ref,1);
        include '../admin/'.$links[$dbCode];
    }
    
    
    
}




?>