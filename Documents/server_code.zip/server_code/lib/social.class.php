<?php


class social{
    
    static function socialsearch($search=''){
    	$ret='';
		$zebra='';
		$sql='select sharing.*, product_title 
			from sharing 
			left join _products_import2 on (barcode=_products_import2.barcode_number)
		   	where 
		   	handle like "%'.$search.'%" or comments like "%'.$search.'%" or groups like "%'.$search.'%" or status like "%'.$search.'%"
		   	order by sharedate desc
		   	limit 100;';
    	
    	$fields='Handle, Groups, Comment, Product, Date,';
    	$ret.= table::head('table obtable tstable',$fields,true);
		if($stmt=dbpdo::query($sql)){
			$ret.='<h4>Social</h4>';
		    while($row = $stmt->fetch()){
//				$ret.=$row['handle'].' '.$row['comments'].' '.$row['product_title'].' '.$row['sharedate'].'<br/>';	    
		        if($row['status']!='Submitted'){
			        $row['button']=$row['status'];
		        }else{
			        $row['button']='
			        	<div class="btnStatus-'.$row['ref'].'">
			        		<a href="#" class="btn-grid act-btn-approve" data-ref="'.$row['ref'].'" data-action="Approve">Approve</a>
			        		<a href="#" class="btn-grid act-btn-approve" data-ref="'.$row['ref'].'" data-action="Reject">Reject</a>
			        	</div>
			        ';
		        }
		        $ret.= table::dataRow($row,'handle,groups,comments,product_title,sharedate,button',true,$zebra);
		        if($zebra==''){
		            $zebra='zebra';
		        }else{
		            $zebra='';
		        }
		    }	
		}
		$ret.= table::close();
		return $ret;
    }
    
    
}


?>