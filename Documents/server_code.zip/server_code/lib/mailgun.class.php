<?php


class mailgun{
    
    
        static function sendEmail($toName,$to,$subject,$text,$ref=100,$fromName,$fromEmail,$attachments=array()){
            $data=array('from'=>$fromName.' <'.$fromEmail.'>',
                        'to'=>$toName.' <'.$to.'>',
                        'subject'=>$subject,
                        'html'=>$text,
                        'v:my-custom-data' => '{“qref”: '.$ref.'}'
                        );
            foreach($attachments as $file){
                //echo '/mnt/stor8-wc2-dfw1/478117/code.clevertech.tv/web/content/cxx/workspace/cinevents/content/admin/'.$file;
                echo $file;
            	$data['file[admin.css]']='@'.$file;
           	}
            $ret=self::apiCall('messages',$data);
            log::logInfo('MAILGUN RETURN');
            log::logInfo($ret);
        }
        
        static function webHook(){
     		log::logInfo('Mailgun event - '.clean::get('e'));
    		log::logInfo(clean::post());
    		$refObj=clean::post('my-custom-data');
    		
    		
    		log::logInfo('*** ref ***');
    		log::logInfo($refObj);
    		$r=self::jsonMailgun($refObj);
    		$ref=$r['qref'];
    		log::logInfo($ref);
    		
    		
    		$fields=array('laststatus'=>clean::get('e'),'laststatustime'=>dbpdo::now());
    		$activeStatus=array('delivered','failed','opened','clicked');
    		if(in_array(clean::get('e'),$activeStatus)){
    		    $fields[clean::get('e')]=dbpdo::now();   
    		}
    		
    		
    	//	dbpdo::dbUpdate('emailqueue',$ref,$fields);
       	
        }
        
        static function listHooks(){
                self::apiCall('webhooks',array(),array('domain'=>'domains/'));
        }
        
        static function clearHooks(){
            $data=array('id'=>'deliver');
            self::apiCall('webhooks',$data,array('domain'=>'domains/','method'=>'DELETE'));
        }
        
        static function createHook(){
            $data=array('id'=>'deliver',
                        'url'=>'http://code.clevertech.tv.php54-3.dfw1-2.websitetestlink.com/cxx/workspace/profiles/content/login/gunin.php');
            self::apiCall('webhooks',$data,array('domain'=>'domains/'));
            
        }
    
    
    
    
    
    
    

        static function apiCall($method='messages',$data=array(),$inOpts=array()){
            $default=array('method'=>'POST',
                            'domain'=>'',
            
            );
            $options=array_merge($default,$inOpts);
            $url='https://api.mailgun.net/v3/'.$options['domain'].'profiles.contactconsultinguk.com/'.$method;
            $privateKey='key-70op2mhuk5i6qmq3o5x89oh1v49vulc3';
            $ch = curl_init();
            //curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-type: multipart/form-data"));
            curl_setopt($ch, CURLOPT_USERPWD, "api:" . $privateKey); 
            curl_setopt($ch, CURLOPT_URL,$url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt ($ch, CURLOPT_VERBOSE, 1);
            if(sizeof($data)!=0){
                $query=http_build_query($data);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS,$query);
            }else{
                curl_setopt($ch, CURLOPT_POST, 0);
            }
            if($options['method']!='GET'){
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $options['method']);
            }
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $server_output = curl_exec ($ch);
            curl_close ($ch);
            print_r($server_output);
            return $server_output;
        }
        
        private static function jsonMailgun($json){
		    $json=str_replace('“','"',$json);
		    $json=str_replace('”','"',$json);
		    return json_decode($json,true);
		}



    
}


?>