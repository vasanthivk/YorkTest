<?php

class history{
    
    static function addItem($table,$ref,$desc){
        $fields=array(
            'tablename'=>$table,
            'userref'=>$_SESSION['user']['ref'],
            'recordref'=>$ref,
            'description'=>$desc,
            'dateviewed'=>dbpdo::now()
        ); 
        $sql='select ref from history where userref=:uref and tablename=:tbl and recordref=:ref limit 1';
        $parms=array(':uref'=>$_SESSION['user']['ref'],':tbl'=>$table,':ref'=>$ref);
        if($data=dbpdo::getQuery($sql,$parms)){
            dbpdo::dbUpdate('history',$data['ref'],$fields);    
        }else{
            dbpdo::dbInsert('history',$fields);   
        }
        
        $fields=array('last_view_id'=>view::dbCode($table,$ref),
                        'last_view_name'=>$desc,
                        'date_modified'=>dbpdo::now()
                        );
        dbpdo::dbUpdate('person',$_SESSION['user']['ref'],$fields);
        
        
    }
    
    
}


?>