<?php


class team{
    
    static $team=false;
    
    static function loadTeam(){
        if(!self::$team){
            $fields='ref,name,name_2';
	        $sql='select '.$fields.' from teams';
    		if($stmt=dbpdo::query($sql)){
    			while($row = $stmt->fetch()){
    			    self::$team[$row['ref']]=$row;
    			}
    		}
        }
    }
    
    static function getName($id){
        self::loadTeam();
        if(array_key_exists($id,self::$team)){
            return '<b>'.self::$team[$id]['name'].' '.
            self::$team[$id]['name_2'].'</b> ';
        }else{
            return $id;
        }
    }
    
    
    
}


?>