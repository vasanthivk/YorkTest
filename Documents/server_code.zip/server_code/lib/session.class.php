<?php

class session{
 
 
    static function get($section,$item,$default=''){
        if($_SESSION){
            if(array_key_exists($section,$_SESSION)){
                if($item!=''){
                    if(array_key_exists($item,$_SESSION[$section])){
                        return $_SESSION[$section][$item];
                    }else{
                        return $default;
                    }
                }else{
                    return $_SESSION[$section];
                }
            }else{
                return $default;
            }
            
        }else{
            return $default;
        }
    }
    
}




?>