<?php

class messages{
	
	static function active(){
		$ret=array();
		$sql='select * from messages';
		if($stmt=dbpdo::query($sql)){
		    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		    	$ret[$row['title']]=$row;
		    }
		}
		echo json_encode($ret);
	}
	
	
	
}


?>