<?php


class dash{
	
	
	static function drawCell($title,$mode,$height='',$cells=3,$refreshBlock='',$static=''){
		$ret='';
		$ret.='<div class="col s12 m'.$cells.' '.$height.' dash-item dash-refresh-'.$refreshBlock.'">';
			$ret.='<div class="dash-item-inner">';
				$ret.='<h4>'.$title.'</h4>';
				$ret.=$static;
				$ret.='<div class="dash-item-targ" data-mode="'.$mode.'">';
					$ret.='Content goes here';
				$ret.='</div>';
			$ret.='</div>';
		$ret.='</div>';
		return $ret;
	}
	
	static function productCount(){
		$sql='select count(*) as cc from _products_import2';
		$parms=array(':yes'=>'Yes');
		if($data=dbpdo::getQuery($sql,$parms)){
			return '<h2 class="dash-has-label">'.$data['cc'].'<span>Products</span></h2>';
		}
		return '';
	}
	
 
    static function barcodesTotals($today=false){
        $parms=array(':type'=>'barcode');
		$where='';
		if($today){
			$where=' and date_created > "'.date('Y-m-d').' 00:00:00'.'"';
		}
        $sql='select product_title ,scannedcodes.barcode_number,datakey,count(*) as productcnt 
                from scannedcodes 
                left join _products_import2 on (datakey=_products_import2.barcode_number)
                where type=:type '.$where.'group by datakey order by productcnt desc limit 10;';
        $ret='';

    	
        $zebra='dash-zebra';
    	if($stmt=dbpdo::query($sql,$parms)){
    	    while($row = $stmt->fetch()){
    	    	$ret.='<div class="act-barcode-drill dash-row s12 '.$zebra.'" data-barcode="'.$row['datakey'].'">';
	    	    	$ret.='<div class="col s2">'.$row['productcnt'].'</div>';
	    	    	if($row['product_title']!=''){
	    	    		$ret.='<div class="col s10">'.$row['product_title'].'</div>';
	    	    	}else{
	    	    		$ret.='<div class="col s10 dash-alert">'.$row['datakey'].'</div>';	
	    	    	}
    	    	$ret.='</div>';
    	    	if($zebra==''){
    	    		$zebra='dash-zebra';	
    	    	}else{	
    	    		$zebra='';
    	    	}
    	    }
    	}
        return $ret;
    }


    static function lastScans(){
        $parms=array();
        $sql='select product_title ,scannedcodes.barcode_number,datakey,date_created,email
                from scannedcodes 
                left join _products_import2 on (datakey=_products_import2.barcode_number)
                order by date_created desc limit 40;';
        $ret='';

        $zebra='dash-zebra';
    	if($stmt=dbpdo::query($sql,$parms)){
    	    while($row = $stmt->fetch()){
    	    	$ret.='<div class="act-barcode-drill dash-row s12 '.$zebra.'" data-barcode="'.$row['datakey'].'">';
    	    		$ret.='<div class="col s2">'.date('H:i:s',strtotime($row['date_created'])).'</div>';
    	    		if($row['product_title']!=''){
	    	    		$ret.='<div class="col s10">'.$row['product_title'].'<small>'.$row['email'].'</small></div>';
    	    		}else{
    	    			$ret.='<div class="col s6 dash-alert">'.$row['barcode_number'].'</div>';
    	    			$ret.='<div class="col s4">'.$row['email'].'</div>';
    	    		}
    	    	$ret.='</div>';
    	    	if($zebra==''){
    	    		$zebra='dash-zebra';	
    	    	}else{	
    	    		$zebra='';
    	    	}
    	    }
    	}
        return $ret;
    }
    
    static function barcodeExpand($barcode){
    	$front=substr($barcode,0,2);
    	if($front=='02'){
    		$price=substr($barcode,6,6);
    		return $barcode.' <span class="dash-catch">C</span> &pound;'.$price;
    	}else{
    		return $barcode;
    	}
    }




    static function barcodesbyDay(){
        $sql='select product_title ,count(*) as productcnt ,DATE_FORMAT(date_created, "%d-%M") as day
                from scannedcodes 
                left join _products_import2 on (datakey=_products_import2.barcode_number)
                where type=:type group by datakey, day(date_created) order by day desc limit 30;';
        $parms=array(':type'=>'barcode');
        $ret='';
    	if($stmt=dbpdo::query($sql,$parms)){
    	    while($row = $stmt->fetch()){
                $ret.=$row['day'].' - '.$row['product_title'].' - '.$row['productcnt'].'<br/>';
    	    }
    	}
        return $ret;
    }

    static function barcodesToday($offset=''){
    	if($offset==''){
    		$datetime=date('Y-m-d').' 00:00:00';
    	}else{
    		$datetime=dbpdo::now($offset);
    	}
        $sql='select code_found,count(*) as productcnt 
                from scannedcodes 
                where type=:type and date_created > "'.$datetime.'"
                group by code_found;';
        $parms=array(':type'=>'barcode');
        $ret='';
        $temp=array();
    	if($stmt=dbpdo::query($sql,$parms)){
    	    while($row = $stmt->fetch()){
    	    	$temp[$row['code_found']]=$row['productcnt'];
    	    	if($row['code_found']=='Yes'){
    	    		
    	    	}else{
    	    		
    	    	}
                //$ret.=$row['code_found'].' - '.$row['productcnt'].'<br/>';
    	    }
    	}
    	$ret.='<h1 class="dash-has-label">'.self::arrayZero($temp,'Yes').'<span>Pass</span></h1>';
    	$ret.='<h3 class="dash-has-label dash-warn">'.self::arrayZero($temp,'No').'<span>Fail</span></h3>';
        return $ret;
    }
    
    
    static function arrayZero($array,$item){
    	if(array_key_exists($item,$array)){
    		return $array[$item];
    	}else{
    		return '0';
    	}	
    }

    static function users($today=false){
		$where='';
		if($today){
			$where=' where date_entered > "'.date('Y-m-d').' 00:00:00'.'"';
		}
        $sql='select count(*) as usercnt 
                from appusers 
                '.$where;
        $ret='';
    	if($stmt=dbpdo::query($sql)){
    	    while($row = $stmt->fetch()){
                $ret.='<h1>'.$row['usercnt'].'</h1>';
    	    }
    	}
        return $ret;
    }

    static function scansByUser($offset=''){
    	if($offset==''){
    		$datetime=date('Y-m-d').' 00:00:00';
    	}else{
    		$datetime=dbpdo::now($offset);
    	}
        $sql='select count(*) as productcnt, email 
                from scannedcodes 
                where type=:type and date_created > "'.$datetime.'"
                group by email order by productcnt desc limit 10;';
        $parms=array(':type'=>'barcode');
        $ret='';
        $zebra='dash-zebra';
    	if($stmt=dbpdo::query($sql,$parms)){
    	    while($row = $stmt->fetch()){
    	    	$ret.='<div class="dash-row s12 '.$zebra.'">';
	    	    	$ret.='<div class="col s2">'.$row['productcnt'].'</div>';
	    	    	$ret.='<div class="col s10">'.$row['email'].'</div>';
    	    	$ret.='</div>';
    	    	if($zebra==''){
    	    		$zebra='dash-zebra';	
    	    	}else{	
    	    		$zebra='';
    	    	}
    	    }
    	}
        return $ret;
    }
    
     static function lastestSignUps($offset=''){
    	if($offset==''){
    		$datetime=date('Y-m-d').' 00:00:00';
    	}else{
    		$datetime=dbpdo::now($offset);
    	}
        $sql='select * from appusers order by date_entered desc limit 10;';
        //$parms=array(':type'=>'barcode');
        $ret='';
        $zebra='dash-zebra';
    	if($stmt=dbpdo::query($sql)){
    	    while($row = $stmt->fetch()){
    	    	$ret.='<div class="dash-row s12 '.$zebra.'">';
	    	    	$ret.='<div class="col s3">'.date('d/m/y H:i',strtotime($row['date_entered'])).'</div>';
	    	    	$ret.='<div class="col s9">'.$row['email'].'</div>';
    	    	$ret.='</div>';
    	    	if($zebra==''){
    	    		$zebra='dash-zebra';	
    	    	}else{	
    	    		$zebra='';
    	    	}
    	    }
    	}
        return $ret;
    }


    static function scansByHour($offset=''){
   		$datetime=dbpdo::now('-1 day');
        $sql='SELECT HOUR(`date_created`) as hour, COUNT(*) as cnt 
        		FROM `scannedcodes` 
        		where date_created > "'.$datetime.'"
        		group by HOUR(`date_created`);';
        $parms=array();
        $data=array();
    	if($stmt=dbpdo::query($sql,$parms)){
    	    while($row = $stmt->fetch()){
                $data[$row['hour']]=$row['cnt'];
    	    }
    	}
    	
    	
    	$ret=self::graph($data);
        return $ret;


    }
    
    static function pipTrack(){
    	$ret='<div class="dash-pip-track"></div>';
    	return $ret;
    }
    
    static function graph($data){
    	$hour=date('H');
		$ret='<div class="graph-outline">';
		$max=0;
		foreach($data as $col){
			if($col>$max){
				$max=$col;
			}
		}
		$pip=100/$max;
		$cc=0;
		$tt=$hour;
		while($cc<24){
			if(array_key_exists($tt,$data)){
				$item=$data[$tt];
			}else{
				$item='';
			}
			$height=$pip*$item;
			$offset=100-$height;
			$width=3.999;
			$class='';
			if($hour==$tt){
				$class="graph-now";
			}
			$ret.='<div class="graph-item '.$class.'" style="bottom:0;width:'.$width.'%;height:'.$height.'%;"><div class="graph-cc">'.$item.'</div><div class="graph-ll">'.str_pad($tt,2,"0",STR_PAD_LEFT).':00</div></div>';
			$tt--;
			if($tt<0){
				$tt=23;
			}
			$cc++;
		}

		$ret.='</div>';
		return $ret;

    }
}
?>