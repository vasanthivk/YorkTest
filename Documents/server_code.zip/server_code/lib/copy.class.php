<?php

class copy{
    
    static $totalCount=0;
    static $changedCount=0;
    static $text='';
    
    
    static function getStats(){
        return array('count'=>self::$totalCount,'changed'=>self::$changedCount);
    }
    
    static function toDemo(){
        $project='cinevents';
        $rootFrom='/mnt/stor8-wc2-dfw1/478117/code.clevertech.tv/web/content/cxx/workspace/';
        $src=$rootFrom.$project;
        $dst='/mnt/stor8-wc2-dfw1/478117/cinema.clevertech.solutions/web/';
        $ret= copy::startCopy($src,$dst,$rootFrom);
        //change .htaccess and upload
        $htaccess=file_get_contents($src.'/content/.htaccess');
        $htaccess=str_replace('code.clevertech.tv/web/content/cxx/workspace/'.$project,'cinema.clevertech.solutions/web/',$htaccess);
        file_put_contents($src.'/content/.demohtaccess',$htaccess);
        copy($src.'/content/.demohtaccess',$dst.'/content/.htaccess');
        return $ret;
    }
    
    static function startCopy($src,$dst,$rootFrom){
        self::$totalCount=0;
        self::$changedCount=0;
        self::$text='';
        $ret='';
        $ret.=self::recurse_copy($src,$dst,$rootFrom);
        return $ret;
    }

    static function recurse_copy($src,$dst,$rootFrom) { 
        $dir = opendir($src);
        if(!file_exists($dst)){
            self::$text.='Create directory '.self::shortPath($dst);
            mkdir($dst);     
        }else{
            //echo '<br/>Directory - '.$dst.'<br/>';
        }
        
        while(false !== ( $file = readdir($dir)) ) { 
            if (( $file != '.' ) && ( $file != '..' )) { 
                if ( is_dir($src . '/' . $file) ) { 
                    if(strpos($file,'zz')===0){
                    }elseif(strpos($file,'cmsdata')===0){
                    }elseif(strpos($file,'settings')===0){
                    }else{
                        self::recurse_copy($src . '/' . $file,$dst . '/' . $file,$rootFrom); 
                    }
                } 
                else { 
                    $smallSrc=str_replace($rootFrom,'../',$src);
                    $pi=pathinfo($file);
                    $status='';
                    //if($pi['extension']=='log'){
                    if(h::safeArray($pi,'extension')=='log'){
                        //echo '.';
                    }else{
                        $stime=filemtime($src . '/' . $file);
                        if(file_exists($dst . '/' . $file)){
                        	$dtime=filemtime($dst . '/' . $file);
                        }else{
                        	$status='*New File*';
                        	$dtime=$stime;
                        	self::$changedCount++;
                        	self::$text.= $smallSrc . '/' . $file.' '.$status.'<br/>';
                        }
                        if($stime>$dtime){
                            self::$changedCount++;
                        	$status='*Changed*';
                            self::$text.= $smallSrc . '/' . $file.' '.$status.'<br/>';  
                        }else{
                        }
                	    
                        copy($src . '/' . $file,$dst . '/' . $file); 
                        self::$totalCount++;
                    }
                } 
            }
        } 
        closedir($dir); 
        return self::$text;
        
    }
    
    
    static function shortPath($inPath){
        $pa=explode('/',$inPath);
        $p1=array_pop($pa);
        $p2=array_pop($pa);
        return $p2.'/'.$p1;
    }

}


?>