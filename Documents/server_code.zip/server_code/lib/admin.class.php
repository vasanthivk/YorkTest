<?php


class admin{
	
	
	static function listUsers(){
		$fields='Name,Email';
		$ret= table::head ('prod-tbl',$fields);
		$sql='select * from  person order by firstnames asc';
		if($stmt=dbpdo::query($sql)){
		    while($row = $stmt->fetch()){
		    	//print_r($row);
		    		
		    	$ret.='<tr>';
		    		$ret.='<td><a href="edit_adminuser.php?ref='.$row['ref'].'" data-ref="'.$row['ref'].'">'.$row['firstnames'].' '.$row['surname'].'</a></td>';
		    		$ret.='<td>'.$row['email'].'</td>';
		    		$ret.='<td>'.$row['lastlogintime'].'</td>';
		    	
		    	$ret.='</tr>';
		    }
		}
		
		$ret.= table::close();
		return $ret;
		
	}
	
	
	
	
}


?>