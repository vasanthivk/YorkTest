<?php


class soapdebug extends SoapClient
{
  public function __doRequest($request, $location, $action, $version, $one_way = 0) {
      // Add code to inspect/dissect/debug/adjust the XML given in $request here

      // Uncomment the following line, if you actually want to do the request
      // return parent::__doRequest($request, $location, $action, $version, $one_way);
  }
}



?>