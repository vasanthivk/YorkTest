<?php


class loginsimple{

	private static $page =array();
	

	static function validate($email,$password){
	    $table=settings::getSettings('login','table');
	    
		
		$ret=false;
		$parms=array(':email'=>$email);
		$sql='select * from '.$table.' where email=:email limit 1';
		if($stmt=dbpdo::query($sql,$parms)){
			while($row = $stmt->fetch()){
				debug::add('found user',$email);
				debug::add($row['password']);
				debug::add($password);
				if(password_verify($password,$row['password'])){
					debug::add('password verified');
					$append='';
					$fields=array('failedlogins'=>0,'lastloginstate'=>'Logged In','lastlogintime'=>dbpdo::now());
					$fields['pin']=form::randomPin();
					dbpdo::dbUpdate($table,$row['ref'],$fields);
                    self::saveUserDetails($row,$append);
                    log::logSecurity('User logged in '.$email);
				    return true;
				}else{
				    $fl=$row['failedlogins'];
				    $fl++;
				    $fields=array('failedlogins'=>$fl,'lastloginstate'=>'Password failed','lastlogintime'=>dbpdo::now());
					dbpdo::dbUpdate($table,$row['ref'],$fields);
					debug::add('password failed');
					self::reportFailedLogin($email,'Failed Login *password* error');
					return false;

				}
			}

		}else{
			self::reportFailedLogin($email,'Failed Login *user* not found');
			return false;
		}
			self::reportFailedLogin($email,'Failed Login *user* not found');
			return false;
	}
	
	static function reportFailedLogin($email,$text){
	    $dev='';
	    if(array_key_exists('HTTP_CLEVVERTECH_DEV',$_SERVER)){
	        $dev='Developer '.$_SERVER['HTTP_CLEVVERTECH_DEV'];
	    }
	    $ret=$dev.' '.PHP_EOL;
	    $ret.='>'.$email;
	    $ret.=PHP_EOL.'>'.$_SERVER['REMOTE_ADDR'].PHP_EOL.$_SERVER['HTTP_USER_AGENT'];
	    log::logSecurity($text.' '.$ret);
	    slack::message($text.' '.$ret,'#failedlogins');
	}

    static function register($name, $email, $password, $passwordcheck){
		$table=settings::getSettings('login','table');
		$ret=false;
		//validate
		$parms=array('email'=>$email);
		$sql='select ref from customer where email=:email limit 1';
		if($stmt=dbpdo::query($sql,$parms)){
			$row = $stmt->fetch();
			if($row['ref']>0){
				//email already exists
				return false;
			}
		}
		if($password==$passwordcheck && strlen($name) > 4 && filter_var($email, FILTER_VALIDATE_EMAIL) && self::strongPassword($password)){
	        $namearr=explode(' ',$name);
	        $firstnames = $namearr[0];
	        if(array_key_exists("1",$namearr)){
		        $surname = $namearr[1];
	        }else{
	        	$surname='';
	        }
	        $email = $email;
	
			$password= password_hash($password, PASSWORD_BCRYPT);
	
	        $fieldlist=array('firstnames'=>$firstnames,
	                         'surname'=>$surname,
	                         'email'=> $email,
	                         'password'=>$password,
	                        );
	
			$ref=dbpdo::dbInsert($table, $fieldlist);
	       
			$parms=array(':ref'=>$ref);
			$sql='select ref, firstnames, surname, password, email from customer where ref=:ref limit 1';
			if($stmt=dbpdo::query($sql,$parms)){
				while($row = $stmt->fetch()){
	                self::saveUserDetails($row);
	                $ret=true;
				}
			}
		}
		return $ret;
        
    }


	private static function saveUserDetails($row,$append=''){
		$user=settings::getSettings('login','user');
		$_SESSION[$user]['ref']=$row['ref'];
		$_SESSION[$user]['fullname']=$row['firstnames'].' '.$row['surname'];
		$_SESSION[$user]['firstnames']=$row['firstnames'];
		$_SESSION[$user]['surname']=$row['surname'];
		$_SESSION[$user]['email']= $row['email'];
		$_SESSION[$user]['rights']=$row['adminroles'];
		$_SESSION[$user]['userrights']=$row['roles'];
		$_SESSION[$user]['browser']=md5($_SERVER['HTTP_USER_AGENT'].self::getIp());
		slack::message('login from '.$row['firstnames'].' '.$row['surname'],'#logins');
	}
	
	static function getIp(){
		$ip=h::sa($_SERVER,'109.152.130.174');
		if($ip==''){
			$ip=h::sa($_SERVER,'HTTP_X_FORWARDED_FOR');	
		}
		return $ip;
		
	}
	
	static function getUser($field=''){
		$user=settings::getSettings('login','user');
		if(array_key_exists($user,$_SESSION)){
			if(array_key_exists($field,$_SESSION[$user])){
				return $_SESSION[$user][$field];
			}else{
				return '';
			}
		}else{
			return '';
		}
	}
	
	static function changePassword($email,$password,$newpass,$checkpass){
	    $table=settings::getSettings('login','table');
	    $sql='select * from '.$table.' where email=:email limit 1;';
	    $parms=array(':email'=>$email);
	    if($data=dbpdo::getQuery($sql,$parms)){
	        if(password_verify($password,$data['password'])){
	            if(!self::strongPassword($newpass)){
	                return 'New password not strong enough - Minimum 8 characters, Uppoer/Lower case and Numeric';
	            }elseif($newpass==$checkpass){
            		$options = array('cost' => 12);
                    $encpassword= password_hash($newpass, PASSWORD_BCRYPT, $options);
                    $fields=array('password'=>$encpassword);
                    dbpdo::dbUpdate($table,$data['ref'],$fields);
                    return 'Updated';
	            }else{
	                return 'New passwords do not match';
	            }
	        }else{
	            return  'Sorry exiting password incorrect';
	        }
	    }
	}
	
    static function resetpassword($email){
        $ret=false;
        $table=settings::getSettings('login','table');
        $enc = 'W'.substr(md5(date('U').rand(1,9999)),0,8);
        log::logSecurity('Hash '.$enc);
		$options = array('cost' => 12);
        $encpassword= password_hash($enc, PASSWORD_BCRYPT, $options);
		$fields=array('password'=>$encpassword);
		dbpdo::dbUpdate($table, $email, $fields,'email');
		$parms=array(':email'=>$email);
		$sql='select ref,firstnames, surname from '.$table.' where email=:email limit 1';
		if($stmt=dbpdo::query($sql,$parms)){
			$row = $stmt->fetch();
			if($row['ref']!=''){
				$body='This is your new password:-<br/>'.$enc;
			//	$email='phil@clevertech.tv';
				if(sendgrid::send('Password Reset',$body,$email,$row['firstnames'].' '.$row['surname'])){ 
				    log::logInfo('password reset mail sent '.$email);
				    $ret=true;
				}else{
				    log::logError('password reset email send error');
				    $ret=false;
				}
			}
		}
		return $ret;		
	}
	
    static function resetpasswordssl($email){
        $ret=false;
        $table=settings::getSettings('login','table');
       
		$enc=form::generateRandomHexString(50);
       
        log::logSecurity('Hash '.$enc);
		$fields=array('hash'=>$enc,'hashdate'=>dbpdo::now());
		dbpdo::dbUpdate($table, $email, $fields,'email');
		$parms=array(':email'=>$email);
		$sql='select ref,firstnames, surname from '.$table.' where email=:email limit 1';
		if($stmt=dbpdo::query($sql,$parms)){
			$row = $stmt->fetch();
			if($row['ref']!=''){
				$url=settings::getSettings('project','url').'login/newpassword.php?email='.$email.'&enc='.$enc;
				$url='<a href="'.$url.'" >Reset Password</a>';
				$body='Click on the link to reset your password:-<br/><br/>'.$url;
			//	$email='phil@clevertech.tv';
				if(sendgrid::send('Password Reset',$body,$email,$row['firstnames'].' '.$row['surname'])){ 
				    log::logInfo('password reset mail sent '.$email);
				    $ret=true;
				}else{
				    log::logError('password reset email send error');
				    $ret=false;
				}
			}
		}
		return $ret;		
	}
	
	static function newpasswordssl($email,$hash,$password,$checkpass){
	    $ret='';
		if($password==$checkpass){
			$table=settings::getSettings('login','table');
			$sql='select ref,hash,hashdate from '.$table.' where email=:email limit 1;';
			$parms=array(':email'=>$email);
			if($data=dbpdo::getQuery($sql,$parms)){
	            if(self::strongPassword($password)){
					if($data['hash']==$hash){
						$datetime1 = new DateTime($data['hashdate']);
						$datetime2 = new DateTime(dbpdo::now());
						$interval = $datetime1->diff($datetime2);
						$days=$interval->format('%a');
						if($days<1){
							$options = array('cost' => 12);
							$encpassword= password_hash($password, PASSWORD_BCRYPT, $options);
							$fields=array('password'=>$encpassword,'hash'=>'','hashdate'=>'0000-00-00 00:00:00');
							dbpdo::dbUpdate($table,$data['ref'],$fields);
							$ret='';
						}else{
							$ret='Link expired - please reset password again';
						}
					}else{
						$ret='Invalid link - please reset password again';
					}
	            }else{
	                $ret='New password not strong enough - Minimum 8 characters, Uppoer/Lower case and Numeric';
	            }
			}else{
				$ret='Password reset failed';
			}
		}else{
			$ret='New passwords do not match';
		}
		return $ret;
	}
	
	static function isLoggedIn(){
		$user=settings::getSettings('login','user');
		if(array_key_exists($user,$_SESSION)){
    		if($_SESSION[$user]['browser']=md5($_SERVER['HTTP_USER_AGENT'].self::getIp())){
    			debug::add('logged in');
    			return true;
    		}else{
    			debug::add('NOT logged in');
    			return false;
    		}
		}else{
		       debug::add('NOT logged in - no session');
		    return false;
		}
	}

    private static function strongPassword($pwd) {
        if (preg_match("#.*^(?=.{8,20})(?=.*[a-zA-Z])(?=.*[0-9]).*$#", $pwd)) {
            return true;
        } else {
            return false;
        }
    }
    
    static function inFileList($fileList=array()){
        $rp=pathinfo($_SERVER['SCRIPT_NAME']); 
        if(in_array($rp['filename'],$fileList)){
            return true;
        }else{
            return false;
        }
    }

    static function inPathList($fileList=array()){
        $rp=pathinfo($_SERVER['SCRIPT_NAME']);
        $dn=explode('/',$rp['dirname']);
        $d=array_pop($dn);
        if(in_array($d,$fileList)){
            return true;
        }else{
            return false;
        }
    }

    
    static function hasAdminRight($right='user'){
        debug::add('User Rights check',self::getUser('rights'));
		if(strpos(self::getUser('rights'),$right)===false){
			return false;
		}else{
			return true;
		}	    	
    }
	
	public static function getSecret(){
	    $user=settings::getSettings('login','user');
		$parms=array(':ref'=>$_SESSION[$user]['ref']);
		$sql='select secret from person where ref=:ref limit 1';
		$stmt=dbpdo::query($sql,$parms);
		if ($stmt) {
			$row = $stmt->fetch();
		}
		return $row['secret'];
	}
	
	static function getUserx(){
	    if(array_key_exists('user',$_SESSION)){
	        if(array_key_exists('fullname',$_SESSION['user'])){
	            return $_SESSION['user']['fullname'];
	        }else{
	            return 'No Name in session';
	        }
	    }else{
	        return 'Not Logged in';
	    }
	}
    
    static function permission($permission='code'){
        debug::add('User permission check',self::getUser('rights'));
		if(strpos(self::getUser('rights'),$permission)===false){
			secure::redirect('../login/login.php');
		}else{
			return true;
		}	    	
    }

}


?>