<?php

require_once(__DIR__.'../../content/aws/aws.phar');

use Aws\Credentials\Credentials;
use Aws\Ses\SesClient;
use Aws\Ses\Exception;
use Aws\CommandPool;

class ses{
	
	private static $client;
	const BATCHSIZE = 20;
	
	static function init($reload=false){
    	if(!isset(self::$client) or $reload){  
		try {
				$credentials = new Credentials(settings::getSettings('amazonSES', 'accesskey'), settings::getSettings('amazonSES', 'Secretkey'));
			    $ses = new SesClient([
			    'credentials' => $credentials,
    			'version' => 'latest',
    			'region'  => 'eu-west-1'
				]);
				self::$client = $ses;
			} catch (Exception $e) {
				debug::add('AWS SES error',$e->getMessage());
			    die();
			}
        	return self::$client;
    	}
	}
	
	



	static function send($subject,$html,$toAddress,$toName,$bcc='',$from='reset@foodadvisr.com',$path='',$file='')
	{
			self::init();
			$fromname='reset@foodadvisr.com';
			 $params = array(
	       		'to'        => "$toName <$toAddress>",
	            'subject'   => $subject,
	            'html'      => $html,
	            'text'      => str_replace('<br/>',PHP_EOL,strip_tags($html,'<br>')),
	            'from'      => "$fromname <$from>",
	          );
	          
	          if($bcc){
	          	$params['bcc']=$bcc;
	          	log::logInfo($params);
	          }
	          
				$emailData = self::buildEmailData($params);

				try{
					$result = self::$client->sendEmail($emailData);
				}catch (Exception $e){
			//		echo '<pre>' . print_r($e->getMessage()) . '</pre>';
					debug::add('AWS SES error',$e->getMessage());
				}
				return $result['MessageId'];
		}
		
		
		private static function buildEmailData($params)
		{
			
			$bcc = array();
			
			if(!empty($params['bcc']))
			{
				$bcc = array($params['bcc']);
			}
			$emailData = [
					    // Source is required
	            'Source' => $params['from'],
	            // Destination is required
	            'Destination' => array(
	            	    'BccAddresses' => $bcc,
				        'CcAddresses' => array(),
				        'ToAddresses' => array(
				           $params['to'],
				        ),
	            ),
	            // Message is required
	            'Message' => array(
	                // Subject is required
	                'Subject' => array(
	                    // Data is required
	                    'Data' => $params['subject'],
	                    'Charset' => 'UTF-8',
	                ),
	                // Body is required
	                'Body' => array(
	                    'Text' => array(
	                        // Data is required
	                        'Data' => $params['text'],
	                        'Charset' => 'UTF-8',
	                    ),
	                    'Html' => array(
	                        // Data is required
	                        'Data' => $params['html'],
	                        'Charset' => 'UTF-8',
	                    ),
	                ),
	            ),
	            'ReplyToAddresses' => array($params['from']),
	            'ReturnPath' => $params['from']
				];
				return $emailData;
		}

}

?>