<?php


class page{
    
    static $page=array();
    
    static function set($name,$value){
        self::$page[$name]=$value;
    }
    
    static function get($name){
        if(array_key_exists($name,self::$page)){
            return self::$page[$name];
        }else{
            return '';
        }
    }
}

?>