<?php


class mailtest{
    
    static $from='noreply@clevertech.tv';
    
    
    static function send($to,$subject,$message){
        $headers = 'From: '.self::$from . "\r\n" .
            'Reply-To: '.self::$from . "\r\n" .
            'X-Mailer: PHP/' . phpversion();
        mail($to, $subject, $message, $headers);
    }
}


?>