<?php



class share{
	
	
	static function saveShare($email,$handle,$groups,$barcode,$comments){
		$fields=array('email'=>$email,'handle'=>$handle,'groups'=>$groups,'barcode'=>$barcode,'comments'=>$comments,'sharedate'=>dbpdo::now());
		slack::message(print_r($fields,true),'#barcodes');
		dbpdo::dbInsert('sharing',$fields);
	}
	
	static function getHandle($email){
		$sql='select * from appusers where email=:email limit 1';
		$parms=array(':email'=>$email);
		if($data=dbpdo::getQuery($sql,$parms)){
			return $data['handle'];
		}else{
			return '';
		}
	}
	
	
	static function freeHandle($handle,$email){
		slack::message($handle.' '.$email,'#api');
		$sql='select * from appusers where handle=:handle limit 1';
		$parms=array(':handle'=>$handle);
		if($data=dbpdo::getQuery($sql,$parms)){
			slack::message(print_r($data,true),'#api');
			if($email!=$data['email']){
			return 'FOUND';
			}else{
				return 'NOTFOUND';
			}
		}else{
			return 'NOTFOUND';
		}
	}
	
	
	
	static function myShares($email){
		$imgPath='https://images.foodadvisr.com/';
		$sql='select * from sharing
		left join _products_import2 on sharing.barcode = _products_import2.barcode_number 
		where email=:email order by sharedate desc limit 40';
		$parms=array(':email'=>$email);
		if($stmt=dbpdo::query($sql,$parms)){
		    while($row = $stmt->fetch()){
		    	$img=$imgPath.md5($row['barcode'].'.xfa8flP4K03LsT3jeya3O38FCMaE3p').'.jpg';
		    	echo '<div class="share-list-item act-view-detail-full" data-barcode="'.$row['barcode_number'].'">';
		    	echo '<img src="'.$img.'"/>';
		    	echo '<div class="detail">';
		    	
		    	if(date('dmy')==date('dmy',strtotime($row['sharedate']))){
		    		$date=''.date('h:ia',strtotime($row['sharedate']));
		    	}else{
		    		$date=date('l jS F h:ia',strtotime($row['sharedate']));
		    	}
		    	$dd=date(DATE_ISO8601,strtotime($row['sharedate']));
		    	echo '<small class="share-time">'.$date.'</small>';
		    	echo '<h6>'.$row['product_title'].'</h6>';
		    	echo '<p><i><small>Shared with : </small>'.$row['groups'].'</i></p>';
		    	if($row['comments']!=''){
		    		echo '<p><b>'.$row['comments'].'</b></p>';
		    	}
		    	echo '</div>';
		    	echo '</div>';
		    }
		}
	}
	
	
	
	
	
}



?>