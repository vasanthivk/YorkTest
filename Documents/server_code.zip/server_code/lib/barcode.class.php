<?php


class barcode{
    
    static function ean13_check_digit($digits){
        $digits =(string)$digits;
        $even_sum = $digits{1} + $digits{3} + $digits{5} + $digits{7} + $digits{9} + $digits{11};
        $even_sum_three = $even_sum * 3;
        $odd_sum = $digits{0} + $digits{2} + $digits{4} + $digits{6} + $digits{8} + $digits{10};
        $total_sum = $even_sum_three + $odd_sum;
        $next_ten = (ceil($total_sum/10))*10;
        $check_digit = $next_ten - $total_sum;
        return $digits . $check_digit;
    }
    

    
    static function lookup($barcode,$userref){
        $prod= products::ByBarcode($barcode,$userref);
        $prod['description']=self::clean($prod['description']);
        $prod['ingredients']=self::clean($prod['ingredients']);
		$arr=explode('|',$prod['setting_vals']);
		foreach($arr as $k=>$v){
		    $subarr=explode(',',$v);
		        $setarr[$subarr[0]]=h::safeArray($subarr,1);
		}
        $fields=self::filterFields($prod,array('ref','title','description','ingredients','productref','setting_vals'));
        echo json_encode($fields);
        push::send($prod['title'].'|'.$prod['productref'].'|'.$barcode);
    }
    
    static function getItem($barcode,$userref){
        $prod= products::byRef($barcode,'');
        echo json_encode(self::entities($prod));
        
        
    }
    
    static function entities($inArray){
        $op=array();
        foreach($inArray as $key=>$value){
            $value=str_replace('<STRONG>','##strong##',$value);
            $value=str_replace('</STRONG>','##strongend##',$value);
            $value=strip_tags($value);
            if($key=='ingredients'){
                $value=strtolower($value);
                //$value=str_replace(' ','',$value);
            }
            $op[$key]=utf8_encode($value);
        }
        return $op;
    }
    
    
    static function filterFields($inData,$fieldList=array()){
        $ret=array();
        foreach($fieldList as $item){
            $ret[$item]=$inData[$item];
        }
        return $ret;
    }
    
    static function clean($intext){
        $ret=str_replace('\r','',$intext);
        $ret=str_replace('\n','',$ret);
        $ret=str_replace('\t','',$ret);
        return $ret;
    }


    static function listBarcodes(){
	    $sql='select * from quicr_barcodes 
	            left join _productsx on (quicr_barcodes.barcode=_productsx.barcode_number)
	            order by category desc,product_title asc limit 100;';
	    $parms=array();

	    $fields='Barcode Image,Barcode,Product Title,Customer';
	    $ret= table::head ('prod-tbl',$fields);
	    $category='';
	    $buffer='';
	    $cc=0;
		if($stmt=dbpdo::query($sql,$parms)){
		    while($row = $stmt->fetch()){
		        $buffer.='<tr class="act-drill-down prod-list" data-ref="'.$row['barcode'].'">';
		        $buffer.='<td><a href="newdetail.php?r='.$row['barcode'].'" class="barcode">'.$row['barcode'].'</a></td>';
		        $buffer.= table::dataRow($row,'barcode,product_title,customer',false);
		        $buffer.='</tr>';
		        $cc++;
		    }
		}
		$ret.=$buffer;
	    $ret.= table::close();
		return $ret;
    }
	
    
}

?>