<?php
error_reporting(0);
class productimage
{

    const IMG_BASEURL = 'http://productimages.brandbank.com/snapshotimagehandler.ashx?id=';
    const IMG_BUCKET = 'images.foodadvisr.com';
    const TMP_IMG_PATH = '/var/www/html/cxx/workspace/quicr/content/tmp/';
    private static $reader;
    private static $count = 0;
    
    public static function initialise($filepath=''){
    	
    	self::$reader = new XMLReader(); // initialize

    	if ($filepath != ''){
            self::$reader->open( $filepath ); // open file
    	}
    }
    
    public static function downloadProductImages($filepath, $fileExt,  $dir=''){
    	 self::initialise($filepath);
  
	    	 while(self::$reader->read())
	         {
	            if( self::$reader->nodeType == XMLReader::ELEMENT 
	                &&  self::$reader->name == 'Product')
	              {
	              	$doc = new DOMDocument('1.0', 'UTF-8');
	                $xml = simplexml_import_dom($doc->importNode(self::$reader->expand(),true));
	                  switch(self::getUpdateType()){
			     		case 'AddOrUpdate':
	                		self::addImage($xml, $fileExt);
	                		break;
	                    case 'Delete':

	                    	break;
	                    default:
	                  }	
	              }
	         }     	
    	 
    }
    
    public static function addImage($xml, $fileExt){
    	// Get barcode
		$barcode=productimport::getNodeValueForAttribute($xml->Identity->ProductCodes->Code, 'Scheme', 'GTIN');
		$params = [':barcode' => $barcode];
		if($barcode != ''){
			$sql = 'SELECT image_ref FROM _products_import2 WHERE barcode_number = :barcode LIMIT 1';
			if($stmt=dbpdo::query($sql, $params)){
				$product = $stmt->fetch();
				$imageRef = $product['image_ref'];
				$imageFilename = self::hashBarcode($barcode) . $fileExt;		// HASH NAME
				if(self::imageDownloadedToS3($imageFilename, productimage::IMG_BUCKET)==false){
					log::logInfo('Downloading .. ' . $imageFilename );
		//			echo 'Downloading .. ' . $imageFilename . "\n";
			//		self::downloadProductImage( $imageRef, $dir, $imageFilename);
					self::downloadImageToS3( $imageRef, $imageFilename, $barcode);
				}else{
					self::saveImageFlag($barcode,'Yes');
					// log::logInfo('Image: ' . $imageFilename . ' already downloaded');
					// echo 'Image: ' . $imageFilename . ' already downloaded' . "\n";
				}
			}
		}
    }
    
    public static function imageDownloadedToS3($imageFilename, $bucket){
		$ret = false;
		$file = s3util::getObject($bucket, $imageFilename);
		$eTag = $file['ETag'];

		if ($file != null){
			$ret = true;
		}else{
			$ret = false;
		}
		
		return $ret;
    }
    
    public static function getUpdateType()
    {
	   return self::$reader->getAttribute('UpdateType');
    }
    
    public static function downloadImageToS3($imageRef, $imageFilename, $barcode, $dir=''){

    	$url = productimage::IMG_BASEURL . $imageRef;
    	$responseCode = self::getHttpResponseCode($url);
  //  	echo $url ."\n";
    	if($responseCode==200){
	    	$newFileContent = file_get_contents($url);
	    	if($newFileContent===false){
		    	self::saveImageFlag($barcode,'No');	// Flag the image as missing in the database
		    	log::logInfo('No image found for product: ' . $barcode);
    //			echo 'No image found for prpduct: ' . $barcode . "\n";
	    	}else{
	    		// Download file to a temp location
		    	$tmpImg = self::downloadFile(productimage::TMP_IMG_PATH, $newFileContent, $imageFilename);
		    	if($tmpImg !== null){
			    	s3util::putObjectFile($tmpImg, productimage::IMG_BUCKET, $imageFilename, s3util::ACL_PUBLIC_READ,array(), 'image/jpeg');
			    	log::logInfo('Added image for product: ' . $barcode );
	    //			echo 'Added image for product: ' . $barcode . "\n";
			    	self::saveImageFlag($barcode,'Yes');	
			   		//Delete temp file
			   		unlink($tmpImg);
		    	}
	    	}
    	}else{
    		self::saveImageFlag($barcode,'No');
    		log::logInfo('No image found for product: ' . $barcode);
  //  		echo 'No image found for product: ' . $barcode . "\n";
    	}
    }
    
    public static function saveImageFlag($barcode, $hasImage){
    	 $fields=array();
    	 $fields['image']=$hasImage;
		 dbpdo::dbUpdate('_products_import2',$barcode,$fields,'barcode_number','',false);
    }

     public static function hashBarcode($str){
    	$secret = settings::getSettings('brandbank', 'image_name_secret');
    	$hashed = md5($str.'.'.$secret);

    	return $hashed;
    }
    
    public static function getHttpResponseCode($url) {
	    $headers = get_headers($url);
	    return substr($headers[0], 9, 3);
	}

    public static function imageCount($dir){
    	$count=0;
    		foreach(glob($dir) as $file)
			{
			    if(!is_dir($file)) { 
			  		$count++;
			    }
			}
			return $count;
    }
    
    public static function downloadFile($dir, $newFileContent, $filename=''){

	    $newFilemame = $dir . $filename;
	    
//	    echo $newFilemame . "\n";

	    $ret = null;
	
	    if (file_put_contents($newFilemame, $newFileContent) !== false) {
	    	$ret = $newFilemame;
	    	echo "File created (" . basename($newFilemame) . ")" . "\n";
		} else {
	    	echo "Cannot create file (" . basename($newFilemame) . ")" . "\n";
		}
			
	    return $ret;
    }

	// ################### Local file System methods / Deprecated ####################
	
	public static function imageDownloaded($imageFilename, $dir){

		foreach(glob($dir) as $file)
		{
		    if(!is_dir($file)) { 
		  //  	echo basename($file)."<br/>";
		    	if (basename($file)==$imageFilename){
		    		return true;
		    	}
		    }
		}
		return false;
    }
    
    public static function downloadProductImage($imageRef, $dir, $imageFilename){
	//	$savePath = realpath(dirname(__FILE__) . '/../content/productimages');

    	$newFilemame = $dir . '/' . $imageFilename;
    	$newFileContent = file_get_contents(productimage::IMG_BASEURL . $imageRef);

    	if (file_put_contents($newFilemame, $newFileContent) !== false) {
    		echo "File created (" . basename($newFilemame) . ")" . "\n";
		} else {
    		echo "Cannot create file (" . basename($newFilemame) . ")" . "\n";
		}
    }
}