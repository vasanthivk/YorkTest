<?php 
class clean{
	
	private static $settingsArray=array();
 	private static $prepend='false';

 	private static $clean=array();

	public static function cleanInput(){
		self::$clean['post']['filter']=filter_input_array( INPUT_POST, FILTER_SANITIZE_STRING );
		self::$clean['post']['raw']=$_POST;
		self::$clean['get']['filter']=filter_input_array( INPUT_GET, FILTER_SANITIZE_STRING );
		self::$clean['get']['raw']=$_GET;
		self::$clean['cookie']['filter']=filter_input_array( INPUT_COOKIE, FILTER_SANITIZE_STRING );
		self::$clean['cookie']['raw']=$_COOKIE;
		self::$clean['server']['filter']=filter_input_array( INPUT_SERVER, FILTER_SANITIZE_STRING );
		self::$clean['server']['raw']=$_SERVER;
		self::$clean['files']['filter']=self::filterFiles();
		self::$clean['files']['raw']=$_FILES;


	}

private static function filterFiles(){
		$files=array();
		if(array_key_exists('file', $_FILES)){
			foreach($_FILES['file'] as $key=>$item){
				$files[$key]=$item;
			}

		}

		return $files;
	}

	
	public static function prepend(){return self::$prepend;}

	public static function setprepend(){self::$prepend=true;}

	static function getEmail($name,$method='post'){
		return filter_var(self::$clean[$method]['filter'][$name], FILTER_SANITIZE_EMAIL);
	}

	static function getInt($name,$method='post',$range=''){
		return filter_var(self::$clean[$method]['filter'][$name], FILTER_SANITIZE_NUMBER_INT);
	}

	static function getStripped($name,$method='post',$range=''){
		return strip_tags(self::$clean[$method]['raw'][$name], '<quote><button><p><a><br><h1><h2><h3><h4><h5><h6><strong><em><b><i><ul><li><ol><small><img>');
	}
	
	static function getRaw($name,$method='post',$range=''){
		return self::$clean[$method]['raw'][$name];
	}


	static function getFloat($name,$method='post',$range=''){
		return filter_var(self::$clean[$method]['filter'][$name], FILTER_SANITIZE_NUMBER_FLOAT);
	}

	static function getUrl($name,$method='post',$range=''){
		return filter_var(self::$clean[$method]['filter'][$name], FILTER_SANITIZE_URL);
	}

	public static function getList($name,$method='post',$list=array()){
		$val=self::$clean[$method]['filter'][$name];
		$res=array_search($val, $list);
		if($res===false){
			return '';
		}else{
			return $val;
		}
	}

	public static function item($inArray,$key,$blank=''){
		if(is_array($inArray)){
			if(array_key_exists($key,$inArray)){
				return $inArray[$key];
			}		
		}
		return $blank;

	}

	public static function get($field='',$mode='filter'){
		if($field!=''){
			return self::item(self::$clean['get'][$mode],$field);
		}else{
			return self::$clean['get'][$mode];
		}
	}
	
	public static function post($field='',$mode='filter'){
		if($field!=''){
			return self::item(self::$clean['post'][$mode],$field);
		}else{
			return self::$clean['post'][$mode];
		}	
	}

	public static function files($field='',$mode='filter'){
		if($field!=''){
			return self::item(self::$clean['files'][$mode],$field);
		}else{
			return self::$clean['files'][$mode];
		}	
	}
	
	public static function postSize(){
	    return sizeof(self::$clean['post']['filter']);   
	}





	public static function setPost($field,$data){
		self::$clean['post']['filter'][$field]=$data;	
	}

	public static function unsetPost($field){
		unset(self::$clean['post']['filter'][$field]);	
	}
	
	public static function cookie($field='',$mode='filter'){
		if($field!=''){
			return self::item(self::$clean['cookie'][$mode],$field);
		}else{
			return self::$clean['cookie'][$mode];
		}	
	}

	public static function noCache($inFile){
		return $inFile.'?cache='.uniqid();
	}
	
	static function validValues($item,$values=array()){
	    if(in_array($item,$values)){
	        return $item;
	    }else{
	        log::logSecurity('Valid values error '.$item);
	        return false;
	    }    
	}
	
	static function def($inText,$default=''){
	    if($inText==''){
	        return $default;
	    }else{
	        return $inText;
	    }
	    
	}






}
?>