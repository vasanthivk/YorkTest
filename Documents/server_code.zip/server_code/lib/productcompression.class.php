<?php

class productcompression
{
	
	private static $table = '_product_compression';
	
	public static function addCodesToProductTable()
	{
		$sql = 'SELECT barcode_number, product_title, ingredients FROM _products WHERE ingredients <> :notfound AND 
		deleted IS NULL AND (last_compressed IS NULL OR NOW() > DATE_ADD(last_compressed, INTERVAL 12 HOUR)) LIMIT 5';
		$params = [':notfound'=>'Not Found'];
		$codeStr = '';
		$fields = array();
		
		if ($stmt=dbpdo::query($sql, $params)) {
			 while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			 	$ingredients = explode(',', $row['ingredients']);
			 	$ingLen = sizeOf($ingredients);
			 	for($i=0; $i < $ingLen; $i++ ){
			 		$code = self::getCodeByIngredientName(trim($ingredients[$i]));
			 		
			 		if($code==''){$code=$ingredients[$i];}
			 		
					if($i < $ingLen-1){
						$codeStr .= $code . ',';
					}else{
						$codeStr .= $code;
					}
			 	}
			 	// Save $codeStr to the ingredient_codes field in the _products table
			 	$fields['ingredient_codes'] = $codeStr;
			 	$fields['last_compressed'] = dbpdo::now();
	//		 	dbpdo::dbUpdate('_products',$row['barcode_number'],$fields, 'barcode_number', '', false);
		//	 	echo 'Updated product: ' . $row['product_title'] . "\n";
				echo str_replace(',',"\n",$codeStr) . "\n\n";
				echo "------------------\n";
			 }
		}
	}
	
	static function getCodeByIngredientName($ingredientName)
	{
		$sql = 'SELECT code FROM _product_compression WHERE ingredient = :ingredientName LIMIT 1';
		$params = [':ingredientName' => $ingredientName];
		$ret = null;

		if ($stmt=dbpdo::query($sql, $params)) {
			$row = $stmt->fetch();
			$ret = $row['code'];
		}
		return $ret;
	}
	
	public static function addOrUpdateIngredients()
	{
		$fieldlist = array();

		$result = self::getUniqueIngredients();
		
		foreach ($result as $row){
			$fieldlist['ingredient'] = $row['name'];
	//		$fieldlist['occurrence'] = self::getIngredientCount($fieldlist['ingredient']);
			$fieldlist['occurrence'] = $row['frequency'];
			$fieldlist['character_count'] = self::getCharacterCount($fieldlist['ingredient'], $fieldlist['occurrence']);
			
		//	echo $fieldlist['ingredient'] . ' - ' . $fieldlist['occurrence'] . ' - ' . $fieldlist['char_count'] . ' - ' . $fieldlist['code'] . "\n";
			$ingredient = self::getIngredientByName($fieldlist['ingredient']);
			
			if($ingredient == null){
				$fieldlist['ref'] = productimportutil::randomString(32);
				$fieldlist['code'] = self::generateCode();
				dbpdo::dbInsert(self::$table, $fieldlist, '', false, true);
				echo 'Product Compression. Added: ' . $fieldlist['ingredient'] . "\n";
			//    log::logInfo( 'Product Compression. Added: ' . $fieldlist['ingredient'] );
			}else{
				dbpdo::dbUpdate(self::$table,$ingredient['ref'],$fieldlist, 'ref', '', false);
				echo 'Product Compression. Updated: ' . $fieldlist['ingredient'] . "\n";
			//	log::logInfo( 'Product Compression. Updated: ' . $fieldlist['ingredient'] );
			}
			
//			echo $fieldlist['ingredient'] . ' - ' . $fieldlist['occurrence'] . ' - ' . $fieldlist['character_count'] . ' - ' . $fieldlist['code'] . "\n";
			// Timestamp when compressed
	//		self::timestampCompressedIngredients($fieldlist['ingredient']);
		
		}
	}
	
	static function timestampCompressedIngredients($ingredientName){
		$sql = 'UPDATE _product_ingredients SET last_compressed = "' . dbpdo::now() . '" WHERE name = :ingredientName';

		$params = ['ingredientName' => $ingredientName];

		$fieldlist['last_compressed'] = dbpdo::now();
		if ($stmt=dbpdo::query($sql, $params)) {
			return true;
		}else{
			return false;
		}
	}
	
	static function printToCli(){
		$sql = 'SELECT * FROM _product_compression';
		$ret = null;

		if ($stmt=dbpdo::query($sql, $params)) {
			 while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) { 
			 	echo '|' . $row['ingredient'] . '|' . "\n";
			 }
		}
	}
	
	static function getNextAlphaNumeric($code) {
	   $base_ten = base_convert($code,36,10);
	   $result = base_convert($base_ten+1,10,36);
	   $result = str_pad($result, 2, '0', STR_PAD_LEFT);
	   $result = strtoupper($result);
	   return $result;
	}
	
	static function genCode(){
		$chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$code = '';
		$limit = strlen($chars);
		for ($i = 0; $i < $limit; $i++){
			// for ($i = 0; $i < strlen($chars); $i++){
				
			// }
			if($i==$limit){
				$i=0;
				$code .= $chars[$i];
			} else{
				$code = $chars[$i];
			}
			echo $code . "\n";
		}
	}
	
	static function generateCode()
	{
		$chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$prependChar = '#';
		$appendChar = '';
		$codeGenerated = false;
		$count=0;
		$code = '';
		
		do {
		    for ($i = 0; $i < strlen($chars); $i++){
		    	for ($n = 0; $n < $count; $n++){
		    		for ($n = 0; $n < $count; $n++){
		    		$appendChar .= $chars[$i];
		    			}
		    	}
		    	$code = $prependChar . $appendChar;
		    	$appendChar = '';
		    	// Check in the db if the code has been used
		    	$ingredientRec = self::getIngredientByCode($code);
		    	if($ingredientRec == null){
		    //		echo 'code generated';
		    		$codeGenerated = true;
		    		break;
		    	}
			}
			$count++;
		} while ($codeGenerated == false);
		
		return $code;
		
	}
	
	// static function generateCode()
	// {
	// 	$chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	// 	$prependChar = '#';
	// 	$appendChar = '';
	// 	$codeGenerated = false;
	// 	$count=0;
	// 	$code = '';
		
	// 	do {
	// 	    for ($i = 0; $i < strlen($chars); $i++){
	// 	    	for ($n = 0; $n < $count; $n++){
	// 	    		$appendChar .= $chars[$i];
	// 	    	}
	// 	    	$code = $prependChar . $appendChar;
	// 	    	$appendChar = '';
	// 	    	// Check in the db if the code has been used
	// 	    	$ingredientRec = self::getIngredientByCode($code);
	// 	    	if($ingredientRec == null){
	// 	    //		echo 'code generated';
	// 	    		$codeGenerated = true;
	// 	    		break;
	// 	    	}
	// 		}
	// 		$count++;
	// 	} while ($codeGenerated == false);
		
	// 	return $code;
		
	// }
	
	static function getIngredientByCode($code)
	{
		$sql = 'SELECT * FROM _product_compression WHERE code = :code LIMIT 1';
		$params = ['code' => $code];
		$ret = null;

		if ($stmt=dbpdo::query($sql, $params)) {
			$ret = $stmt->fetch();
		}
		return $ret;
	}
	
	static function getIngredientByName($name)
	{
		$sql = 'SELECT * FROM _product_compression WHERE ingredient = :ingredient LIMIT 1';
		$params = ['ingredient' => $name];
		$ret = null;

		if ($stmt=dbpdo::query($sql, $params)) {
			$ret = $stmt->fetch();
		}
		return $ret;
	}
	
	
	static function getUniqueIngredients()
	{
	//	$sql = 'SELECT distinct(name) FROM _product_ingredients';
		$sql='SELECT ref, name, count(*) as frequency
			FROM _product_ingredients WHERE deleted IS NULL AND (last_compressed IS NULL OR NOW() > DATE_ADD(last_compressed, INTERVAL 12 HOUR))
			GROUP BY name HAVING COUNT(*) > 110
			ORDER BY count(*) desc LIMIT 50';

		$results = null;
		
		if ($stmt=dbpdo::query($sql)) {
			$results = $stmt->fetchAll();
		}
		
		return $results;
	}
	
	static function getIngredientCount($ingredient)
	{
		$sql = 'SELECT count(*) FROM _product_ingredients WHERE name = :ingredient';
		$params = ['ingredient' => $ingredient];
		$count = 0;
		if ($stmt=dbpdo::query($sql,$params)) {
			$count = $stmt->fetchColumn();
		}
		
		return $count;
	}
	
	static function getCharacterCount($ingredient, $ingredientCount)
	{
		$chars = strlen($ingredient);
		$charCount = $chars * $ingredientCount;
		return $charCount;
	}
	
}