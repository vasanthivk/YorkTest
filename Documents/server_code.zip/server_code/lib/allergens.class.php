<?php


class allergens{
    
    static function api($type){
        $ret=array();
        $sql='select * from allergens where type=:type';
        $parms=array(':type'=>$type);
		if($stmt=dbpdo::query($sql,$parms)){
		    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		        $ret[$row['title']]=$row;
		    }
		}
		return $ret;
    }
    
    
    function listAllergens($type){
        $ret=array();
        $sql='select * from allergens where type=:type';
        $parms=array(':type'=>$type);
        $fields='Title,edit';
	    $ret= table::head ('prod-tbl',$fields);
		if($stmt=dbpdo::query($sql,$parms)){
		    while($row = $stmt->fetch()){
		    	$row['edit']='<a href="../admin/allergens_edit.php?ref='.$row['ref'].'">Edit</a>';
		        $ret.= table::dataRow($row,'title,edit',true);
		    }
		}
	    $ret.= table::close();
		return $ret;

    }
    
    
}

?>