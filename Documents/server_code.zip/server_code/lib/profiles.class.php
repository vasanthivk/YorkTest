<?php


class profiles{
    
    

    static function getAll(){
    	slack::message('getall','#andydebug');
        $ret=array();
        $sql='select * from profiles where display=:yes order by sortorder desc,name asc';
        $parms=array(':yes'=>'Yes');
        $nref=1;
		if($stmt=dbpdo::query($sql,$parms)){
		    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		    	$row['ingredients']=strtolower($row['ingredients']);
		    	$row['name']=ucwords($row['name']);
		        //$ret[$row['ref']]=$row;
		        $row['ref']=$nref;
		        $ret[$nref]=$row;
		        $nref++;
		    }
		}
		return $ret;
    }
    

    static function listProfiles(){
        $ret=array();
        $sql='select * from profiles where display=:yes';
        $parms=array(':yes'=>'Yes');
        $fields='Name,Edit';
	    $ret= table::head ('prod-tbl',$fields);
		if($stmt=dbpdo::query($sql,$parms)){
		    while($row = $stmt->fetch()){
		    	$row['edit']='<a href="../admin/profiles_edit.php?ref='.$row['ref'].'">Edit</a>';
		        $ret.= table::dataRow($row,'name,edit',true);
		    }
		}
	    $ret.= table::close();
		return $ret;
    }
    
    
    
}


?>