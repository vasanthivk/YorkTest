<?php


class login{
    
    
    static function validate($email,$passHash){
        $sql='select * from appusers where email=:email limit 1';
        $parms=array(':email'=>$email);
        if($data=dbpdo::getQuery($sql,$parms)){
            if(password_verify($passHash,$data['password'])){
            	self::log($email);
    			$key=settings::getSettings('JWT','key');
    			$payload=array('email'=>$email,'logintime'=>dbpdo::now());
				$encoded=JWT::encode($payload,$key);
				echo 'loggedin|'.$encoded;
            }else{
            	$cc=$data['failedlogins'];
            	$cc++;
            	self::log($email,'Failed password',$cc);
                echo 'fail|';
                die();
            }
        }else{
        	self::log($email,'Failed email');
            echo 'fail|';
            die();
        }
    }
    
    static function getJWT($userid,$p4,$p5){
		$key=settings::getSettings('JWT','key');
		$payload=array('email'=>$userid,'logintime'=>dbpdo::now());
		$encoded=JWT::encode($payload,$key);
		return $encoded;
    }
    
      static function validate2($email,$passHash,$version,$device){
        $sql='select * from appusers where email=:email limit 1';
        $parms=array(':email'=>$email);
        if($data=dbpdo::getQuery($sql,$parms)){
            if(password_verify($passHash,$data['password'])){
            	self::log($email);
    			$key=settings::getSettings('JWT','key');
    			$payload=array('email'=>$email,'logintime'=>dbpdo::now());
				$encoded=JWT::encode($payload,$key);
				echo 'loggedin|'.$encoded;
				$fields=array('appversion'=>$version,'device'=>$device,'lastlogin'=>dbpdo::now());
				dbpdo::dbUpdate('appusers',$email,$fields,'email');
            }else{
            	$cc=$data['failedlogins'];
            	$cc++;
            	self::log($email,'Failed password',$cc);
                echo 'fail|';
                die();
            }
        }else{
        	self::log($email,'Failed email');
            echo 'fail|';
            die();
        }
    }

    
    static function changePassword($jwt,$oldpass,$newpass){
    	$key=settings::getSettings('JWT','key');
    	$decode=JWT::decode($jwt,$key);
    	$sql='select * from appusers where email=:email limit 1';
    	$parms=array(':email'=>$decode->email);
    	$data=dbpdo::getQuery($sql,$parms);
    	//echo $oldpass.' '.$data['password'];
    	if(password_verify($oldpass,$data['password'])){
    		$newpass=$hashedPass=password_hash($newpass, PASSWORD_DEFAULT);
    		$fields=array('password'=>$newpass);
    		dbpdo::dbUpdate('appusers',$decode->email,$fields,'email');
    		echo 'updated';
    	}else{
    		echo 'error';
    	}
    }
    
    static function log($email,$status='Logged in',$failCount=0){
    	$fields=array('email'=>$email,
    				'lastlogin'=>dbpdo::now(),
    				'ipaddress'=>self::getIp(),
    				'browserstring'=>$_SERVER['HTTP_USER_AGENT'],
    				'browserhash'=>md5(self::getIp().$_SERVER['HTTP_USER_AGENT']),
    				'failedlogins'=>$failCount,
    				'status'=>$status
    				
    	);
    	dbpdo::dbUpdate('appusers',$email,$fields,'email');
    }
    
    
    
    static function getIp(){
		if(h::sa($_SERVER,'REMOTE_ADDR')!=''){
			return h::sa($_SERVER,'REMOTE_ADDR'); //normal server
		}else{
			if(h::sa($_SERVER,'HTTP_X_FORWARDED_FOR')!=''){
				return h::sa($_SERVER,'HTTP_X_FORWARDED_FOR'); //rackspace
				
			}
			
		} 
		return h::sa($_SERVER,'HTTP_CF_CONNECTING_IP'); //cloudflare
    }
    
    
    static function signUp($email,$password){
    	slack::message($email.' '.$password,'#barcodes');
        if(!self::userExists($email)){
        	$hashedPass=password_hash($password, PASSWORD_DEFAULT);
        	$fields=array('email'=>$email,
        					'password'=>$hashedPass,
        					'date_entered'=>dbpdo::now());
        	dbpdo::dbInsert('appusers',$fields);
                $key=settings::getSettings('JWT','key');
    			$payload=array('email'=>$email,'logintime'=>dbpdo::now());
				$encoded=JWT::encode($payload,$key);        	
        	die('created:'.$encoded);
        }else{
        	die('error:userexists');
        }
    }
    
    static function resetPassword($email){
    	$hash = bin2hex(openssl_random_pseudo_bytes(60));
    	$fields=array('resethash'=>$hash);
    	dbpdo::dbUpdate('appusers',$email,$fields,'email');
    	$path=settings::getSettings('project','resetpath');
    	$link=$path.'?email='.$email.'&hash='.$hash;
	$subject='FoodAdvisr password reset';
	$html='A request has been made to reset your FoodAdvisr password. If you did not request a reset then please ignore this email. If you requested a reset, click the link below to create a new password<br/><br/>';
	$html.='<a href="'.$link.'">Reset my password</a>';
	$to=$email;
	$toName='';


	ses::send($subject,$html,$to,$toName);
    	
    	
    	
    	//mailtest::send('andy@clevertech.tv','QUICR Password reset',$link);
    	echo 'emailsent';
    }
    

    
    
    static function userExists($email){
        $sql='select * from appusers where email=:email limit 1';
        $parms=array(':email'=>$email);
        if($data=dbpdo::getQuery($sql,$parms)){
        	if(h::sa($data,'email')!==''){
        		return true;
        	}else{
        		echo '1';
        		return false;
        	}
        }else{
        	echo '2';
        	return false;
        }
        echo '3';
        return true;
    	
    }
    
    
    
}


?>