<?php 

class debug{
	
	private static $debugText;
	private static $pageStartTime;
	private static $errors=false;
	private static $errorCount=0;
	private static $warnings=false;
	private static $warningCount=0;

	private static $logHandle=false;
	private static $showDebug=false;

	private static $log=array();

	private static $timer=0;
	private static $totalTime=0;

	private static $counts=array();

	private static $collections =array();
	
	private static $dbcalls=array();



        static function addDB($sql,$parms,$error,$rows,$duration){
            self::$dbcalls[]=array('sql'=>$sql,
                                'parms'=>$parms,
                                'error'=>$error,
                                'rows'=>$rows,
                                'time'=>round($duration,3).'s');
        }

		static function addColItem($collection,$item,$data){
			self::$collections[$collection][$item]=$data;
		}

	

		static function startTimer($countId){
			self::$timer=microtime(true);
			self::add('+++ Start Timer ***');
			if(!array_key_exists($countId, self::$counts)){
				self::$counts[$countId]=1; 
			}else{
				self::$counts[$countId]++;	
			}
			

			 
		}

		static function stopTimer($text){
			$ts=microtime(true)-self::$timer;

			self::$totalTime+=$ts;
			self::$counts['TIME']=round(self::$totalTime,5);
			self::add('*** TIMER ****'.$text,round($ts,5));

		}



		static function startTime(){
			self::$pageStartTime=microtime(true);
		}
		
		static function setTimeLog($logText){
			$tt=microtime(true)-self::$pageStartTime;
			self::$debugText.='### page time ### <b>'.$logText.'</b> '.round($tt,5).'<br/>';
		}

		static function add($inBold,$inText=''){
			
			$bt=debug_backtrace();
			$btsub=self::getSubArray($bt,1);
			$bn=basename(self::getSubArray($btsub,'file'));
			if(is_array($inBold)){
				if(sizeof($inBold)>0){
					self::$debugText.=self::oneArray($inBold,$inText);
					

				}else{
					//self::$debugText.=$bn.' <b>'.$bt[1]['class'].'</b>-><b>'.$bt[1]['function'].'</b> (<b>'.$bt[1]['line'].'</b>) '.$inText.' <b>Array Empty</b><br/>';
				}
			}else{
				if(strrpos(strtolower($inBold),'error')===false){
					if(strrpos(strtolower($inBold),'warning')===false){
						$inBold='<em>'.$inBold.'</em>';
					}else{
						$inBold='<strong>'.$inBold.'</strong>';	
					self::$warnings=true;
					self::$warningCount++;
					}
				}else{
					$inBold='<i>'.$inBold.'</i>';
					self::$errors=true;
					self::$errorCount++;
				}
				self::$debugText.=$bn.' <b>'.self::getSubArray($btsub,'class').'</b>-><b>'.self::getSubArray($btsub,'function').'</b> (<b>'.self::getSubArray($btsub,'line').'</b>) '.$inBold.' <b>'.$inText.'</b><br/>';
				
			}
		}

		private static function getSubArray($inArray,$target){
			$retVal='';
			if(is_array($inArray)){
				if(array_key_exists($target,$inArray)){
				
					$retVal=$inArray[$target];
				}				
			}

			return $retVal;
		}



		

		static function show($hideOutput=false){
		    if(!loginsimple::hasAdminRight('mysql')) {
		        return '';
		        
		    }
			self::add('lib file',__FILE__);
			$finalTime=microtime(true)-self::$pageStartTime;
			$retVal='<link rel="stylesheet" type="text/css" href="../css/debug.css" />';
			$retVal.='<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">';
			//$retVal.='<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>';
			$retVal.='<script src="../js/debug.js"></script>';
			
			
			
			
			$retVal.='<div class="debug-margin"></div>';
			$retVal.='<div id="debug-wrap">';
			    $retVal.='<div class="head">';
			        $retVal.='<a href="" class="action-toggle-debug">Debug</a> ';
			        $retVal.='<i class="fa fa-clock-o"></i> '.round($finalTime,3).'<small>s</small> ';
			        $retVal.='<i class="fa fa-server"></i> '.round(memory_get_peak_usage()/1000,2).'<small>kb</small> ';
			        $retVal.='<i class="fa fa-clock-o"></i> '.date ("F d Y H:i:s.", getlastmod()).' ';
			    
			        $retVal.='<a href="#"><i class="fa fa-search"></i>Detail </a>';
			        
			        $retVal.='<a href="#"><i class="fa fa-random"></i>Request </a>';
			        
			        $retVal.='<a href="#"><i class="fa fa-user"></i>Session </a>';
			        
			        $retVal.='<a href="#"><i class="fa fa-database"></i>Database <span class="debug-info-roundel">'.sizeOf(self::$dbcalls).'</span></a>';
			        if(self::$errorCount>0){
			            $retVal.='<a href="#"><i class="fa fa-exclamation-triangle debug-red"></i>Errors <span class="debug-error-roundel">'.self::$errorCount.'</span></a>';
			        }
			    
			    $retVal.='</div>';
			    $retVal.='<div id="debug-detail">';
			        $retVal.='<div class="debug-wrap">';
			        $retVal.='<div id="debug-panel"><a name="debugpanel">';
				$retVal.='<div class="debug-sub-panel">';
				if(self::$errors){
					//$retVal.='<h5>Debug Output</h5><a href="#debugpanel" class="debug-error-panel">'.self::$errorCount.'</a>';
				}else{
					//$retVal.='<h3>Debug Output</h3>';
				}
				
				$retVal.='Page time is '.$finalTime.'<br/>';
				$retVal.='Peak Memory '.round(memory_get_peak_usage()/1000,2).'kb<br/>';
				$retVal.=self::$debugText;
				$retVal.='<h3>Page details</h3>';
				$retVal.= "Last modified <b>" . date ("F d Y H:i:s.", getlastmod()).'</b><br/>';
				$retVal.='</div>';
				$retVal.=self::oneArray($_SESSION,'Session data');
				$retVal.=self::oneArray(clean::post(),'POST data');
				$retVal.=self::oneArray(clean::get(),'GET data');
				$retVal.=self::oneArray($_COOKIE,'$_COOKIE');
				$retVal.=self::oneArray(get_included_files(),'Included Files');
				$retVal.=self::oneArray($_SERVER,'$_SERVER');
				
				$retVal.=self::oneArray(self::$dbcalls,'Database');
				
				$retVal.=self::oneArray(self::$counts,'Counts');
				$retVal.=self::oneArray(self::$collections,'Collections');



				
			$retVal.='</a></div>';
			        $retVal.='</div>';
			    $retVal.='</div>';//end of debug detail
			$retVal.='</div>'; // end of debug wrap
			
			file_put_contents('../../logs/andydebug.html',$retVal);

            if($hideOutput){
                return '';
            }else{
			    return $retVal;
            }
		}
		
		static function oneArray($inArray,$title){
			$retVal='<div class="debug-sub-panel">';
				$retVal.='<h3>'.$title.'</h3>';
				$retVal.=self::walker($inArray);
			$retVal.='</div>';
			return $retVal;
		}
		
		static function walker($inArray,$depth=0){
			$depth++;
			$retVal='';
			if(sizeOf($inArray)>0){
				foreach($inArray as $key=>$value){
					if(is_array($value)){
						$retVal.='<div class="debug-sub-array">';
						$retVal.= '<h4>Array [<b>'.$key.']</b></h4>';
						$retVal.=self::walker($value,$depth);
						$retVal.='</div>';
					}else{
						if(!strrpos(strtolower($key),'error'===false)){
							if(gettype($value)=='object'){
								$value='{object}';
							}
							if(gettype($key)=='object'){	

								$retVal.= '<em>Key is Object</em> <b>'.$value.'</b><br/>';
							}else{
								$retVal.= '<em>'.$key.'</em> <b>'.$value.'</b><br/>';	
							}
							
						}else{
							$retVal.= $key.' <b>'.$value.'</b><br/>';
						}
						
					}				
				}
			}else{
				$retVal.='Empty Array';
			}
			return $retVal;
		}



		



	static function logErrors($showDebug=false){
		self::$showDebug=$showDebug;
		set_error_handler(array('debug','localerror'),E_ALL);
		register_shutdown_function(array('debug','shutdown'));
	}




    static function localerror($errNo,$errString){
        self::log('ERROR '.$errNo.':'.$errString);
        self::add('PHP ERROR '.$errNo,$errString);
        //log::logError('PHP ERROR '.$errNo,$errString);
        
        return false;
    }


		static function clearLog(){
			
			//$logHandle=fopen(settings::getSettings('project','debugpath'), 'w+');
			//fclose($logHandle);
		}

		static function log($logtext){		
			$txt=date('H:i:s');
			if(is_array($logtext)){
				$txt.='Array Found ';
				$txt.=self::walker($logtext);
			}else{
				$txt.=$logtext;
			}
			//$logHandle=fopen(settings::getSettings('project','debugpath'), 'a');
			//fwrite($logHandle, $txt.'</br>');
			//fclose($logHandle);

		}


	static function shutdown() {
	    $isError = false;
	    $errorType='Unknown';

	    if ($error = error_get_last()){
	    switch($error['type']){
	        case E_ERROR:
	        	$errorType='E_ERROR';
	        case E_CORE_ERROR:
	        	$errorType='E_CORE_ERROR';
	        case E_COMPILE_ERROR:
	        	$errorType='E_COMPILE_ERROR';
	        case E_WARNING:
	        	$errorType='E_WARNING';
	        case E_NOTICE:
	        	$errorType='E_NOTICE';
	        case 8:
	            $errorType='Not Sure'; 
	        case E_USER_ERROR:
	        	$errorType='E_USER_ERROR';
	            $isError = true;
	            break;
	        }
	    }

	    $errorType.=' '.$error['type'];

	    if ($isError){
	    	debug::log('SHUTDOWN ERROR '.$errorType.' '.$error['message'].' line '.$error['line']);
	    	$appname=settings::get('slack','appname');
	    	log::logError(basename($_SERVER["PHP_SELF"]).' ERROR '.$appname.' '.$error['line'].' '.$error['message']);
	    	//slack::message(basename($_SERVER["PHP_SELF"]).' ERROR '.$appname.' '.$error['line'].' '.$error['message'].' :confused:','#debug');
	    	debug::add('SHUTDOWN ERROR '.$errorType,$error['message'].' line '.$error['line']);

	    	
	    	//echo debug::show();
	    }
	    if(self::$showDebug){
		    debug::log('### START OF STORED DEBUG OUTPUT ###');
		    debug::log(debug::show());
		    debug::log('### END OF STORED DEBUG OUTPUT ###');	    	
	    }

	}

	static function showXML($xml){
		$ret='<pre>';
			$ret.=htmlentities($xml);
		$ret.='</pre>';
		return $ret;
	}

}
?>