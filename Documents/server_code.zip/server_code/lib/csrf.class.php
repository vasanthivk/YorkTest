<?php


class csrf{


	static function createCSRF(){
		$_SESSION['csrf']=base64_encode(openssl_random_pseudo_bytes(30));
	}
	
	static function checkCSRF(){
	    log::logInfo('checkCSRF called');
		$validUrls=array('https://test.congadeal.com','https://load2.congadeal.com','https://www.congadeal.com','https://load.congadeal.com','https://prod1.congadeal.com','https://prod2.congadeal.com');
		if(count(clean::post())>0){
			$match=false;
			foreach($validUrls as $item){
				$httpref=substr($_SERVER['HTTP_REFERER'],0,strlen($item));
				log::logInfo('*CSRF ['.$httpref.'] '.$item);	
				if($httpref==$item){
					$match=true;
					break;
				}			
			}




			//$leng=strlen(settings::getSettings('project','csrf'));
			//$httpref=substr($_SERVER['HTTP_REFERER'],0,$leng);
			//$setting=settings::getSettings('project','csrf');
			if(clean::post('csrf')==$_SESSION['csrf'] && $match){
			//if(clean::post('csrf')==$_SESSION['csrf']){
			}else{
				//echo 'invalid csrf';
				//echo '<br/>'.clean::post('csrf');
				//echo '<br/>'.$_SESSION['csrf'];
				//echo '<br/>'.$httpref;
				//echo '<br/>'.$setting;
				clean::revoke('Invalid CSRF');
				die();
			}
		}
	}
	static function hiddenCSRF(){
		log::logInfo('Write csrf field');
		$ret='';
		if(array_key_exists('csrf', $_SESSION)){
			$ret.='<input type="hidden" name="csrf" id="csrf" value="'.$_SESSION['csrf'].'"/>';	
		}else{
			//print_r($_SESSION);
			log::logInfo('CSRF field hidden');
		}
		
		return $ret;
	}
}


?>