<?php


class myadmin{
    
    static function viewDeleted(){
        $table=$_SESSION['builder']['table'];
        $sql='select * from changes where tablename=:table and mode=:mode limit 50';
        $parms=array(':table'=>$table,':mode'=>'delete');
        $first=true;
        if($stmt=dbpdo::query($sql,$parms)){
        	$ret='<table class="table"><thead>';
    	    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
    	    		$d=json_decode($row['backup']);
    	    		if($first){
    	    			$ret.='<tr>';
    	    				foreach($d as $title=>$value){
    	    					$ret.='<td>'.$title.'</td>';
    	    				}
    	    			$ret.='</tr>';
    	    			$first=false;
    	    			$ret.='</thead><tbody>';
    	    		}
    	    		
	    			$ret.='<tr>';
	    				foreach($d as $title=>$value){
	    					$ret.='<td>'.$value.'</td>';
	    				}
	    			$ret.='</tr>';
    	    }
        }
        $ret.='</tbody></table>';
        return $ret;

        
    }
    
    static function viewData($table='',$limit='limit 100'){
        if($table==''){
            $table=$_SESSION['builder']['table'];
        }
        $searchfield='';
        if(clean::post('field')!=''){
            $searchfield=clean::post('field');
            $search=clean::post('search');
            $sql='select * from '.$table.' where '.$searchfield.' like :search order by ref desc limit 100';    
            $parms=array(':search'=>'%'.$search.'%');
        }else{
            $sql='select * from '.$table.' order by ref desc '.$limit;    
            $parms=array();
        }
        
        $ret='<table class="table striped highlight dbedit">';
        $first=true;
        $fields='[';
    	if($stmt=dbpdo::query($sql,$parms)){
    	    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
    	    	if($first){
    	    		$ret.='<thead><tr>';
    	    		foreach($row as $key=>$value){
    	    			$ret.='<th>';
    	    			$ret.='<b>'.$key.'</b>';
    	    		$ss='';
    	    		$class=' ';
    	    		if($searchfield==$key){
    	    		    $ss=$search;
    	    		    $class=' show';
    	    		}
    	    		$ret.='<input type="text" class="dbsearch'.$class.'" value="'.$ss.'"/>';

    	    			$ret.='</th>';
    	    			$fields.='"'.$key.'",';
    	    		}
    	    		$ret.='<tr/></thead><tbody>';
    	    		$first=false;
    	    	}
    	    	$ret.='<tr data-ref="'.$row['ref'].'">';
    	    		foreach($row as $item){
    	    			$ret.='<td contenteditable=true>'.$item.'</td>';
    	    		}
    	    	
    	    	$ret.='</tr>';
    	    }
    	}
    	$ret.='</tbody></table>';
    	$fields=rtrim($fields,',').']';
    	echo '<script>var fields='.$fields.'</script>';
    	return $ret;
    	
    }
    

    
    static function listTables(){
    	$ret='';
    	$sql='show table status';
    	if($stmt=dbpdo::query($sql)){
    	    while($row = $stmt->fetch()){
    	        //$rc=self::getRowCount($row[0]);
    	        $rc=$row['Rows'];
    	        $ret.= '<a class="build-tablelink" href="?table='.$row['Name'].'"><i class="material-icons">toc</i>'.$row[0].'<span class="circle spot red">'.$rc.'</span></a><br/>';
    	    }
    	}
    	

    	
    	return $ret;
    }
    
    static function getRowCount($table){
        $sql='select count(*) as cc from '.$table;
        if($data=dbpdo::getQuery($sql)){
            return $data['cc'];
        }else{
            return -1;
        }

    }
    
    static function viewColumns(){
        $ret='';
        $sql='select * from '.clean::get('table').' limit 1';
        $_SESSION['builder']['table']=clean::get('table');
        if($stmt=dbpdo::getColumns($sql)){
            $row = $stmt->fetch();
            $cc=0;
            foreach($row as $field=>$value){
                $meta=$stmt->getColumnMeta($cc++);
                $native_type=$meta['native_type'];
                $name=$meta['name'];
            	$ret.= self::getField($meta);
            }
        }
        return $ret;
    }


    
    
    static function getField($meta){
        $ret='';
        $comment='//'.$meta['native_type'].' '.$meta['len'];
        $title=$meta['name'];
        switch($meta['native_type']){
            case 'LONGLONG':
                $ret.="echo form::input('$title','s12 m12');".$comment.'<br/>';
                break;
            case 'VAR_STRING':
                if($meta['len']>100){
                    $ret.="echo form::textarea('$title','s12 m12');".$comment.'<br/>';
                }else{
                    $ret.="echo form::input('$title','s12 m12');".$comment.'<br/>';
                }
                break;
            case 'DATE':
                $ret.="echo form::datePicker('$title','s12 m12');".$comment.'<br/>';
                break;
        }
        return $ret;
    }

    
    
}


?>