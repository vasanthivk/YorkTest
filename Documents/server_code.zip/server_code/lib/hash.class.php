<?php


class hash{
    
}


?>