<?php

    $sql='select * from menu where company=:company';
    $parms=array(':company'=>'David Lloyd');
    $menuarr=array();
	if($stmt=dbpdo::query($sql,$parms)){
	    while($row = $stmt->fetch()){
	    	$menuarr[$row['menu']][$row['submenu']]=$row['ref'];
	    }
	}
	
	print_r($menuarr);
	$sortorder=0;
    if (($handle = fopen("davidlloyd.csv", "r")) !== FALSE) {
        while (($data = fgetcsv($handle, 2000, ",")) !== FALSE) {
            //[0] => DishName [1] => Calories [2] => Fat1 [3] => SaturatedFat1 [4] => Carbohydrates [5] => Sugar1 [6] => Fibre [7] => Protein [8] => Sodium 
			if($data[2]!=''){
				if($data[2]=='H'){
					//echo 'Menu Ref '.$menuarr[trim($data[3])][''];
					$menu=trim($data[3]);
					$menuref=$menuarr[trim($data[3])][''];
					$submenuref=0;
				}else{
					//echo 'Sub Menu Ref '.$menuarr[$menu][trim($data[3])];
					$submenuref=$menuarr[$menu][trim($data[3])];
				}
			}else{
	            //($data);
	            //$arr=explode(',',$data);                
				//echo '<br/>';
	            //echo '<hr/>';
	            $bar='DL'.uniqid();
	            $ins=array('barcode_number'=>$bar,
	                        'product_title'=>$data[3],
	                        'category'=>'QSR Menu',
	                        'nutrition_numeric_energykcal'=>$data[4],
	                        'allergy_contains'=>$data[5],
	                        'allergy_may'=>$data[6],
	                        );
	            dbpdo::dbInsert('_productsdl',$ins,'',false,true);
	            $sortorder++;
	            if($submenuref==0){
	            	$prodref=$menuref;
	            }else{
	            	$prodref=$submenuref;
	            }
	            $menuins=array('menu_ref'=>$prodref,
	            				'barcode_number'=>$bar,
	            				'sort_order'=>$sortorder,
	            				'product_no'=>$data[0],
	            				'sub_product_no'=>$data[1],
	            				);
	            dbpdo::dbInsert('menu_products',$menuins,'',false,true);
			}
        }
        fclose($handle);
    }

?>