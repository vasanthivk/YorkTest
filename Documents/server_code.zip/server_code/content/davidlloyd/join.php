<?php



	    $sql='SELECT menu,submenu,description,product_title, barcode_number, menu_ref FROM `menu`
				inner join _productsdl on (_productsdl.menu_ref = menu.ref)
				WHERE company = :company order by sort_order asc';
	    $parms=array(':company'=>'David Lloyd');
		if($stmt=dbpdo::query($sql,$parms)){
		    while($row = $stmt->fetch()){
		    	$ins=array('menu_ref'=>$row['menu_ref'],'barcode_number'=>$row['barcode_number']);
                dbpdo::dbInsert('menu_products',$ins,'',false,true);
		    }
		}

?>