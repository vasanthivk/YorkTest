<?php

    $row = 1;
    if (($handle = fopen("recipenutrition.csv", "r")) !== FALSE) {
        while (($data = fgetcsv($handle, 2000, ",")) !== FALSE) {
            $num = count($data);
            $row++;
            $fields=array();
            $fields['barcode']=$data[0];
            if($row>5){
                //[0] => DishName [1] => Calories [2] => Fat1 [3] => SaturatedFat1 [4] => Carbohydrates [5] => Sugar1 [6] => Fibre [7] => Protein [8] => Sodium 
                print_r($fields);
                $arr=explode(chr(9),$fields['barcode']);                
                echo '<br/>';
                print_r($arr);
                echo '<hr/>';
                $ins=array('barcode_number'=>'DL'.uniqid(),
                            'product_title'=>$arr[0],'category'=>'QSR Menu',
                            'nutrition_numeric_energykcal'=>$arr[1],
                            'nutrition_numeric_fat'=>$arr[2],
                            'nutrition_numeric_satfat'=>$arr[3],
                            'nutrition_numeric_carbohydrate'=>$arr[4],
                            'nutrition_numeric_sugar'=>$arr[5],
                            'nutrition_numeric_fibre'=>$arr[6],
                            'nutrition_numeric_protein'=>$arr[7],
                            'nutrition_numeric_sodium'=>$arr[8],
                            );
                dbpdo::dbInsert('_productsdl',$ins,'',false,true);

                //$len=strlen($fields['barcode']);
                //for ($i = 0; $i <= $len; $i++) {
                //    echo substr($fields['barcode'],$i,1). ' '.ord(substr($fields['barcode'],$i,1)).'<br/>';
                //}    
            }
        }
        fclose($handle);
    }

?>