<?php 
	debug::logErrors();
	//print_r(clean::post());
	$msg='';
	$sent=false;
	//reset request
	if(clean::post('resetemail')!=''){
	    if(loginsimple::resetpassword(clean::post('resetemail'))){
	        $msg= 'Password Reset email sent';
	        $sent=true;
	   }
	}

	include '../adminlogin/_top.php';
?>

<div class='row'>			
	<div class='m4 offset-m4 s12 col center-align login'>
				<div class='logo logo-white'></div>
				<img class="responsive-img" src="../img/advisrlogo.svg" alt=""/>

		<h4>Reset Password</h4>
		<form action='#' method='post' >
		    <?php 
		        echo form::showHash();
		        if(!$sent){
		    ?>
			<div class="input-field col s12">
				<input value="" class="email" name="resetemail" type="text" placeholder="Email Address">
			</div>
			<button class='btn' type='submit'>Reset Password</button>
			<a class="extra-link" href="../adminlogin/login.php">Cancel</a>
		</form>
    		<?php 
		        }
				if($msg!=''){
					echo '<div class="col s12 red-warning">'.$msg.'</div>';	
					echo '<a href="../adminlogin/login.php" class="btn">Login</a> ';
				}
			?>

	</div>
		
</div><!--row-->
		
<?php 
    
	include '../admin/_footer.php';
	
?>