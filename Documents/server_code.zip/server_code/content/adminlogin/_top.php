<?php debug::logErrors();?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="hash" content="<?php echo form::buildHash();?>"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>Quicr</title>

    <!-- CSS  -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link href="../css/materialize.min.css" type="text/css" rel="stylesheet"/>
    
<link rel="stylesheet" type="text/css" href="../css/mediumed.css"/>
    
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link href="../admin/slide.css" type="text/css" rel="stylesheet"/>
    <link href="../admin/admin.css" type="text/css" rel="stylesheet"/>
    <link href="../admin/print.css" type="text/css" rel="stylesheet"/>



</head>
<body>

