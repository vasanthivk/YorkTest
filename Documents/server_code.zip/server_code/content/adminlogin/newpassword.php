<?php 
    page::set('showmenu','no');
	debug::logErrors();
	$msg='';
	//reset request
	if(clean::post('chngpassword')!=''){
	    $msg=loginsimple::newpasswordssl(clean::get('email'),clean::get('enc'),clean::post('chngpassword'),clean::post('chngrepeatpassword'));
	    if($msg==''){
	        secure::redirect('../login/login.php');
	        exit();
	    }
	}

	include '../adminlogin/_top.php';

?>

<div class='row'>			
	<div class='m4 offset-m4 s12 col center-align login'>
				<div class='logo logo-white'>Splenda</b></div>
		<h4>Reset Password</h4>
		<form action='#' method='post' >
		    <?php 
		        echo form::showHash();
		    ?>
					<div class="input-field col s12">
						<input value="" class="chngpassword" name="chngpassword" type="password" placeholder="Password - Min 8 Chars (Capital, lowercase &amp; numeric)">
					</div>
					<div class="input-field col s12">
						<input value="" class="chngrepeatpassword" name="chngrepeatpassword" type="password" placeholder="Re-enter Password">
					</div>
					<?php echo csrf::hiddenCSRF();?>
					<button class='btna' type='submit'>Reset Password</button>
		</form>
    		<?php 
				if($msg!=''){
					echo '<div class="col s12 red-warning">'.$msg.'</div>';	
				}
			?>

	</div>
		
</div><!--row-->
		
<?php 
    
	include '../admin/_footer.php';
	
?>