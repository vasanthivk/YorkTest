<?php 
	page::set('showmenu','no');
	debug::logErrors();
	$msg='';
	$ret='';
	$validate=false;
	if(clean::get('mode')=='logoff'){
	    session_destroy();
	}

	//login request
	if(clean::post('email')!=''){
		log::logInfo('###');
		log::logInfo(clean::post());
		log::logInfo('Stay Logged in is '.clean::post('stayloggedin'));
	    if(loginsimple::validate(clean::post('email'),clean::post('password'),clean::post('stayloggedin'),'people')){
		    $_SESSION['email']=clean::post('email');
    		if(loginsimple::hasAdminRight()){
    		    $validate=true;
        	}elseif(loginsimple::hasAdminRight('cms')){
    		    secure::redirect('../adminlogin/login.php');
    		}else{
    		    $rights=loginsimple::getUser('userrights');
    		    if(strpos($rights,'xxxx')!==false){
                    secure::redirect('../adminlogin/login.php');    		
    		    }elseif(strpos($rights,'zzzzr')!==false){
                    secure::redirect('../adminlogin/login.php');    		
    		    }
    		    secure::redirect('../adminlogin/login.php');
    		}
	   }else{
	   		$msg='Sorry email or password incorrect.';
	   }
	}else{
		$dx=count(clean::post());
		if($dx>0){
			$msg='Please enter an email address and password ';	
		}
		
	}
	
		include '../adminlogin/_top.php';
	
?>




	
	
<div class='row'>			
	<div class='m4 offset-m4 s12 col center-align login'>
				<div class='login-inner'>
					<?php 
			            if($validate){
			                include '_auth.php';
			            }else{
			                include '_loginform.php';    
    					    if($msg!=''){
	    					    echo '<div class="col s12 warning red-warning">'.$msg.'</div>';	
    					    }
		    			}
					?>
					<br/>
				    </div>
	</div>
</div><!--row-->


		
<?php 
	include '../admin/_footer.php';
?>


<script>
	
	

	$('#authkey').on('keyup',function(){
		t=$(this).val();
		if(t.length==6){
			validateAUTH();	
		}
	});


	function validateAUTH(){
		data=new Object();
		data['inauth']=$('.authkey').val();
		data['hash']=$('#hash').val();
		$('.authresult').load('../adminlogin/_authvalidate.php',data);
	}
</script>