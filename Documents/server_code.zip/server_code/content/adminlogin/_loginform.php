    <img class="responsive-img" src="../img/advisrlogo.svg" alt=""/>
	<form action='../adminlogin/login.php' method='post' >
	    <?php echo form::showHash();?>
		<div class="input-field col s12">
			<input autofocus value="<?php echo clean::post('email');?>" class="email" name="email" type="text" placeholder="Email Address">
		</div>
		<div class="input-field col s12">
			<input value="" class="password" name="password" type="password" placeholder="Password">
		</div>
		<?php echo csrf::hiddenCSRF();?>
		<button class='btn' type='submit'>Login</button> 
		<a href='../adminlogin/resetpassword.php'>Reset Password</a> 
	
	</form>
