<img class="responsive-img" src="../img/advisrlogo.svg" alt=""/>
<?php echo form::showHash();?>
<input autofocus type='text' id='authkey' class='authkey' placeholder='AUTH Key' />
<button class='login-button btn' onclick='validateAUTH();return false;' href=''>Login</button>
<div class='authresult'></div>
