<?php

    session_destroy();
    

?>