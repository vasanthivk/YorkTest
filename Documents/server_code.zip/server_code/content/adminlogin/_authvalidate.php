<?php
	//require_once('googleauth.php');

	$ga = new googleauthenticator();


	
	$secretkey=loginsimple::getSecret();
	$currentcode = clean::post('inauth');
	
	



	if($ga->verifyCode($secretkey, $currentcode, 2)){
		$location='../admin/index.php';
		debug::add('Redirect to ',$location);
		echo 'Logged in';
		$_SESSION['login']['2party']=true;
		echo '<script type="text/javascript">window.location = "'.$location.'"</script>';		
	}else{
		echo '<div class="alert alert-error">';
//		echo 'Login Failed - Check Time on Server '.date('Y-m-d H:i:s');
		echo 'Login Failed';
		echo '</div>';
	}

?>
