<?php




    print_r(profile::userProfiles('4c675dbe-9b60-11e6-90c4-005056bd66c5'));
    
    print_r(profile::profileDetail('8546e3d8-9b61-11e6-90c4-005056bd66c5'));

?>