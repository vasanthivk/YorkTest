<?php
echo '-------';
print_r(clean::post());
echo '-------';

?>