<?php
	header("Access-Control-Allow-Origin: *");
    log::logInfo('barcode request'.clean::get('code'));
    slack::message('barcode '.clean::get('code'),'#barcodes');
    $prod= products::ByBarcode(clean::get('code'));
    
    echo $prod;
    $prodList=explode('|',$prod);
    push::send($prodList[0].' '.clean::get('code').'|'.$prodList[2]);
    
    




?>