<?php

    $row = 1;
    if (($handle = fopen("barcodes.csv", "r")) !== FALSE) {
        while (($data = fgetcsv($handle, 2000, ",")) !== FALSE) {
            $num = count($data);
            $row++;
            $fields=array();
            $fields['barcode']=$data[0];
            print_r($fields);
                dbpdo::dbInsert('quicr_barcodes',$fields,'',true,true);
            echo '<hr/>';
        }
        fclose($handle);
    }

?>