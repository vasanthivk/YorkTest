<?php

    //echo products::byBarcode('5000157024886');
    echo '<br/><br/>';
    echo profile::listUsers();
    echo '<br/><br/>';
    echo profile::userProfiles('a1');
    echo '<br/><br/>';
    
    $sql='select * from products order by title asc;';
    $parms=array();
    $fields=array();
	if($stmt=dbpdo::query($sql,$parms)){
	    while($row = $stmt->fetch()){
	        $fields['nutrition']=import::stripChars($row['nutrition']);
	        $fields['cook']=import::stripChars($row['cook']);
	        $fields['recycling']=import::stripChars($row['nutrition']);
	        $fields['ataglance']=import::stripChars($row['nutrition']);
	        $fields['additives']=import::stripChars($row['nutrition']);
            dbpdo::dbUpdate('products',$row['ref'],$fields);
            //echo $all;
	    }
	}
echo debug::show();
?>