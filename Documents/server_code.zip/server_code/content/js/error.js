window.onerror = function(msg, url, line){
    //alert(msg+' '+url+' '+line);   
    data={};
    data['msg']=msg;
    data['url']=url;
    data['line']=line;
    $.post('../m/jserror.php',data);
};