$(document).ready(
	function(){
		//$( ".cms-sidebar" ).draggable({ handle: ".cms-sidebar-handle" });
});


function addCms(){
	$('.cms-drag').remove();
	$('.cms-menu').remove();
	$('.cms-wrap .cms-panel').each(function(){
		if($(this).parent().hasClass('cms-sort')){
			$(this).unwrap();		
		}
	});
	$('.cms-wrap .cms-panel').wrap("<div class='cms-sort' data-r='cms-temp'></div>");
	$('.cms-wrap .cms-sort').prepend("<i class='mdi-content-add cms-drag'></i>");
	$('.cms-wrap .cms-sort').prepend("<i class='mdi-action-list cms-menu dropdown-button' data-activates='dropdown1'></i>");
	startTextEdit();
	$('.cms-image').after('<a href="#modal1" class="circle cms-img-up modal-trigger">+</a>');
	return false;
	
	
	
}

$('body').on('click','.cms-img-up',function(){
	alert(2);
	$('#modal1').openModal();
});




$('body').on('click','.action-cms-edit',function(){
	alert(1);
	addCms();
 $( ".cms-segment" ).draggable({
      connectToSortable: ".cms-wrap",
      helper: "clone",
      revert: "invalid",
      stop: function( event, ui ) {
      		tt=ui.helper;
      		tt.html('<div class="row section cms-panel cms-newitem">Test</div>');
      		tt.attr('style','');
      		ff=tt.data('cmsseg');
      		$('.cms-newitem').load('../cms/segments/'+ff+'.php',function(){
      			$(this).removeClass('cms-newitem');
      			$(this).children().unwrap();
      		});
      		addCms();
      }
    });
    
  $( ".cms-wrap" ).sortable({ handle: ".cms-drag" });
});
    
    
    
 function unwrap(){
 	$('.cms-wrap .cms-sort').children().unwrap();
	//now get rid of the dynamic content
	$('.cms-dynamic').each(function(){
		t=$(this);
		dd=t.data('dynamic');
		t.html('#['+dd+']#');
		
	});
	
 }  


$('.action-cms-unwrap').on('click',function(){
	//first unwrap the moveable divs
	$('.cms-panel').unwrap();
	//now get rid of the dynamic content
	$('.cms-dynamic').each(function(){
		t=$(this);
		dd=t.data('dynamic');
		t.html('#['+dd+']#');
		
	});
});

$('.action-cms-crop').click(function(){
	alert(1);
$('.cropper-example-1 > img').cropper({
  aspectRatio: 16 / 9,
  autoCropArea: 0.65,
  strict: false,
  guides: false,
  highlight: false,
  dragCrop: false,
  movable: false,
  resizable: false
});
});

$('.action-cms-test').click(function(){
	$('.cms-wrap').html('');
});

$('body').on('click','.cms-menux',function(){
	p=$(this).parent();
	hh=p.html();
	p.after(hh);
});

var preSaved;


$('.action-cms-save').on('click',function(){
	alert(3);
	preSaved=$('.cms-wrap').html();
	unwrap();	
	fname=window.location.pathname;
	Materialize.toast('Saving page '+fname, 1000);
	ob={};
	ob['data']=$('.cms-wrap').html();
	ob['filename']=fname;
	$('.cms-saved').load('../cms/save.php',ob,function(){
		Materialize.toast('Page Saved... '+fname, 2000);
		$('.cms-wrap').html(preSaved);
	});
});

$('.action-cms-load').on('click',function(){
	$('.cms-wrap').load('../cms/testload.php');
});

$('.action-cms-textedit').on('click',function(){
	
	startTextEdit();	
});


function startTextEdit(){
        var editor = new MediumEditor('.editable', {
                buttonLabels: 'fontawesome',
                placeholder: {
        text: 'Type your text'
    },
    buttons: ['bold', 'italic', 'quote','anchor','orderedlist','unorderedlist','header1','header2'],
                paste: {
                cleanPastedHTML: true,
                forcePlainText: false,
                autoLink: true
            }
            }),
            cssLink = document.getElementById('medium-editor-theme');
	
}