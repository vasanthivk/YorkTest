(function($){
  $(function(){
    $('select').material_select();
    $('.button-collapse').sideNav();

    $('.dropdown-button').dropdown({
      constrain_width: false, // Does not change width of dropdown to that of the activator
      hover: false, // Activate on hover
      gutter: 0, // Spacing from edge
      belowOrigin: true, // Displays dropdown below the button
      alignment: 'left' // Displays dropdown with edge aligned to the left of button
    }
  );
  
  $('.prefocus').on('click',function(){
  	setTimeout(function(){$('#email').focus();},200);
  });
  
  
  $('.act-mobile-menu').on('click',function(){
  	$('.zoom-dot').addClass('zoom');
  	setTimeout(function(){$('.mobile-menu').show();$('.zoom-dot').removeClass('zoom')},400);
  	return false;
  });
  
  $('.mobile-menu').on('click',function(){
  	$(this).hide();
  	
  });
  
  $(window).on('scroll', function() {scrollBits();});
  
  $('.act-signup-btn').on('click',function(){
      
      email=$('#email').val();
      if(ct.validateEmail(email)){
        $('.act-signup-btn').hide();
        obb={};
        obb['email']=email;
        $('.result').html('testing');
        $.post('../s/contactp1.php',obb);
        $('.signup-main').show('fast',function(){
        	$('#fullname').focus();
        }); 
        
      }else{
        Materialize.toast('Please enter  valid email address', 4000);    
      }
      return false;
  });
  
  $('.act-signup2-btn').on('click',function(){
  		
      obb={};
      company=$(this).attr('href');
      company=company.substr(1);
      obb['contenttype']=company;
      $('.contact-field').each(function(){
          t=$(this);
          id=t.attr('id');
          obb[id]=t.val();
      });
      $('.signup-box').html(progress());
      errors=false;
      fullname=obb['fullname'];
      if(fullname.length<4){
      	message='Please enter your name';
      	errors=true;
      }
      
      if(!errors){
	       $.post('../s/contactp2.php',obb,function(){
	          $('.signup-box').html('<div class="contact-thank"><h3>Thank You</h3>We will be in touch shortly.</div>');
	      });

      	
      }else{
      	Materialize.toast(message, 4000); 		
     }

      return false;
  });
  
  

    

  }); // end of document ready
})(jQuery); // end of jQuery name space


    var lastScroll=0;
    var currentClass='nav-tran';

    function scrollBits(){
        st=$(document).scrollTop();
        if(st>lastScroll){
            dir='up';
        }else{
            dir='down';
        }
        lastScroll=st;
        if(st>100){
            if(dir=='up'){
                thisClass='nav-white';
            }else{
                thisClass='nav-white';
            }
        }else{
            thisClass='nav-tran';
        }
        if(currentClass!=thisClass){
            $('.nav-wrapper').removeClass('nav-hide nav-white').addClass(thisClass);
        }
        currentClass=thisClass;
    }




    var wordIdx=0;
    var chrIdx=1;
    var words=['OPERA','THEATRE','BALLET','ESPORTS','MUSIC','COMEDY','SPORTS'];
    var wordsLen=words.length;

    setTimeout(function(){drawWord();},100);
    
    function drawWord(){
        delay=150;
        word=words[wordIdx];
        wpart=word.substr(0,chrIdx);
        chrIdx++;
        if(chrIdx>word.length){
            chrIdx=1;
            wordIdx++;
            delay=1000;
            $('#trs').hide();
        }else{
            wpart+='<b>|</b>';
        }
        $('.word-target').html(wpart);
        if(wordIdx>=wordsLen){
            wordIdx=0;
        }
        setTimeout(function(){drawWord();},delay);
    }



    $('body').on('click','.refreshdisplay',function(){
        t=$(this);
        $('.displayContent').load('../s/_displaycontent.php?ref='+t.data('ref'),function(){
        });
        return false;
    });
    
    function progress(){
    	return '<div class="progress"><div class="indeterminate"></div></div>';
    }

    







