$('body').on('click','.action-toggle-debug',function(){
    $('#debug-detail').show('fast');
    return false;
});

$('body').on('click','.jslog',function(){
    $('.jslogview').toggle();
});


function debugclass(){
 
 
         this.log=function(logText){
            $('.jslogview').prepend('<p>'+logText+'</p>');
        }
   
}

debug=new debugclass();

  $(document).ready(function() {
    $('select').material_select();
  });    
