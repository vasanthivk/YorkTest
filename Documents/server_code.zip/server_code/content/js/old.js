    $('body').on('click','.btn-editlocation',function(){
        t=$(this);
        $('.form-list').slideUp('fast');
        $('.form-detail').slideDown('fast');
        $('.form-detail').load('../admin/_locationmod.php?ref='+t.data('ref'),function(){
            form.focus();
        });
    });
    

    $('body').on('click','.btn-editpeople',function(){
        t=$(this);
        $('.form-list').slideUp('fast');
        $('.form-detail').slideDown('fast');
        $('.form-detail').load('../admin/_peoplemod.php?ref='+t.data('ref'),function(){
            form.focus();
        });
    });
    
    $('body').on('click','.btn-editevent',function(){
        t=$(this);
        $('.form-list').slideUp('fast');
        $('.form-detail').slideDown('fast');
        $('.form-detail').load('../admin/_eventmod.php?ref='+t.data('ref'),function(){
            form.focus();
            form.initDate();
        });
    });
    
