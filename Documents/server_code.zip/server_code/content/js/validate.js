





ct= new Object();

ct.validate=function(tClass){
	//alert('start');
	if (typeof tClass === 'undefined') { tClass = 'validate'; }
	valCount=0;
	//$('.val-text').remove();

	$('.'+tClass).next('.val-text').remove();

	$('.field-error').removeClass('field-error');
	$('.'+tClass).each(function(){
		t=$(this);
		validate=t.val();
		txt=t.data('validate');
		valArr=txt.split(':');
		valType=valArr[0];
		valData=valArr[1];
		switch(valType){
			case('postcode'):
				if(!ct.validatePostcode(validate)){
					valCount++;
					t.addClass('field-error');
					t.after('<div class="val-text">Please enter a valid postcode</div>');	
				}

				break;
			case('min'):
				vl=validate.length;
				if(vl<parseInt(valData)){
					t.addClass('field-error');
					valCount++;
					if(valArr[2]!=undefined){
						ctxt=valArr[2];
					}else{
						ctxt='Please enter at least '+valData+' chrs';
					}
					t.after('<div class="val-text">'+ctxt+'</div>');	
				}
					
				break;
			case('minnumb'):
				nospace=str = validate.replace(/\s+/g, '');
				vl=nospace.length;

				if(vl<parseInt(valData) || $.isNumeric(nospace)==false){
					t.addClass('field-error');
					valCount++;
					if(valArr[2]!=undefined){
						ctxt=valArr[2];
					}else{
						ctxt='Please enter at least '+valData+' digits 0-9 only';
					}
					t.after('<div class="val-text">'+ctxt+'</div>');	
				}
					
				break;
			case('musthave'):
				vl=validate.length;
				if(vl<1){
					valCount++;
					t.addClass('field-error');
					if(valArr[2]!=undefined){
						//alert(valArr[2]);
						ctxt=valArr[2];
					}else{
						ctxt='Please enter some information';
					}
					t.after('<div class="val-text">'+ctxt+'</div>');	
				}
					
				break;
			case('email'):
				if(!ct.validateEmail(validate)){
					valCount++;
					t.addClass('field-error');
					t.after('<div class="val-text">Please enter a valid email address</div>');
				}

				break;

			case('phone'):
				if(!ct.validatePhone(validate)){
					valCount++;
					t.addClass('field-error');
					t.after('<div class="val-text">Please enter a valid phone number</div>');
				}

				break;


		}

	});


	return valCount;
}


 ct.validatePostcode=function(postcode){
	var regPostcode = /^([a-zA-Z]){1}([0-9][0-9]|[0-9]|[a-zA-Z][0-9][a-zA-Z]|[a-zA-Z][0-9][0-9]|[a-zA-Z][0-9]){1}([ ])([0-9][a-zA-z][a-zA-z]){1}$/;
	return regPostcode.test(postcode);
}

ct.validateEmail=function(email) { 
    var re = /\S+@\S+/;
    return re.test(email);
} 

ct.validatePhone =function(p) {
  
  return;
}

ct.forceNumeric=function(event){
return ( event.ctrlKey || event.altKey 
                    || (47<event.keyCode && event.keyCode<58 && event.shiftKey==false) 
                    || (95<event.keyCode && event.keyCode<106)
                    || (event.keyCode==8) || (event.keyCode==9) 
                    || (event.keyCode>34 && event.keyCode<40) 
                    || (event.keyCode==46) )	
}




