    $('body').on('click','.act-form-save',function(){
        t=$(this);
        form.loader();
        data={};
        m=$('.main-save');
        m.find('input,textarea,select').each(function(){
            tt=$(this);
            if($(this).attr('id') !== undefined){
                data[$(this).attr('id')]=$(this).val();
            }
        })
        $.post('../admin/do.php?m=save',data,function(){
            location.reload();
        });
        return false;
    });
    
        $('body').on('click','.act-form-edit',function(){
            t=$(this);
            $('.form-list').slideUp('fast');
            $('.form-detail').slideDown('fast');
            $('.form-detail').load('../admin/do.php?m=edit&ref='+t.data('ref'),function(){
                form.focus();
                form.initDate();
            });
            return false;
        });

    
    $('body').on('click','.act-form-del',function(){
        t=$(this);
        if(confirm('Are you sure you want to delete? ')){
            obb={};
            obb['formhash']=$('#formhash').val();
            $.post('../admin/do.php?m=del',obb,function(){
                //location.reload();
            });
            
        }
        return false;
    });
    
    
    function formclass(){
        
        this.focus=function(){
            $('.form-start').find(':input').focus();
        }
        
        this.loader=function(){
            ll='<div class="progress"><div class="indeterminate"></div></div>';
            $('.form-detail').prepend(ll);
        }
        
        this.initDate=function(){
                $('.datepicker').pickadate({
                selectMonths: true, 
                selectYears: 15 
                });

            
        }
        
        
    }
    
    form=new formclass();
    
  $(document).ready(function() {
    $('select').material_select();
  });    


	$('.validate-form').on('submit',function(){
		if(ct.validate()>0){
			return false;
		}else{
			
		}
		
	});
	
