var didScroll = false;
var classState='';
var $window = $(window);
var $headItems=$('.head-wrap');
$window.on('scroll', checkScroll);
scrollPage();


function checkScroll(){
    
	if( !didScroll ) {
		didScroll = true;
		
		setTimeout( scrollPage, 100 );
	}	
}

function scrollPage(){
	st=$(document).scrollTop();
	if(st>300){
		if(classState===''){
		    $headItems.addClass('scrolled');
		    classState='on';
		    
		}
	}else{
		if(classState==='on'){
            $headItems.removeClass('scrolled');
		    classState='';		    
		}
	}
	didScroll = false;	
}




