
    


function postcodeclass(){
    
    
        this.lookup=function(){
            postcode=$('.postcode-lookup').val();
            pcl=$('.postcode-list');
            pcl.html('Loading...').stop().fadeTo('fast',0.3);
            $('#modalpostcode').openModal();
            obb={};
            obb['postcode']=postcode;
            
            pcl.load('../s/loadpostcodes.php',obb,function(){
                $(this).stop().fadeTo('fast',1);
            });
        }
        
        this.update=function(t){
            addr=t.data('address');
            dd=addr.split(',');
            cc=1;
            dd.forEach(function(entry) {
                $('.pc'+cc).val(entry);
                cc++;
            });
            $('#modalpostcode').closeModal();
        }
    }
    
    postcode=new postcodeclass();
    
$('body').on('click','.act-postcode',function(){
        postcode.lookup();
        return false;
    });
    
$('body').on('click','.postcode-list a',function(){
        postcode.update($(this));
        return false;
    });
