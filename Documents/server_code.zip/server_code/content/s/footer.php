<div class="timezones"></div>

  <!--  Scripts-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.1/js/materialize.min.js"></script>
    
    
    
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.6/Chart.min.js"></script>
    <script src="../js/moment.js"></script>
    <script src="../js/moment-timezone.js"></script>
   
    
    
    
    <script src="../js/medium.min.js"></script>

    <script src="../js/form.js?v=0.1i"></script>
    <script src="../js/validate.js"></script>
    <script src="../js/highlight.js"></script>


    <div class="test"></div>
     <div class="test1"></div>
     <div class="cache"></div>
  </body>
</html>
