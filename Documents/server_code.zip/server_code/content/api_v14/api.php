<?php
header("Access-Control-Allow-Origin: *");
    $l=clean::get('var');
    log::logInfo('Api call '.$l);
    if(!validateCall($l)){
    	die('ERROR');
    }
    $passed=explode('/',$l);
    $command=$passed[0];
    $p4=h::safeArray($passed,4);
    $p3=h::safeArray($passed,3);
    $p2=h::safeArray($passed,2);
    $p1=h::safeArray($passed,1);
    $jwtEncoded=h::safeArray($passed,1);
    
    if($jwtEncoded=='nokey'){
    	$decode=array();
    	$email='...';
    }else{
    	$key=settings::getSettings('JWT','key');
    	$decode=JWT::decode($jwtEncoded,$key);	

    	$email=$decode->email;
    }
    switch($command){
    	case 'messages':
    		echo messages::active();
    		break;
    	case 'schoolmenu':
    		echo school::menu();
    		break;
    	case 'menu':
    		echo file_get_contents('../menu/dlmenu.html');
    		break;
    	case 'dlprofiles':
			echo file_get_contents('../menu.dlmenu.html');
    		
    		break;
    	case 'share':
    		$barcode=clean::post('barcode');
    		$comments=clean::post('comments');
    		$groups=clean::post('groups');
    		$handle=clean::post('handle');
    		
    		echo share::saveShare($email,$handle,$groups,$barcode,$comments);
    		break;
    	case 'savehandle':
    		if($email!=''){
    			if(share::freeHandle($passed[2],$email)=='NOTFOUND'){
	     			$fields=array('handle'=>$passed[2]);
	    			//dbpdo::dbUpdate('appusers',$email,$fields,'email');
	    			dbpdo::dbInsertUpdate('appusers',$email,$fields,'email');
	    			echo 'OK|'.$passed[2];
   				
    			}else{
    				echo 'EXISTS|'.$passed[2];
    			}
    		}else{
    		}
    		break;
    	case 'sharelist':
    		echo share::myShares($email);
    		break;
    	case 'gethandle':
    		echo share::getHandle($email);
    		break;
    	case 'getskin':
    		echo skin::getSkin($email);
    		break;
    	case 'feedback':
    		feedback::save($decode);
    		break;
    	case 'feedbacklist':
    		echo feedback::listIssues($email);
    		break;
    	case 'getjwt':
    		echo login::getJWT($p2,$passed[3],$passed[4]);
    		break;
        case 'login':
            $ret= login::validate2($p2,$p3,$passed[4],$passed[5]);
            echo $ret;
            
            break;
        case 'signup':
            $ret= login::signup($p2,$p3);
            echo $ret;
            break;
        case 'reset':
            echo login::resetPassword($p2);
            break;
        case 'change':
            echo login::changePassword($p1,$p2,$p3);
            break;
        case 'profiles':
        	echo json_encode(profiles::getAll(),JSON_PARTIAL_OUTPUT_ON_ERROR);
        	break;
        case 'allergens':
        	$ret=array();
        	$ret['A']=allergens::api('A');
        	$ret['I']=allergens::api('I');
        	$ret['L']=allergens::api('L');
        	echo json_encode($ret,JSON_PARTIAL_OUTPUT_ON_ERROR);
        	break;
        case 'barcode':
        	$barcode=$p2;
        	$latLong=$p3;
        	$sliders=h::safeArray($passed,4);
        	$profileRef=h::safeArray($passed,5);
        	$ret= trim(products::getBarcodev14($barcode,$email,$latLong,$sliders,$profileRef));
        	echo $ret;
        	break;
        case 'loadcache':
        	echo products::getCache();
        	break;
        case 'loadcachetest':
        	echo products::getCache('_products500');
        	break;

        case 'jserror':
        	slack::message(print_r($passed,true),'#quicrerrors');
        	slack::message($p2.'.'.$p3.'.'.$p4,'#quicrerrors');
        	break;
        	





    	case 'prodcache':
    		echo json_encode(products::getAll());
    		break;
    	case 'prodcachenew':
    		echo json_encode(products::BBgetAll());
    		break;

    	case 'rules':
    		echo json_encode(profile::getRules());
    		break;
    	case 'fullitem':
    	    //slack::message('API Fullitem '.$passed[2],'#debug');
    		barcode::getItem($p2,$p1);
    		break;
        case 'listusers':
            echo profile::listUsers();
            break;
        case 'getuser':
            echo profile::getUser($p1);
            break;
        case 'getuserall':
        	echo json_encode(profile::getUserAll($p2));
        	break;
        case 'listprofiles':
            echo profile::userProfiles($p1);
            break;
        case 'valtitles':
            echo json_encode(products::valTitles());
            break;
        case 'settings':
        	echo json_encode(profile::APIlistSettings());
        	break;
         case 'settingsdebug':
        	echo json_encode(profile::APIlistSettings());
        	profile::showJsonError();
        	break;
      	
        	
        	
        	
        	
        default:
            echo 'Invalid api command';
            break;
    }
    
    function validateCall($inText){
    	$hash='.xfa8flP4K03LsT3jeya3O38FCMaE3p';
    	$x=explode('/||',$inText);

    	$md=md5('/'.$x[0].$hash);
    	if($md==$x[1]){
    		return true;
    	}else{
    		return false;
    	}
    }
    
    
    

?>