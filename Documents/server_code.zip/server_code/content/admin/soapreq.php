<?php

    $data=soap::GetUnsentProductData();
    
    print_r($data);

?>