<?php
    include '_top.php'; 
    
	echo '<div class="row">';
		echo '<div class="container">';
			echo '<div class="col s12 m8 offset-m2">';
			    $ret='';
			    if(count(clean::post())>1){
			        $delparms=array('profile_ref'=>clean::get('ref'));
		        	$sql='delete from profile_preferences where profile_ref=:profile_ref';
		        	dbpdo::query($sql,$delparms);
			        foreach(clean::post() as $key=>$val){
			            if(strpos($key,'=')===false){
			            	$exp=explode('/',$key);
				            $arr[$exp[0]]['category']=$exp[1];
				            $arr[$exp[0]]['score']=$val;
			            }else{
			            	$exp=explode('=',$key);
			            	$arr[$exp[2]]['score'.$exp[1]]=$val;
			            	$arr[$exp[2]]['category']=$exp[0];
			            }
			        }
			        foreach($arr as $key=>$val){
			        	$fields=array();
			        	$fields['profile_ref']=clean::get('ref');
			        	foreach($val as $k=>$v){
			        		$fields[$k]=$v;
			        	}
			        	dbpdo::dbInsert('profile_preferences',$fields);
//			        	print_r($fields);
			        	//echo '<br/><br/><br/>';
			        }
			        
			        $ret= 'Updated';
			    }    
?>
	<h3>Profiles Edit</h3>

<?php
   
	    $sql='select profile.ref, concat(firstnames, " ", surname) as name, profile.name as pname 
	    		from profile 
	    		inner join person on (person.ref=profile.personref)
	    		where surname like "Demo%" 
	    		and profile.ref=:ref
	    		order by name asc;';
	    $parms=array(':ref'=>clean::get('ref'));
        
		if($stmt=dbpdo::query($sql,$parms)){
		    $row = $stmt->fetch();
	    	echo '<h5>'.$row['name'].' - '.$row['pname'].'</h5>';
	    	$profileref=$row['ref'];
	    	
		}


        echo '<form action="#" method="post">';
            //echo '<input type="input" name="profile_ref" value="'.clean::get('ref').'" />';
            echo profile::listPerferences(clean::get('ref'),$profileref);
    		echo '<button type="submit" class="btn">Update</button>';
    		echo '<br/>'.$ret;
        echo '</form>';
           // echo profile::listUsersTable();
        
        
        

    		echo '</div>';
		echo '</div>';
	echo '</div>';
	//echo debug::show();
?>

<?php
    include '_footer.php';
?>