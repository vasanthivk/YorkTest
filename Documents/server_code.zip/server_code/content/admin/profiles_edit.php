<?php
    include '_top.php'; 
    
	echo '<div class="row">';
		echo '<div class="container">';
			echo '<div class="col s12 m8 offset-m2">';
			    $ret='';
			    if(count(clean::post())>1){
			        foreach(clean::post() as $key=>$val){
						$fields[$key]=$val;
			        }
			        if(clean::post('ref')!='new'){
			    		dbpdo::dbUpdate('profiles',clean::post('ref'),$fields);
			    	}else{
			    		dbpdo::dbInsert('profile',$fields);	
			    	}
			        $ret= 'Updated';
			    }    
?>
	<h3>Profiles Edit</h3>

<?php
   
	    $sql='select profiles.*
	    		from profiles 
	    		where ref=:ref;';
	    $parms=array(':ref'=>clean::get('ref'));
        
		if($stmt=dbpdo::query($sql,$parms)){
		    $row = $stmt->fetch();
		}
		


        echo '<form action="#" method="post">';
            echo '<input type="hidden" name="ref" value="'.$row['ref'].'" /><br/>';
            echo '<label>Name</label><br/>';
            echo '<input type="input" name="name" value="'.$row['name'].'" /><br/>';
            echo '<label>Calories</label><br/>';
            echo '<input type="input" name="calories" value="'.$row['calories'].'" /><br/>';

            echo '<label>Total Fat</label><br/>';
            echo '<input type="input" name="totalfat" value="'.$row['totalfat'].'" /><br/>';
            echo '<label>Saturated Fat</label><br/>';
            echo '<input type="input" name="saturatedfat" value="'.$row['saturatedfat'].'" /><br/>';
            echo '<label>Salt</label><br/>';
            echo '<input type="input" name="salt" value="'.$row['salt'].'" /><br/>';
            echo '<label>Sugar</label><br/>';
            echo '<input type="input" name="sugar" value="'.$row['sugar'].'" /><br/>';
            echo '<label>Protein</label><br/>';
            echo '<input type="input" name="protien" value="'.$row['protien'].'" /><br/>';
            echo '<label>Carbs</label><br/>';
            echo '<input type="input" name="carbs" value="'.$row['carbs'].'" /><br/>';
            echo '<label>Fibre</label><br/>';
            echo '<input type="input" name="fibre" value="'.$row['fibre'].'" /><br/>';
            echo '<label>Cholesterol</label><br/>';
            echo '<input type="input" name="cholesterol" value="'.$row['cholesterol'].'" /><br/>';
            echo '<label>Ingredients</label><br/>';
            echo '<textarea style="min-height:200px;" name="ingredients">'.$row['ingredients'].'</textarea><br/>';
            echo '<label>Likes</label><br/>';
            echo '<textarea style="min-height:200px;" name="likes">'.$row['likes'].'</textarea><br/>';

            echo '<input type="input" name="display" value="'.$row['display'].'" /><br/>';

    		echo '<button type="submit" class="btn">Update</button>';
    		echo '<br/>'.$ret;
        echo '</form>';

        
        

    		echo '</div>';
		echo '</div>';
	echo '</div>';
?>

<?php
    include '_footer.php';
?>