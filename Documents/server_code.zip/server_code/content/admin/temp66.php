<?php
    include '_top.php'; 
    
	echo '<div class="row">';
		echo '<div class="container">';
		    echo '<div class="col s12">';
		    
		    $path='../tempimages';
		    $dd=scandir($path);
		    print_r($dd);
		    foreach($dd as $file){
		        if($file!='.' && $file!='..'){
		            $fp=pathinfo($file);
		            print_r($fp);
		            echo '<br/>';
		            $fileName=$fp['filename'];
		            $md5=md5($fileName.'.xfa8flP4K03LsT3jeya3O38FCMaE3p');
		            //rename($path.'/'.$file,$path.'/'.$md5.'.jpg');
		        }
		    }
		    
		    
		    
            echo '</div>';
            
		echo '</div>';
	echo '</div>';

?>

<?php
    include '_footer.php';
?>
