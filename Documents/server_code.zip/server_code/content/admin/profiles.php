<?php
    include '_top.php'; 
    
	echo '<div class="row">';
		echo '<div class="container">';
  			echo '<div class="col s12 m6 offset-m1">';
         
?>
	<h3>Profiles</h3>

<?php
   
            echo profiles::listProfiles();
        
        
        

			echo '</div>';
		echo '</div>';
	echo '</div>';

?>

<?php
    include '_footer.php';
?>