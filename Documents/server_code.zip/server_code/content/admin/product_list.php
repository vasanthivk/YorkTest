<?php
    include '_top.php'; 
    
	echo '<div class="row">';
		echo '<div class="container">';
   			echo '<div class="col s12 m10 offset-m1">';
     
?>
	<h3>Products List</h3>
	<form action="product_import.php" method="post" class="noprint">
		<div class="col s12 m4">
		<label>Product Ref</label>
		<input type="text" name="productref"/>
		</div>
		<div class="col s12 m4">
		<label>Bar Code</label>
		<input type="text" name="barcode"/>
		</div>
		<div class="col s12 m4">

		<?php
		    $groups=array('Burgers','Butter','Cereal','Coffee','Couscous','Pudding','Ready Meal','Salads','Sandwiches','Sauces','Soups','Teabag','Yoghurt');
    	    echo '<div class="input-field col s12">';
                echo '<select name="category" class="cat-change">';
                    foreach($groups as $k){
                        echo '<option value="'.$k.'">'.$k.'</option>';
                    }
                    echo '</select>';
                    echo '<label>Grouping</label>';
            echo '</div>';
        ?>    
        </div>
        <div class="col s12">
			<input type="submit" class='btn' value="Import">
		</div>
	</form>
	
<?php
   
            echo products::listProducts();
        
        
        

    		echo '</div>';
		echo '</div>';
	echo '</div>';

?>

<?php
    include '_footer.php';
?>


<script>
    $('body').on('click','.act-drill-down',function(){
    	$(this).addClass('scale');
        window.location='../admin/product_edit.php?ref='+$(this).data('ref');
        return false;
    });


var settings = {
          output:"bmp",
          barWidth: 2,
          barHeight: 55
        };

    $('.barcode').each(function(){
        t=$(this);
        xx=t.html();
        t.html('<b>'+xx+'</b>');
        t.barcode(t.text(),"ean13",settings);

    });

</script>