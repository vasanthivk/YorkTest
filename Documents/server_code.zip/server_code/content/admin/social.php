<?php
    include '_top.php'; 
    
	echo '<div class="row">';
		echo '<div class="container">';
		    echo '<div class="col s12">';
		        echo '<h2>Social</h2>';
	        
				echo '<div class="col s12 m8 offset-m2">';
					echo '<input placeholder="Enter search text here" style="text-align:center;" type="text" id="socialsearch" />';
				echo '</div>';
				echo '<div class="col s12 m12 searchres">';
					include '_socialsearch.php';
				echo '</div>';
		     echo '</div>';
		echo '</div>';
	echo '</div>';

?>

<?php
    include '_footer.php';
   // echo debug::show();
?>
<script>

    $('body').on('keydown','#socialsearch',function(e){
        if(e.keyCode==13){
            runSearch();
            return false;
        }
        
    });


	
	function runSearch(){
		search=$('#socialsearch').val();
		search=search.toLowerCase();
    	data={};
	    data['search']=search;
		$('.searchres').load('_socialsearch.php',data);
	}

    $('body').on('click','.act-btn-approve',function(e){
    	data={};
	    data['action']=$(this).data('action');
	    data['ref']=$(this).data('ref');
	    const pp=$('.btnStatus-'+data['ref']);
	    pp.text('Updating...');
		pp.load('_socialupdate.php',data);
		return false;
    });


</script>

