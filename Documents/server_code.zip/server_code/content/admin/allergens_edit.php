<?php
    include '_top.php'; 
    

	echo '<div class="row">';
		echo '<div class="container">';
			echo '<div class="col s12 m8 offset-m2">';
			    $ret='';
			    if(count(clean::post())>1){
			        foreach(clean::post() as $key=>$val){
						$fields[$key]=$val;
			        }
			        if(clean::post('ref')!='new'){
			    		dbpdo::dbUpdate('allergens',clean::post('ref'),$fields);
			    	}else{
			    		dbpdo::dbInsert('allergens',$fields);	
			    	}
			        $ret= 'Updated';
			    }    
?>
	

<?php
   
	    $sql='select allergens.*
	    		from allergens 
	    		where ref=:ref;';
	    $parms=array(':ref'=>clean::get('ref'));
        
		if($stmt=dbpdo::query($sql,$parms)){
		    $row = $stmt->fetch();
		    if($row['type']=='A'){
		    	echo '<h3>Allergens Edit</h3>';
		    }else{
		    	echo '<h3>Intolernace Edit</h3>';
		    }
		}
		


        echo '<form action="#" method="post">';
            echo '<input type="hidden" name="ref" value="'.$row['ref'].'" /><br/>';
            echo '<div class="col s12 m6">';
	            echo '<label>title</label><br/>';
	            echo '<input type="input" name="title" value="'.$row['title'].'" /><br/>';
            echo '</div>';
            
            echo '<div class="col s12 m6">';
	            echo '<label>Display</label><br/>';
	            echo '<input type="input" name="display" value="'.$row['display'].'" /><br/>';
            echo '</div>';

            
            
            
            
            echo '<label>Ingredients</label><br/>';
            echo '<textarea style="min-height:200px;" name="breakdown">'.$row['breakdown'].'</textarea><br/>';
            

    		echo '<button type="submit" class="btn">Update</button>';
    		echo '<a class="btn" href="allergens.php">Cancel</a>';
    		echo '<br/>'.$ret;
        echo '</form>';

        
        

    		echo '</div>';
		echo '</div>';
	echo '</div>';
?>

<?php
    include '_footer.php';
?>