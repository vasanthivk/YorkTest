<?php


$client = new SoapClient("https://api.brandbank.com/svc/feed/extractdata.asmx?WSDL");
echo 'Functions<br/>';
$funcs=$client->__getFunctions();
foreach($funcs as $key=>$val){
    echo '<b>'.$key.'</b> '.$val.'<br/>';
}

var_dump($client->__getFunctions()); 
echo '<br/>Types<br/>';
var_dump($client->__getTypes());

//echo $client->GetUnsentProductData();


?>