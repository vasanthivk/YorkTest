<?php
    include '_top.php'; 
    

	echo '<div class="row">';
		echo '<div class="container">';
			echo '<div class="col s12 m8 offset-m2">';
			    $ret='';
			    if(count(clean::post())>1){
			        foreach(clean::post() as $key=>$val){
						$fields[$key]=$val;
			        }
			        if(clean::post('ref')!='new' && clean::post('ref')!=''){
			    		dbpdo::dbUpdate('person',clean::post('ref'),$fields);
			    	}else{
			    		dbpdo::dbInsert('person',$fields);	
			    		secure::redirect('adminusers.php');
			    	}
			        $ret= 'Updated';
			    }    
?>
	

<?php

	$ga = new googleauthenticator();

	$newSecret=$ga->createSecret();
   
	    $sql='select person.*
	    		from person 
	    		where ref=:ref;';
	    $parms=array(':ref'=>clean::get('ref'));
        
		if($row=dbpdo::getQuery($sql,$parms)){
		
		    	
		}else{
			$row=array();
			$row['ref']='new';
			$row['secret']='';
			$row['adminroles']='user,admin';
		}
		
		echo '<h3>Admin user Edit</h3>';
		
		if($row['secret']==''){
			$row['secret']=$newSecret;
		}
		


        echo '<form action="#" method="post">';
            echo '<input type="hidden" name="ref" value="'.$row['ref'].'" /><br/>';
            echo '<div class="col s12 m4">';
	            echo '<label>Firstnames</label><br/>';
	            echo '<input type="input" name="firstnames" value="'.h::sa($row,'firstnames').'" /><br/>';
            echo '</div>';
            
            echo '<div class="col s12 m4">';
	            echo '<label>Surname</label><br/>';
	            echo '<input type="input" name="surname" value="'.h::sa($row,'surname').'" /><br/>';
            echo '</div>';
            
            echo '<div class="col s12 m4">';
	            echo '<label>Email</label><br/>';
	            echo '<input type="input" id="email" name="email" value="'.h::sa($row,'email').'" /><br/>';
            echo '</div>';
            
 			echo '<div class="col s12 m4">';
	            echo '<label>Admin Roles</label><br/>';
	            echo '<input type="input" id="email" name="adminroles" value="'.h::sa($row,'adminroles').'" /><br/>';
            echo '</div>';

            
echo '<div class="col s12 m6">';
	            echo '<label>SECRET</label><br/>';
	            echo '<input type="input" id="secret" name="secret" value="'.h::sa($row,'secret').'" /><br/>';
            echo '</div>';

            
            
            
            
			echo '<div class="col s12">';
    		echo '<button type="submit" class="btn">Update</button>';
    		echo '<button class="btn act-new-secret" type="submit" class="btn">New Secret</button>';
    		echo '<a class="btn" href="adminusers.php">Cancel</a>';
    		echo '<br/>'.$ret;
    		echo '</div>';
        echo '</form>';
        echo '<div class="col s12" style="margin-top:20px;">';
        	echo '<div id="qrcode"></div>';
        echo '</div>';
        
        
        

        
        

    		echo '</div>';
    		
		echo '</div>';
	echo '</div>';
?>

<?php
    include '_footer.php';
    
    
    function build2fa($secret,$email){
    	$ret='otpauth://totp/AdvisrTech:'.$email.'?secret='.$secret.'&issuer=AdvisrTech';
    	return $ret;
    }
?>


<script>

	$('body').on('click','.act-new-secret',function(){
		$('#secret').val('');
		
	});
	
	secret=$('#secret').val();
	email=$('#email').val();
	if(email!=''){
otp='otpauth://totp/AdvisrTech:'+email+'?secret='+secret+'&issuer=AdvisrTech';



	new QRCode(document.getElementById("qrcode"), otp);		
	}
	
	
</script>