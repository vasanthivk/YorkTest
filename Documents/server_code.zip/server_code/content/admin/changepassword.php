<?php 
	debug::logErrors();
	$msg='';
	$ret='';
    if(clean::post('chngexistingpassword')!==''){
        $email=$_SESSION[settings::getSettings('login','user')]['email'];
        $password=clean::post('chngexistingpassword');
        $newpass=clean::post('chngpassword');
        $checkpass=clean::post('chngrepeatpassword');
        $ret=loginsimple::changePassword($email,$password,$newpass,$checkpass);
    }
	
	include '_top.php';


?>

	
<div class='row'>			
	<div class='m4 offset-m4 s12 col center-align login'>
		<h4>Change Password</h4>
				<form action='#' method='post' >
				    <?php echo form::showHash();?>
					<div class="input-field col s12">
						<input value="" class="chngexistingpassword" name="chngexistingpassword" type="password" placeholder="Current Password">
					</div>
					<div class="input-field col s12">
						<input value="" class="chngpassword" name="chngpassword" type="password" placeholder="Password - Min 8 Chars (Capital, lowercase &amp; numeric)">
					</div>
					<div class="input-field col s12">
						<input value="" class="chngrepeatpassword" name="chngrepeatpassword" type="password" placeholder="Re-enter Password">
					</div>
					<?php echo csrf::hiddenCSRF();?>
					<button class='btn' type='submit'>Change Password</button>
					<a href="../admin/index.php">Cancel</a>
					<?php 
                    if($ret!=''){
					    echo '<div class="col s12 red-warning">'.$ret.'</div>';	
				    }


					?>
				</form>
	</div>
</div><!--row-->



		
<?php 
	include '_footer.php';
?>
		
		
