<div class="row">
<?php
	$sql='select * from _products_import2 where barcode_number=:barcode limit 1';
	$parms=array(':barcode'=>clean::get('barcode'));
	if($data=dbpdo::getQuery($sql,$parms)){
		//print_r($data);
		
		echo '<div class="col s12 m6">';
			echo '<h5>'.$data['product_title'].'</h5>';
		echo '<p>';
			echo $data['category'].'/';
			echo $data['subcategory'].'/';
			echo $data['subsubcategory'];
		echo '</p>';
		
		echo '<h5>Contains</h5>';
		echo $data['allergy_contains'];
		
		echo '<h5>May Contain</h5>';
		echo $data['allergy_may'];
		
		echo '<h5>Nutrition</h5>';
		
		echo '<div class="col s8">Calories</div>';
		echo '<div class="col s4">'.$data['nutrition_numeric_energykcal'].'</div>';

		echo '<div class="col s8">Fat</div>';
		echo '<div class="col s4">'.$data['nutrition_numeric_fat'].'</div>';
		echo '<div class="col s8">Saturated Fat</div>';
		echo '<div class="col s4">'.$data['nutrition_numeric_satfat'].'</div>';
		echo '<div class="col s8">Protein</div>';
		echo '<div class="col s4">'.$data['nutrition_numeric_protein'].'</div>';
		echo '<div class="col s8">Fibre</div>';
		echo '<div class="col s4">'.$data['nutrition_numeric_fibre'].'</div>';
		echo '<div class="col s8">Sugar</div>';
		echo '<div class="col s4">'.$data['nutrition_numeric_sugar'].'</div>';
		echo '<div class="col s8">Sodium</div>';
		echo '<div class="col s4">'.$data['nutrition_numeric_sodium'].'</div>';
		echo '<div class="col s8">Cholesterol</div>';
		echo '<div class="col s4">'.$data['nutrition_numeric_cholesterol'].'</div>';

		echo '<div class="col s8">Carbs</div>';
		echo '<div class="col s4">'.$data['nutrition_numeric_carbohydrate'].'</div>';

		echo '<div class="col s8">Full Pack Calories</div>';
		echo '<div class="col s4">'.$data['nutrition_numeric_energykjoules'].'</div>';





		


		
		echo '</div>';
		echo '<div class="col s12 m6">';
			echo '<div class="barcode">'.$data['barcode_number'].'</div>';
		$hash=md5($data['barcode_number'].'.xfa8flP4K03LsT3jeya3O38FCMaE3p');
		
		
		echo '<img class="responsive-img dash-pop-img" src="https://images.foodadvisr.com/'.$hash.'.jpg" alt=""/>';
		echo '<div class="barcode-text">'.$data['barcode_number'].'</div>';

		
		echo '</div>';
		
		echo '<div class="col s12">';
			echo '<h5>Description</h5>';
			echo $data['regulated_product_name'];
		echo '</div>';
		
		echo '<div class="col s12">';
			echo '<h5>Ingredients</h5>';
			echo $data['ingredients'];
		echo '</div>';
	//	print_r($data);
	}else{
		echo '<div class="barcode">'.clean::get('barcode').'</div>';
		echo '<div class="barcode-text">'.clean::get('barcode').'</div>';
	}
?>

</div>