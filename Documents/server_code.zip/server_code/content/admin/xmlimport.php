<?php
    include '_top.php'; 
    
	echo '<div class="row">';
		echo '<div class="container">';
        
?>
	<h3>XML Import test</h3>
	
	
	<?php

	$xml = simplexml_load_file('../xml1/small.xml');	
	

echo $xml->Product->Identity->ProductCodes->Code;


RecurseXML($xml); 

function RecurseXML($xml,$parent="") 
{ 
   $child_count = 0; 
   foreach($xml as $key=>$value) 
   { 
      $child_count++;     
      if(RecurseXML($value,$parent.".".$key) == 0)  // no childern, aka "leaf node" 
      { 
         print($parent . "." . (string)$key . " = " . (string)$value . "<BR>\n");        
      }     
   } 
   return $child_count; 
} 


	//recx($xml);
	
	
	function recx($x,$level=''){
		foreach($x as $key=>$val){
			echo '<br/>'.$level.'.'.$key.' '.gettype($val).'<br/>';
			print_r($val);
			recx($val,$level.'.');
		}
	}
	
	
	
	

	
	
	
	
	?>


<?php
    include '_footer.php';
?>