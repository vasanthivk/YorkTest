<?php
    include '_top.php'; 

    $table='preferences';
    if(clean::get('type')=='sub'){
        $table='preferences_sub';
    }
    
	echo '<div class="row">';
		echo '<div class="container">';
			echo '<div class="col s12 m6">';
			    $ret='';
			    if(count(clean::post())>1){
			        $fields['name']=clean::post('name');
			        $fields['maxval']=clean::post('maxval');
			        $fields['hint']=clean::post('hint');
                    dbpdo::dbUpdate($table,clean::get('ref'),$fields);
			        $ret= 'Updated';
			    }    
?>
	<h3>Settings Edit</h3>

<?php
        
        $sql='select name ,  ref, maxval, hint
	    		from '.$table.' where ref=:ref';
	    
	    $parms=array(':ref'=>clean::get('ref'));
        
		if($stmt=dbpdo::query($sql,$parms)){
		    $row = $stmt->fetch();
		    fform::load($row);
		}


        echo '<form action="#" method="post">';
    		echo '<div class="col s12 m12 relative">';
        	    echo fform::field('name',12);
    	    echo '</div>';
    		echo '<div class="col s12 m12 relative">';
        	    echo fform::field('maxval',12);
    	    echo '</div>';
    		echo '<div class="col s12 m12 relative">';
        	    echo fform::field('hint',12);
    	    echo '</div>';
    		echo '<div class="col s12 m12 relative">';
        		echo '<button type="submit" class="btn">Update</button>';
    	    echo '</div>';
    		echo '<br/>'.$ret;
        echo '</form>';
           // echo profile::listUsersTable();
        
       
        

    		echo '</div>';
		echo '</div>';
	echo '</div>';
	//echo debug::show();
?>

<?php
    include '_footer.php';
?>