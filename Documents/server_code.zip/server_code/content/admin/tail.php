<?php
    loginsimple::permission('code');
    include '../admin/_top.php';
?>

 	<div class="row section greybg logtail">
         <div class="row act-filter">
            <a href="#all">All</a> | 
            <a href="#info">INFO</a> | 
            <a href="#error">ERROR</a> | 
            <a href="#security">SECURITY</a> |
            <a href="#mailgun">MAILGUN</a>
        </div>
        <div class='row'><div class="logtail-progress"></div><div class="logtail-refresh"></div></div>

     	<div class="targ-logtail">
     	<?php
     	    include '../admin/_tail.php';
     	?>
     	</div>
	</div>




<?php
    include '../admin/_footer.php';
    
    
?>
<script>

    var search='all';
    
    var progress=0;
    var xrefresh=0;
    
    filter(search);

    $('.act-filter a').on('click',function(){
        h=$(this).attr('href');
        h=h.substr(1);
        search=h;
        filter(h);
        return false;
    });
    
    $('body').on('dblclick','.ll',function(){
    	$(this).toggleClass('big');
    	
    });


    //setInterval(function(){refresh();},10000);
    setInterval(function(){
    	progress+=0.3;
    	if(progress>100){
    		progress=100;
    	}
    	pp=progress+'%';
    	$('.logtail-progress').css({width:pp});
    	
     	xrefresh+=1;
    	if(xrefresh>100){
    		xrefresh=0;
    		refresh();
    	}
    	pp=xrefresh+'%';
    	$('.logtail-refresh').css({width:pp});
    	
   	
 
    },500);


    function refresh(){
        llt=$('.last-log-time').text();
        $.post('../admin/_tail.php?l='+llt,function(data){
            if(data!=''){
            	progress=0;
                $('.targ-logtail').html(data);
                filter(search);
            }    
        });
        //$('.logtail').load('../admin/_tail.php?l='+llt);      
    }
    
    function filter(h){
        if(h!='all'){
            $('.ll').stop().hide();
            $('.'+h).stop().show();   
        }else{
            $('.ll').stop().show();   
        }
        $('.ll').each(function(){
        	t=$(this).find('span');
        	hh=t.height();
        	if(hh>15){
        		t.addClass('issquashed');
        	}
        });
        
    }

</script>

