<?php

	echo users::usersearch(clean::post('search'));

?>