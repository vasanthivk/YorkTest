<?php


//These calls are based on the documents here
//https://api.brandbank.com/svc/feed/extractdata.asmx


$client = new SoapClient("https://api.brandbank.com/svc/feed/extractdata.asmx?WSDL",array("soap_version" => SOAP_1_1,'trace' => TRUE));

$client->namespaces = array(
        'xmlns:soap'=>"http://www.w3.org/2003/05/soap-envelope",
        'xmlns:ns'=>"http://www.i-label.net/Partners/WebServices/DataFeed/2005/11"
);



$ns='http://www.i-label.net/Partners/WebServices/DataFeed/2005/11';
$GUID=settings::getSettings('brandbank','dev_guid');

$headerbody = array('ExternalCallerId' => $GUID); 
$header = new SOAPHeader($ns, 'ExternalCallerHeader', $headerbody);        
$client->__setSoapHeaders($header); 





try {
        $response=$client->GetUnsentProductData();
        
        //Data returned here.. we need to pick up the id from the start of the xml to use in the acknowledgeMessage
        print_r($response->GetUnsentProductDataResult->any);//xml outpu here !!
        
        
        echo "Request :<br>", htmlentities($client->__getLastRequest()), "<br>";
    }
    catch (SoapFault $soapFault) {
        soap::showErrors($soapFault,$client);
    }
    
    
//Once we have imported the data we need to call this soap function with the id in the wrapper xwml to confirmt hat we have all the products
//This will then reset the downloads list so that we dont get the same product again
//Not sure how we pass the id into this.



try {
        //$response=$client->AcknowledgeMessage();
        //print_r($response);
        echo "Request :<br>", htmlentities($client->__getLastRequest()), "<br>";
    }
    catch (SoapFault $soapFault) {
        soap::showErrors($soapFault,$client);
    }















?>