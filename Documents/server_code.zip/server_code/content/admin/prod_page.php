<?php
    include '_top.php'; 
?>
<style>
body,html{
    font-size:0.8rem;
}
img{
    width:100px;
}

.half{
    float:left;
    width:49%;
    overflow:hidden;
    min-height:120px;
}

h5{
    font-size:1.0rem;
}
</style>
<?php $mode="Yoghurt";?>

    
    <div class="row">
        <h4 style="color:#0099C5;">QUICR <smal style="color:#606060;"><?php echo $mode;?></small></h4>
    </dsiv>
    
    <div class="row">

            <?php
                
                echo products::printCategory($mode);
            
            ?>

        
        
        



    </div>

<?php
    include '_footer.php';
?>

<script>

var settings = {
          output:"bmp",
          barWidth: 2,
          barHeight: 50
        };

    $('.barcode').each(function(){
        t=$(this);
        xx=t.html();
        t.html('<b>'+xx+'</b>');
        t.barcode(t.text(),"ean13",settings);

    });


</script>


