<?php
    include '_top.php'; 
    
	echo '<div class="row">';
		echo '<div class="container">';
        
?>
	<h3>Settings List</h3>

<?php
   
            echo profile::listSettings();
            echo profile::listSubSettings();
        
        
        

		echo '</div>';
	echo '</div>';

?>

<?php
    include '_footer.php';
?>