<?php
	$mode=clean::get('mode');
	switch($mode){
		case 'scanstoday':
			echo dash::barcodesToday('-1 days');
			break;
		case 'scanshour':
			echo dash::barcodesToday('-1 hour');
			break;
		case 'scans':
			echo dash::barcodesToday('-10 years');
			break;
		case 'topusers':
			echo dash::scansByUser('-10 years');
			break;
		case 'latestsignups':
			echo dash::lastestSignUps('-10 years');
			break;

		case 'mostscanned':
			echo dash::barcodesTotals();
			break;
		case 'mostscannedtoday':
			echo dash::barcodesTotals(true);
			break;
		case 'productCount':
			echo dash::productCount();
			break;
		case 'usercount':
			echo dash::users();
			break;
		case 'newusercount':
			echo dash::users(true);
			break;
		case 'last10':
			echo dash::lastScans();
			break;
		case 'perhour':
			echo dash::scansByHour();
			break;







	}
	
	
	




?>