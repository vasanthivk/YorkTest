


<form method="post">
<textarea name="dd" style="width:50%;height:300px;"><?php echo clean::post('dd');?></textarea>
<button type="submit">Update</button>
</form>


<?php


    $input = trim(clean::post('dd'));
    file_put_contents('temp.txt',$input);
    $dd=file('temp.txt');
    foreach($dd as $d){
    	echo trim($d).',';
    }
    
//$numbers = preg_split('/\s+/', $input);
//echo implode(',', $numbers);



?>