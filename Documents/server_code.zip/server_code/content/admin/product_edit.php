<?php
    include '_top.php'; 
	echo '<div class="row">';
		echo '<div class="container">';
			echo '<div class="col s12 m8">';
			    $ret='';
			    if(count(clean::post())>1){
			        $setting_vals='';
                    foreach(clean::post() as $k => $v){
                        $setting_vals.=$k.','.$v.'|';
                    }
			        $fields['setting_vals']=substr($setting_vals,0,-1);
                    dbpdo::dbUpdate('products',clean::get('ref'),$fields);
			        $ret= 'Updated';
			    }    
?>
	<h3>Products Edit</h3>

<?php
echo 'ddd';
print_r(clean::post());
echo 'ddd';
        
        $sql='select *
	    		from products where ref=:ref';
	    
	    $parms=array(':ref'=>clean::get('ref'));
        
		if($stmt=dbpdo::query($sql,$parms)){
		    $row = $stmt->fetch();
		    $product=$row;
		}
		echo '<br/><br/><b>Title</b><br/>';
	    echo $row['title'];
	    echo '<br/><br/><b>Description</b><br/>';
	    echo $row['description'];
	    $groups=array('Burgers','Butter','Cereal','Coffee','Couscous','Pudding','Ready Meal','Salads','Sandwiches','Sauces','Soups','Teabag','Yoghurt');
	    echo '<div class="input-field col s12">';
            echo '<select class="cat-change" data-ref="'.$row['ref'].'">';
                echo '<option value="" disabled selected>Choose your option</option>';
                foreach($groups as $k){
                    $sel='';
                    if($row['category']==$k){$sel=' selected ';}
                    echo '<option '.$sel.' value="'.$k.'">'.$k.'</option>';
                }
                echo '</select>';
                echo '<label>Grouping</label>';
        echo '</div>';
        echo '<div class="catupd"></div>';
	    echo '<br/><br/><b>Nutrition</b><br/>';
	    echo $row['nutrition'];
	    echo '<br/><br/>';
        echo '<a target="_blank" href="http://www.waitrose.com/shop/DisplayProductFlyout?productId='.$row['productref'].'">Waitrose Site</a>';
	    echo '<br/><br/>';
	    echo $row['setting_vals'];
		$arr=explode('|',$row['setting_vals']);
		foreach($arr as $k=>$v){
		    $subarr=explode(',',$v);
		        $setarr[$subarr[0]]=h::safeArray($subarr,1);
		}
	//	print_r($setarr);
	    $sql='select concat(preferences.name, " / ",preferences_sub.name) as name , preferences_sub.ref,
	            preferences_sub.maxval,preferences_sub.category,preferences_sub.subcategory
	    		from preferences_sub
	    		inner join preferences on (preferences_sub.category=preferences.category)
	    		order by preferences_sub.category asc, preferences_sub.subcategory asc;';
	    
	    $parms=array();
	    
        $simple=array();
        echo '<form action="#" method="post">';
    		if($stmt=dbpdo::query($sql,$parms)){
    		    while($row = $stmt->fetch()){
            		echo '<div class="col s12 m6 relative">';
                	    echo $row['name'];
                	    $val=h::safeArray($setarr,$row['category'].':'.$row['subcategory']);
            	    echo '</div>';
            		echo '<div class="col s12 m6 relative">';
                	    echo '<input name="'.$row['category'].':'.$row['subcategory'].'" value="'.$val.'" />';
            	    echo '</div>';
            	    $simple[$row['category'].':'.$row['subcategory']]=$row['name'];
    		    }
    		}
    		//print_r($simple);
    		echo '<div class="col s12 m12 relative">';
        		echo '<button type="submit" class="btn">Update</button>';
    	    echo '</div>';
    		echo '<br/>'.$ret;
        echo '</form>';
           // echo profile::listUsersTable();

       
        

    		echo '</div>';
    		echo '<div class="col s12 m4">';
    		    echo '<br/><br/>';
    		    echo '<div class="barcode">'.$product['barcode'].'</div>';
    		    echo '<div>'.$product['barcode'].'</div>';
    		    echo '<br/>';
    		    echo '<img class="responsive-img" src="../productfiles/'.$product['productref'].'.jpg" />';
    		echo '</div>';
		echo '</div>';
	echo '</div>';
	//echo debug::show();
?>

<?php
    include '_footer.php';
    //echo debug::show();
?>

<script>
var settings = {
          output:"bmp",
          barWidth: 3,
          barHeight: 100
        };

    $('.barcode').each(function(){
        t=$(this);
        xx=t.html();
        t.html('<b>'+xx+'</b>');
        t.barcode(t.text(),"ean13",settings);

    });

    $( ".cat-change" ).change(function() {
     /// alert($(this).data('ref'));
//      alert($( ".cat-change option:selected" ).text());
        obb={};
        obb['formhash']=$('#formhash').val();
        obb['ref']=$(this).data('ref');
        obb['category']=$( ".cat-change option:selected" ).text();
		$('.catupd').load('../admin/_updatecat.php',obb);

    });



</script>