<?php
    $fields=array('name'=>clean::post('name'),'exclude'=>clean::post('exclude'));
    dbpdo::dbUpdate('settings',clean::post('ref'),$fields);
    echo '<h2>Edit</h2>';
    echo 'Record Updated';  
?>