<?php
    include '_top.php'; 
    
	echo '<div class="row">';
		echo '<div class="container">';
			echo '<div class="col s12 m8 offset-m2">';
?>
	<h3>Skins</h3>
	
	<?php
	
	
		$sql='select * from skins order by title desc';
		if($stmt=dbpdo::query($sql)){
		    while($row = $stmt->fetch()){
		    	ar::map($row);
		    	echo '<a href="skin_edit.php?ref='.$row['ref'].'" class="col s12 m3">';
		    		echo '<h5>'.$row['title'].'</h5>';
		    		echo $row['color1'].'<div class="colorblock" style="background:#'.$row['color1'].';"></div><br/>';
		    		echo $row['color2'].'<div class="colorblock" style="background:#'.$row['color2'].';"></div><br/>';
		    		echo $row['logo'].'<br/>';
		    		echo '<img class="responsive-img" src="https://api.foodadvisr.com/logos/'.$row['logo'].'" alt=""/>';
		    		        //echo '<div class="qrcode">cmd:'.ar::get('title').'|'.ar::get('color1').'|'.ar::get('color2').'|'.ar::get('logo').'</div>';

		    	echo '</a>';
		    }
		}

	
	?>


   




        

		</div>
	</div>
</div>

<?php
    include '_footer.php';
?>
<script>
	$('.qrcode').each(function(){
		var t=$(this);
		alert(t.text());
		var qr=new QRCode(t, t.text());
	});

</script>