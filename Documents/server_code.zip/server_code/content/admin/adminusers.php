<?php
    include '_top.php'; 
    
	echo '<div class="row">';
		echo '<div class="container">';
  			echo '<div class="col s12 m6 offset-m1">';
         
?>
	

<?php
   			echo '<h3>Admin Users</h3>';
            echo admin::listUsers();
            
            echo '<a href="edit_adminuser.php?ref=new" class="btn">Add User</a>';

        

			echo '</div>';
		echo '</div>';
	echo '</div>';

?>

<?php
    include '_footer.php';
?>