<?php
    include '_top.php';
    
    echo '<h1>Product Ref '.clean::post('productref').'</h1>';
    $data=file_get_contents('http://www.waitrose.com/shop/DisplayProductFlyout?productId='.clean::post('productref'));
    import::setdata($data);
    file_put_contents('../productfiles/'.clean::post('productref'),$data);
    
    import::getInfo();
    echo '<img src="../productfiles/'.clean::post('productref').'.jpg" />';


    import::showExtracted();
    
    import::dbInsert();
?>

<?php
    include '_footer.php';    
    
?>