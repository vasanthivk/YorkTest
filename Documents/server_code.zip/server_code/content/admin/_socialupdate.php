<?php
	$fields=array('status'=>clean::post('action'));
	dbpdo::dbUpdate('sharing',clean::post('ref'),$fields);
	echo clean::post('action');
?>