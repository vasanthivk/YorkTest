<?php
    include '_top.php'; 
?>

	<style>
		body{background:#606060;}
	</style>

		
	
    
	<div class="row">

			
			
			<?php
				echo dash::drawCell('LAST SCAN','lastscan','',6,'scaninfo');
				echo dash::drawCell('SCANS PER HOUR','perhour','',6,'scan',dash::pipTrack());
				
				echo dash::drawCell('SCANS TOTAL','scans','',2,'scan');
				echo dash::drawCell('SCANS TODAY','scanstoday','',2,'scan');
				echo dash::drawCell('SCANS LAST HOUR','scanshour','',2,'scan');
				
				echo dash::drawCell('PRODUCTS','productCount','',2);
				echo dash::drawCell('USERS','usercount','',2,'timer');
				echo dash::drawCell('NEW USERS TODAY','newusercount','',2,'timer');
				
				echo dash::drawCell('LAST 10 SCANS','last10','dash-double',4,'scan');
				echo dash::drawCell('NEW USERS','latestsignups','dash-double',4,'timer');


				echo dash::drawCell('TOP USERS','topusers','dash-double',4,'scan');
				echo dash::drawCell('MOST SCANNED','mostscanned','dash-double',4,'scan');
				echo dash::drawCell('MOST SCANNED TODAY','mostscannedtoday','dash-double',4,'scan');
				
				
				
				
				
				
		





        ?>
        
            
	</div>


<?php
    include '_footer.php';
   // echo debug::show();
?>
    <script>
    
    
    
    $(function() {
    	$('.dash-item-targ').each(function(){
    		t=$(this);
    		var mode=t.data('mode');
    		t.load('_dashitems.php?mode='+mode,function(){
    		});
    	});
    	setInterval(function(){refresh('timer');},30000);
	});


    Pusher.logToConsole = false;
    
    var preset={};
    preset['30']='Test1';
    preset['31']='xxcvvb';
    

    var pusher = new Pusher('934d3572d544c91c47f8', {
      cluster: 'eu',
      encrypted: true
    });

    var channel = pusher.subscribe('livechanges');
    channel.bind('events', function(data) {
        dlist=data.split('|');
        console.log(dlist);
        div='<div class="small-prod-right">'+dlist[0]+'<br/>'+dlist[1]+'<br/>'+dlist[2]+'</div>';
      $('.targ-new-scans').prepend('<div class="small-prod">'+div+'</div>');
      var tt=$('.dash-refresh-scaninfo').find('.dash-item-targ');
      tt.html('<span class="act-barcode-drill" data-barcode="'+dlist[0]+'">'+dlist[1]+'</span> '+dlist[2]+'<div class="barcode">'+dlist[0]+'</div><div class="barcode-text"></div>');
      showBarcode();
      if(dlist[1]==''){
      	
      	dclass='dash-pip-alert';	
      }else{
      	dclass='';
      }
      $('.dash-pip-track').prepend('<div class="dash-pip dash-pip-start '+dclass+'"></div>');
      setTimeout(function(){$('.dash-pip-start').removeClass('dash-pip-start')},5);
      
      $('.barcode-text').text(dlist[0]);
      refresh('scan');
    });
    
    
    function refresh(refreshCode){
    	$('.dash-refresh-'+refreshCode).each(function(){
     		var p=$(this);
     		var t=p.find('.dash-item-targ');
     		t.stop().fadeTo('fast',0.5);
    		var mode=t.data('mode');
    		t.load('_dashitems.php?mode='+mode,function(){
    			$(this).stop().fadeTo('fast',1);
    		});
   		
    	});
    }
    
    setInterval(function(){
    	$('.dash-pip').each(function(){
    		var t=$(this);
    		var tp=t.position();
    		if(tp.left<=1){
    			t.remove();
    		}
    	});
    },1000);
    


    
    
    
    
    </script>
