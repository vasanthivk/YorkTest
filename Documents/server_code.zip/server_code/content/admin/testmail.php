<?php


	$subject='this is a password reset test';
	$html='some reset info<br/>inHere';
	$to='andy@clevertech.tv';
	$toName='Andy Derrick';


	ses::send($subject,$html,$to,$toName);



?>