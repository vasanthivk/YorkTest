<?php
    include '_top.php'; 
    
	echo '<div class="row">';
	
			echo '<div class="col s12 m8 offset-m2">';
				echo '<input placeholder="Enter search word here" style="text-align:center;" type="text" id="search" />';
			echo '</div>';
			?>
				<div class="col s12 center-align act-filters filters">
					<a href="#">Tesco</a> 
					<a href="#">Waitrose</a> 
					<a href="#">Sainsbury</a>
					<a href="#">Co-operative</a> 
					<a href="#">Morrisons</a> 
					
					<a href="#">Sharwood</a>
					<a href="#">Thai</a>
					<a href="#">Indian</a>
					<a href="#">Gluten</a>
					<a href="#">Vegetarians</a>
					
					
					<a href="#">Clear</a> 
				</div>
			
			
			<?
	
	
	
   			echo '<div class="col s12 m12">';
     
?>
    <div class="container">
	<h3>New Products List
	    <small><a href="#qrcode" class="act-toggle">Database Switch</a> 
	    <a href="#barcodes" class="act-toggle">Barcodes</a></small>
	</h3>
	
	<?php
	
	    //echo view2::viewData('_products');
	    $sql='select * from _products order by product_title desc limit 200';
	    $parms=array();
	    $top=true;
	    $zebra='';
	    $ret='';
	    if($stmt=dbpdo::query($sql,$parms)){
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			    $ret.='<div class="col s12 m3" style="min-height:200px;">';
			        if($row['product_title']!=''){
    			        $ret.='<h6>'.$row['product_title'].'</h6>';
    			        $ret.='<div style="margin-bottom:40px; !important" class="barcode col s12 m8 offset-m2  center-align">'.$row['barcode_number'].'</div>';
			            
			        }
			        //$ret.='<div class="col s12 m8 offset-m2  center-align">';
			        //$ret.='<img class="responsive-img" style="margin-left:auto;margin-right:auto;"  src="../productimages/'.$row['barcode_number'].'.jpg"/>';
			        //$ret.='</div>';
			        //$ret.=print_r($row,true);
			    $ret.='</div>';
			}
	    }
	    

	    echo $ret;

	
	?>
	</div>




        </div>
</div>

<?php





    function title($name){
        return str_replace('_',' ',$name);
    }

    include '_footer.php';
?>

<script>
  var settings = {
          output:"bmp",
          barWidth: 2,
          barHeight: 50
        };

    $('.barcode').each(function(){
        t=$(this);
        xx=t.html();
        var code='';
        t.html('<b>'+xx+'</b>');
        switch(xx.length){
        	case 13:
        		code="ean13";
        	
        		break;
        	case 8:
        		code="ean8"
        		break;
        	default:
        		alert(xx.length);
        		code="ean13";
        		break;
        }
        t.barcode(t.text(),code,settings);

    });
  
    


	var body=$('body');
	
	body.on('click','.act-filters a',function(){
		t=$(this);
		filter=t.text();
		if(filter=='Clear'){
			filter='';
		}
		$('#search').val(filter);
		runSearch();
		return false;
	});


    $('body').on('keydown','#search',function(e){
        if(e.keyCode==13){
            runSearch();
            return false;
        }
        
    });

	$('body').on('click','.act-search',function(){
		//alert($('#search').val());
		return false;
	});
	
	
	function runSearch(){
		search=$('#search').val();
		search=search.toLowerCase();
		$('tr').each(function(){
		    t=$(this);
		    row=t.text();
		    row=row.toLowerCase();
		    if(row.search(search)!=-1){
		        t.show();
		    }else{
		        t.hide();
		    }
		    
		});
	    
	}



</script>


