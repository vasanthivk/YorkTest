<?php
    include '_top.php'; 

?>

    <div class="container">
        <div class="row">
            <div class="col s12 m10 offset-m1">
            
            <?php
            
                $sql='select * from products where barcode=:bar limit 1';
                $parms=array(':bar'=>clean::get('bar'));
                $data=dbpdo::getQuery($sql,$parms);
                print_r($data);
            
            
            ?>
            
            </div>
        
        </div>
    </div>




<?php

    include '_footer.php';

?>