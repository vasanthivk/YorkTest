<?php
    $fields=array('category'=>clean::post('category'));
    dbpdo::dbUpdate('products',clean::post('ref'),$fields);
    echo 'Updated';
?>