<?php

	echo search::prodsearch(clean::post('search'));

?>