<?php
    include '_top.php'; 
    
	echo '<div class="row">';
		echo '<div class="container">';
   			echo '<div class="col s12 m10 offset-m1">';
     
?>
	<h3>Quicr Barcode List</h3>
	<form action="barcodes.php" method="post" class="noprint">
		<div class="col s12 m4">
		<label>Bar Code</label>
		<input type="text" name="barcode"/>
		</div>
		<div class="col s12 m8">

        </div>
        <div class="col s12">
			<input type="submit" class='btn' value="Search">
		</div>
	</form>
	
<?php
   
            echo barcode::listBarcodes();
        
        
        

    		echo '</div>';
		echo '</div>';
	echo '</div>';

?>

<?php
    include '_footer.php';
?>


<script>

var settings = {
          output:"bmp",
          barWidth: 2,
          barHeight: 55
        };

    $('.barcode').each(function(){
        t=$(this);
        xx=t.html();
        t.html('<b>'+xx+'</b>');
        t.barcode(t.text(),"ean13",settings);

    });

</script>