<?php
    include '_top.php'; 
    
	echo '<div class="row">';
		echo '<div class="container">';
		    echo '<div class="col s12">';
		        echo '<h2>Branding</h2>';
		        
		        echo 'Colour pallett, Logos, App icon, Watermark amd select font style - import settings from google fonts';
		        echo 'Build process - colours and title then others. choice of dummy or customer data for menus submit to tbuild status of submitted..we pick up .status of processing then mark as complete and show qrcode';
		        
		       echo '</div>'; 

		echo '</div>';
	echo '</div>';

?>

<?php
    include '_footer.php';
   // echo debug::show();
?>
