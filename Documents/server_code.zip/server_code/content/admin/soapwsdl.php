<?php



    $dd=file_get_contents('https://api.brandbank.com/svc/feed/extractdata.asmx?WSDL');
    echo '<code>';
    print_r($dd);
    echo '</code>';

?>