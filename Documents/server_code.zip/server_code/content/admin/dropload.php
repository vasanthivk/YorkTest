<?php

    print_r($_FILES);
    
    $barcode=h::sa($_SESSION,'product','barcode');
    $barcode=substr($barcode,0,14);
    echo $barcode;
    if($barcode!=''){
        $tmp_name = $_FILES["file"]["tmp_name"];
        move_uploaded_file($tmp_name, '../productimages/'.$barcode.'.jpg');
    }

?>