<?php

    $cc=clean::get('id');
    echo $cc;

    soap::AcknowledgeMessage('38808a82-a283-4185-a0d9-029b8c164b8e');













?>