
<ul id="data-settings" class="dropdown-content">
    <li><a href="../admin/settings.php?t=allergens">Allergens</a></li>
    <li><a href="../admin/settings.php?t=religion">Religion</a></li>
    <li><a href="../admin/settings.php?t=beliefs">Beliefs</a></li>
    <li><a href="../admin/settings.php?t=medical">Medical</a></li>
    <li><a href="../admin/settings.php?t=celebrity">Celebrity</a></li>
    <li><a href="../admin/settings.php?t=intolerances">Intolerances</a></li>

</ul>

<ul id="data-brandbank" class="dropdown-content">
    <li><a href="../admin/newproducts.php">Products</a></li>
    <li><a href="../admin/bbproducts.php">Barcodes</a></li>
    <li><a href="../admin/ingredients.php">Ingredients</a></li>

</ul>

<ul id="data-customers-new" class="dropdown-content">
    <li><a href="../admin/newproducts.php">Create customer</a></li>
    <li><a href="../admin/restaurant.php">Restaurant Name</a></li>
    <li><a href="../admin/bbproducts.php">Branding</a></li>
    <li><a href="../admin/ingredients.php">Menu</a></li>
    <li><a href="../admin/ingredients.php">Offers &amp; Promotions</a></li>

</ul>


<ul id="data-customers" class="dropdown-content">
	<?php
    $sql='select distinct customer from _productsx order by customer';
    $customers=array();
    
    if($stmt=dbpdo::query($sql)){
        while($row = $stmt->fetch()){
        	if($row['customer']!=''){
            	echo '<li><a href="../admin/newproducts.php?customer='.$row['customer'].'">'.$row['customer'].'</a></li>';
        	}
        }
    }
    
		
	?>
	<li class="divider"></li>
	<li><a href="">All</li>

</ul>




<ul id="user-drop" class="dropdown-content">
  <li><a href="#D<?php echo h::safeArray($_SESSION,'ref');?>" class="act-detail">My Details</a></li>
  <li><a href="../admin/changepassword.php">Change Password</a></li>
  <?php
    if(loginsimple::hasAdminRight('mysqldddddddd')){
        echo '<li><a href="../admin/view-history.php">History</a></li>';
        echo '<li class="divider"></li>';
        echo '<li><a href="../admin/build.php">MySql</a></li>';
        echo '<li><a href="../admin/adminusers.php">Admin Users</a></li>';
        echo '<li><a href="../admin/tail.php">Log Tail</a></li>';
        echo '<li><a href="../zzcopyproject/copytodemo.php">Deploy to Demo</a></li>';
    }
  ?>
  
  <li><a href="../adminlogin/login.php?mode=logoff">Log Off</a></li>
</ul>


<div class="navbar-fixed head-wrap">
<nav class="orange-bk targ1">
  <div class="nav-wrapper">
    <a href="#" class="brand-logo logo">
    	<img src="../img/thumb.svg" alt="" style="height:40px;margin-left:30px;margin-top:10px;"/>
    	
    </a>

    <ul class="right hide-on-med-and-down">
    
    
        <li>
            <a class="dropdown-button" href="#!" data-activates="data-customers" data-beloworigin="true">
            Customers
            <i class="material-icons right">arrow_drop_down</i>
            </a>
        </li>
        
       
           <li>
            <a class="dropdown-button" href="#!" data-activates="data-customers-new" data-beloworigin="true">
            New Customer
            <i class="material-icons right">arrow_drop_down</i>
            </a>
        </li>




    
    <li><a href="../admin/menudesign.php">Menu Designer</a></li>
    	<li><a href="../admin/index.php">Dashboard</a></li>
    	
    	<li><a href="../admin/heatmap.php">Heat Map</a></li>
    	
    	<li><a href="../admin/barcodes.php">Barcodes</a></li>
        <?php
        if(loginsimple::isLoggedIn()){
            echo '<li>';
            
            echo '<a class="dropdown-button" href="#!" data-activates="user-drop">';
            echo '<i class="material-icons left">perm_identity</i>';
            echo '<i class="material-icons right">arrow_drop_down</i>';
            echo loginsimple::getUser('fullname');
            echo '</a>';
            echo '</li>';
        }
        
        ?>

    </ul>
          <ul id="nav-mobile" class="side-nav">

      </ul>
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>

  </div>
</nav></div>
<div class="fixed-action-btn">
    <a href="../admin/addnewproduct.php" class="btn-floating btn-large red">
      <i class="large material-icons">mode_edit</i>
    </a>
  </div>
<div class="minidrop overlay-hide hideme"><div class="inner"></div></div>
<div class="bigpop"></div>
<div class="tooltipp"></div>
<div class="hover-pop"></div>
<?php //include '../datepick/datepick.html';?>



