<?php
    echo log::tail(50, clean::get('l'));

?>