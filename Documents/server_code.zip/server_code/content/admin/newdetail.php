<?php
    include '_top.php'; 
    
?>

<link href="../css/dropzone.css" type="text/css" rel="stylesheet"/>

<?php
    
	echo '<div class="row">';
		echo '<div class="subtools">';
			echo '<div class="container">';
				echo '<a href="#" class="act-save">Save</a>';
				echo '<a href="#" class="act-start-delete">Delete</a>';
			echo '</div>';
		echo '</div>';
		echo '<div class="container">';
		
		
   			echo '<div class="col s12 m12">';
   			
   			

?>

	<?php
	
		$_SESSION['product']['barcode']=clean::get('r');
	
	    $sql='select * from _productsx where barcode_number=:barcode';
	    $parms=array(':barcode'=>clean::get('r'));
	    echo '<br/><br/>';
	    
	    if(!$data=dbpdo::getQuery($sql,$parms)){
	        $data=array();
	    }
	    $customer=h::sa($data,'customer');
	        //print_r($data);
	        echo '<h5>'.h::sa($data,'product_title').'</h5>';
	        echo '<div class="col s12 m6">';
	        
	        
	        
	        
	        echo '<div class="barcode">'.h::sa($data,'barcode_number').'</div>';
	        	echo half('barcode_number',$data,12);
	        	echo half('customer',$data,12);
	        	
	        	echo hint('barcodes.txt');
	        	
	        	//echo half('product_code',$data,12);
	        
	        echo '</div>';
	        
	        $jwt=JWT::encode(h::sa($data,'barcode_number'),settings::getSettings('hash','key'));
	        
	        echo '<div class="dhash hide">'.$jwt.'</div>';
	        

	        
	        echo '<div class="col s12 m6 right-align product-image">';
	        	        $img=h::sa($data,'barcode_number');
	        $value='<img class="responsive-img" src="../productimages/'.$img.'.jpg" alt=""/>';
	        echo '<div id="dropzone1" class="dropzone" data-barcode="'.h::sa($data,'barcode_number').'">';
	        echo $value;
	        echo '</div>';

	        echo '</div>';
	        
	        
	        echo '<div class="col s12 m12">';
	        
	        echo '</div>';

	        
	        
	        
			if($customer=='brandbank'){
		        echo halfx('category',$data,4);
		        echo halfx('subcategory',$data,4);
		        echo halfx('subsubcategory',$data,4);
			}
			
		
			
			
			echo half('product_title',$data,12);
	        
	        
	        
	        //echo half('further_description',$data,12,'area');
	        
	        echo half('regulated_product_name',$data,12,'area');
	        
	        
	        
	        hint('ingredients.txt');
	        echo half('ingredients',$data,12,'html');
	        
	        //echo '<div class="col s12"><h5>Text Nutrition</h5></div>';
	        
	        //echo half('nutrition_textual_calories',$data,2);
	        //echo half('nutrition_textual_fat',$data,2);
	        //echo half('nutrition_textual_cholesterol',$data,2);
	        //echo half('nutrition_textual_sodium',$data,2);
	        //echo half('nutrition_textual_sugar',$data,2);
	        //echo half('nutrition_textual_fibre',$data,2);
	        
	        
	        echo '<div class="col s12"><h5>Numeric Nutrition</h5></div>';
	        
	        
	        
	        
	        //echo half('image_url',$data,12,$value);
	        
	        echo half('nutrition_numeric_calories',$data,2);
	        echo half('nutrition_numeric_fat',$data,2);
	        echo half('nutrition_numeric_satfat',$data,2);
	        echo half('nutrition_textual_carbohydrate',$data,2);
	        echo half('nutrition_numeric_sugar',$data,2);
	        echo half('nutrition_numeric_cholesterol',$data,2);
	        
	        
	        echo half('nutrition_numeric_fibre',$data,2);
	        echo half('nutrition_numeric_protein',$data,2);
	        echo half('nutrition_numeric_sodium',$data,2);
	        
	        
	        
	        echo half('company_name',$data,6);
	        echo half('lifestyle',$data,6);
	        hint('allergytext.txt');
	        echo half('allergy_text',$data,6);
	        
	        echo half('allergy_advice',$data,6);
	        
	        
	        
	        if($customer=='brandbank'){
	        	echo half('front_of_pack',$data,12);
	        }
	        

	        
	        

	        
	        
	    //}


	    

	
	?>




        </div>
    </div>
</div>



<?php


	function hint($file){
		$txt=file_get_contents('../admin/hints/'.$file);
		if($txt!=''){
			echo '<div class="hint">';
				echo $txt;
			echo '</div>';
		}
	}

    function dynamicDrop($field){
        $sql='select distinct '.$field.'  from _productsx';
		if($stmt=dbpdo::query($sql)){
			while($row = $stmt->fetch()){
			    print_r($row);
			    echo '<br/>';
			}
		}
        
    }

    function halfx($field,$data,$cols=6,$value=''){
        $ret='<div class="col s12 m'.$cols.' fwrap">';
            $ret.='<label for="'.$field.'">'.$field.'</label>';
            if($value==''){
                $ret.=h::sa($data,$field);
            }else{
                $ret.=$value;
            }
        $ret.='</div>';
        return $ret;
    }
    
    function half($field,$data,$cols=6,$type='text',$value=''){
    	$txtField=tidyField($field);
        $ret='<div class="col s12 m'.$cols.' fwrap">';
            $ret.='<label for="'.$field.'">'.$txtField.'</label>';
            if($value==''){
                
                $text=h::sa($data,$field);
            }else{
                $text=$value;
            }
            switch($type){
                case 'text':
                    $ret.='<input type="text" class="bbinput" id="'.$field.'" value="'.$text.'"/>';
                    break;
                case 'area':
                    $ret.= '<textarea id="'.$field.'" class="bbinput materialize-textarea">'.$text.'</textarea>';
                    break;
                case 'html':
                    $ret.= '<div class="bbinput editable" id="'.$field.'">'.$text.'</div>';
                    break;
            }
            
        $ret.='</div>';
        return $ret;
    }
    
    function tidyField($field){
    	$fields=array('regulated_product_name'=>'Product description');
    	if(h::sa($fields,$field)!=''){
    		return h::sa($fields,$field);
    	}else{
	    	$ret=str_replace('_',' ',$field);
	    	$ret=ucfirst($ret);
	    	return $ret;
    	}
    }
    
    
    echo '<div class="result"></div>';

    




    include '_footer.php';
    //echo debug::show();
?>
<script src="../js/dropzone.js"></script>
<script>

    $(function(){
        startTextEdit();
        //dz=$("#dropzone1").dropzone({ url: "../admin/dropload.php",headers: { "My-Awesome-Header": "header value" } });
        //dz.on('addedfile', function(file){alert(1);console.log(file)});
    });
    
    
    
 $(function() {
  // Now that the DOM is fully loaded, create the dropzone, and setup the
  // event listeners
  var myDropzone = new Dropzone("#dropzone1",{ url: "../admin/dropload.php",headers: { "My-Awesome-Header": "header value" } });
  myDropzone.on("success", function(file) {
  	dz=$('#dropzone1');
  	dz.html('<img class="responsive-img" src="../productimages/'+dz.data('barcode')+'.jpg?v='+Math.random()+'" alt=""/>');
  });
})   
    


    var body=$('body');
    
    var delTimer;
    
    
    
    body.on('click','.act-start-delete',function(){
    		if(delTimer){
    			cleartimeout(delTimer);
    		}
    	var delText='Really delete?';
    	t=$(this);
    	if(t.text()==delText){
    		Materialize.toast('Deleting product',2000);
    		jwt=$('.dhash').text();
    		$.post('../admin/delitem.php?jwt='+jwt,function(data){
    		    Materialize.toast('Deleted',2000);
    		    window.location.href = "../admin/newproducts.php";
    		})
    		
    	}else{
    		t.text(delText);
    		delTimer=setimeout(function(){$('.act-start-delete').text('Delete')},5000);
    		
    	}
    	return false;
    });
    
    body.on('click','.act-save',function(){
    	Materialize.toast('Saving Updates..',1000);
        obb={};
        $('.bbinput').each(function(){
            t=$(this);
            
            fname=t.attr('id');
            if(t.hasClass('editable')){
                obb[fname]=t.html();    
            }else{
                obb[fname]=t.val();   
            }
            
        });
    
        $.post('../admin/_savedetails.php',obb,function(){
        	Materialize.toast('Saved',2000);
        });
        return false;
    });







  var settings = {
          output:"bmp",
          barWidth: 2,
          barHeight: 50
        };

    $('.barcode').each(function(){
        t=$(this);
        xx=t.html();
        var code='';
        t.html('<b>'+xx+'</b>');
        switch(xx.length){
        	case 13:
        		code="ean13";
        	
        		break;
        	case 8:
        		code="ean8"
        		break;
        	default:
        		alert(xx.length);
        		code="ean13";
        		break;
        }
        t.barcode(t.text(),code,settings);

    });
    
function startTextEdit(){
        var editor = new MediumEditor('.editable', {
                buttonLabels: 'fontawesome',
                placeholder: {
        text: 'Type your text'
    },
    buttons: ['bold', 'italic', 'quote','anchor','orderedlist','unorderedlist','header1','header2'],
                paste: {
                cleanPastedHTML: true,
                forcePlainText: false,
                autoLink: true
            }
            }),
            cssLink = document.getElementById('medium-editor-theme');
	
}
  
    




</script>



