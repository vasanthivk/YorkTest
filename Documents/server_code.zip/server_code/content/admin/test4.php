


<form method="post">
<textarea name="dd" style="width:50%;height:300px;"><?php echo clean::post('dd');?></textarea>
<button type="submit">Update</button>
</form>


<?php


    $input = trim(clean::post('dd'));
$numbers = preg_split('/\s+/', $input);
echo implode(',', $numbers);



?>