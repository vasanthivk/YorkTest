<?php
    include '_top.php'; 
    
	echo '<div class="row">';
		echo '<div class="container">';
  			echo '<div class="col s12 m6 offset-m1">';
         
?>
	

<?php
   			echo '<h3>Allergens</h3>';
            echo allergens::listAllergens('A');
            echo '<h3>Intolernaces</h3>';
            echo allergens::listAllergens('I');
        
        
        

			echo '</div>';
		echo '</div>';
	echo '</div>';

?>

<?php
    include '_footer.php';
?>