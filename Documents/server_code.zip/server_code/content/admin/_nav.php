

<ul id="user-drop" class="dropdown-content">
  <li><a href="#D<?php echo h::safeArray($_SESSION,'ref');?>" class="act-detail">My Details</a></li>
  <li><a href="../admin/changepassword.php">Change Password</a></li>
  <?php
    if(loginsimple::hasAdminRight('mysqldddddddd')){
        echo '<li><a href="../admin/view-history.php">History</a></li>';
        echo '<li class="divider"></li>';
        echo '<li><a href="../admin/build.php">MySql</a></li>';
        echo '<li><a href="../admin/adminusers.php">Admin Users</a></li>';
        echo '<li><a href="../admin/tail.php">Log Tail</a></li>';
        echo '<li><a href="../zzcopyproject/copytodemo.php">Deploy to Demo</a></li>';
    }
  ?>
  
  <li><a href="../adminlogin/login.php?mode=logoff">Log Off</a></li>
</ul>


<div class="navbar-fixed head-wrap">
<nav class="orange-bk targ1">
  <div class="nav-wrapper">
    <a href="#" class="brand-logo logo">
    	<img src="../img/thumb.svg" alt="" style="height:40px;margin-left:30px;margin-top:10px;"/>
    	
    </a>

    <ul class="right hide-on-med-and-down">
    

    	<li><a href="../admin/index.php">Dashboard</a></li>
    	
    	<li><a href="../admin/search.php">Search</a></li>
    	
    	<li><a href="../admin/users.php">Users</a></li>
    	<li><a href="../admin/profiles.php">Profiles</a></li>
    	<li><a href="../admin/allergens.php">Allergens</a></li>
    	<li><a href="../admin/skin.php">Skins</a></li>
    	<li><a href="../admin/social.php">Social</a></li>
    	<li><a href="../admin/barcodes.php">Barcodes</a></li>
    	<li><a href="../admin/adminusers.php">Admin Users</a></li>
        <?php
        if(loginsimple::isLoggedIn()){
            echo '<li>';
            
            echo '<a class="dropdown-button" href="#!" data-activates="user-drop">';
            echo '<i class="material-icons left">perm_identity</i>';
            echo '<i class="material-icons right">arrow_drop_down</i>';
            echo loginsimple::getUser('fullname');
            echo '</a>';
            echo '</li>';
        }
        
        ?>

    </ul>
          <ul id="nav-mobile" class="side-nav">

      </ul>
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>

  </div>
</nav></div>
<div class="fixed-action-btn">
    <a href="../admin/addnewproduct.php" class="btn-floating btn-large red">
      <i class="large material-icons">mode_edit</i>
    </a>
  </div>
<div class="minidrop overlay-hide hideme"><div class="inner"></div></div>
<div class="bigpop"></div>
<div class="tooltipp"></div>
<div class="hover-pop"></div>
<?php //include '../datepick/datepick.html';?>



