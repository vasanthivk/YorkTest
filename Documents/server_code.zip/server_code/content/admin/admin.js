        var body=$('body');
    
    body.on('click','.act-barcode-drill',function(){
    	$('.act-overlay').removeClass('hide');
    	$('.dash-popup').html('Loading...').removeClass('hide').load('dash-item.php?barcode='+$(this).data('barcode'),function(){
    		showBarcode();
    	});
    	return false;
    });
    
    body.on('click','.act-overlay',function(){
    	$(this).addClass('hide');
    	$('.overlay-hide').addClass('hide');
    	return false;
    });
    
 var settings = {
          output:"bmp",
          barWidth: 2,
          barHeight: 50
        };

    
    
    function showBarcode(){

    $('.barcode').each(function(){
        t=$(this);
        xx=t.html();
        var code='';
        t.html('<b>'+xx+'</b>');
        switch(xx.length){
        	case 13:
        		code="ean13";
        	
        		break;
        	case 8:
        		code="ean8"
        		break;
        	default:
        		code="ean13";
        		break;
        }
        t.barcode(t.text(),code,settings);

    });    	
    }

