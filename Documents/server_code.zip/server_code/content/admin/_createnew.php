<?php

    //print_r(clean::post());

    $fields['barcode_number']=clean::post('barcode_number');
    $fields['customer']=clean::post('customer');
    
    
    

    dbpdo::dbInsert('_productsx',$fields,'',true,true);
    
    echo '<script>window.location="../admin/newdetail.php?r='.$fields['barcode_number'].'"</script>';
    
    
    
    //echo debug::show();
    
    



?>
