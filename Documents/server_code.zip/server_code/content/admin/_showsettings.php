<?php

    echo profile::settingsTable(clean::post('table'));
    echo '<a href="#" class="sett-edit" data-ref="New"  data-table="'.clean::post('table').'"  data-name="">New</a>';

?>