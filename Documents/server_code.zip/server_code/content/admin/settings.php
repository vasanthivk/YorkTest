<?php
    include '_top.php'; 
    
	echo '<div class="row">';
		echo '<div class="container">';
			echo '<div class="col s12 m6" style="overflow:hidden;">';
                echo '<h2>Settings - '.ucfirst(clean::get('t')).'</h2>';       
            	echo '<div class="settingslist">';
            		clean::setPost('table',clean::get('t'));
            		include '../admin/_showsettings.php';
	    		echo '</div>';
    		echo '</div>';
			echo '<div class="col s12 m6 edit-settings">';
                echo '<h2>Edit</h2>';       
            
    		echo '</div>';
		echo '</div>';
	echo '</div>';

?>

<?php
    include '_footer.php';
?>
<script>
    $('body').on('click','.sett-edit',function(){
		
		t=$(this);
        data={};
        data.ref=t.data('ref');
        data.table=t.data('table');
        data.name=t.data('name');
        data.exclude=t.data('exclude');
        $('.edit-settings').load('../admin/_editsettings.php',data);
        
        return false;
    });
	$('body').on('click','.act-save-data',function(){
        data={};
        data.ref=$(this).data('ref');
        data.table=$(this).data('table');
        data.name=$('#Name').text();
        data.exclude=$('#Exclude').text();
        $('.edit-settings').load('../admin/_savesettings.php',data,function(){
        	$('.settingslist').load('../admin/_showsettings.php',data);
        });
	    return false;
	});
	
	
	
</script>