<html>
	<head>
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<style>

	html{
		font-family: Tahoma, Geneva, sans-serif;
		font-size:1.0rem;
	}
	
	.qsr-menu{
		font-family: Tahoma, Geneva, sans-serif;
		font-size:1.0rem;
		
	}
	
	small{
		font-size:0.8rem;
		display:inline-block;
		margin-left:20px;
	}
	
	b{
		display:block;
		font-size:0.9rem;
		color:#606060;
		font-weight:normal;
		margin-bottom:10px;
	}
	
	h3,h4,h5,h6{
		margin:none !important;
		padding:none !important;
		font-family: 'Open Sans', sans-serif;
	}
	
	h3{
		font-size:1.4rem;
		color:red;
	}
	
	h6{
		font-size:0.9rem;
		color:#808080;
		
	}
	
</style>
		
	</head>
	<body>
<div class="qsr-menu">
<?php


    $sql='SELECT menu.menu,menu.submenu, menu.description, menu_products.sort_order,menu_products.product_no,menu_products.sub_product_no,_productsdl.*
    FROM menu_products
    inner join menu on (menu.ref=menu_products.menu_ref)
    inner join _productsdl on (menu_products.barcode_number=_productsdl.barcode_number)
    order by menu_products.sort_order asc';
    $first=true;
    $menu='';
    $submenu='';
    if($stmt=dbpdo::query($sql)){
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        	if($first){
            print_r($row);
            $first=false;
        	}
        	if($menu!=$row['menu']){
        		echo '<h3>'.$row['menu'].'</h3>';
        		echo '<h6>'.$row['description'].'</h6>';
        		$menu=$row['menu'];
        		
        	}
        	if($submenu!=$row['submenu']){
        		echo '<h5>'.$row['submenu'].'</h5>';
        		$submenu=$row['submenu'];
        		
        	}
        	
        	$dd=explode(':',$row['product_title']);
			if($row['sub_product_no']==0){
            	echo $row['product_no'].' '.$row['sub_product_no'].' '.$dd[0].' '.$row['nutrition_numeric_energykcal'].'kcal <br/>';
            	echo '<b>'.h::sa($dd,1).'</b>';
			}else{
				echo '<small>'.$row['product_no'].' '.$row['sub_product_no'].' '.$dd[0].' '.$row['nutrition_numeric_energykcal'].' kcal </small><br/>';	
			}
        }
    }





?>
</div>
</body>
</html>