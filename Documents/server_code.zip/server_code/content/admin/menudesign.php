<?php
    include '_top.php'; 
    
	echo '<div class="row">';
		echo '<div class="container">';
			echo '<div class="col s12">';
				echo '<a href="#" class="act-save-menu">Save Updates</a>';
			echo '<?div>';
		    echo '<ul class="col s12 m6  leftpick" id="sortleft">';
		    echo menu::products();
            echo '</ul>'; 
             echo '<ul class="col s12 m6 save-menu" id="" style="min-height:300px;border:1px solid grey;">';
             echo menu::show();
             echo '</ul>';
		echo '</div>';
	echo '</div>';

?>

<?php
    include '_footer.php';
   // echo debug::show();
?>

<script>

	body=$('body');
	
	body.on('click','.act-save-menu',function(){
		var menu='';
		var submenu='';
		$('.save-menu').children().each(function(){
			t=$(this);
			alert(t.text()+' '+t.attr('class'));
			if(t.hasClass('menu')){
				alert('Menu '+t.text());
			}
			if(t.hasClass('submenu')){
				alert('submenu '+t.text());
			}
			
			if(t.hasClass('sortit')){
				t.each(function(){
					alert('xxxx '+$(this).text());
				});
			}
					
			//	}else{
			//		//must be some data
			//	}
				
			//}
			
		});
		return false;
	});
	
	$( function() {

    $( ".sortit" ).sortable({
    	connectWith: ".sortit",
    	
    });
    $( ".leftpick" ).sortable({
connectWith: ".sortit",
      revert: true, helper: "clone" 

     });
	$( "ul, li" ).disableSelection();
  } );
  
	
	
$(document).keydown(function(e){
	console.log(e);
});

</script>
