<?php
    include '../admin/_top.php';?>
    
    <div class="row">
    	<div class="container">
    		<div class="col s12 targ-messages">
    			
    		</div>
    	</div>
    
    </div>





    <?php include '../admin/_footer.php';
?>

<script>
Pusher.logToConsole = true;

    var pusher = new Pusher('61d633d66b7d5a7c16c8', {
      encrypted: true
    });
    
    
	    var channel = pusher.subscribe('jserrors');
	    channel.bind('error', function(data) {
	      $('.targ-messages').append('<div class="col s12">'+data+'</div>');
	    });    	
	
	
	
</script>