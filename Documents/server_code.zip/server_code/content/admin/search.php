<?php
    include '_top.php'; 
    
	echo '<div class="row">';
		echo '<div class="container">';
		    echo '<div class="col s12">';
		        echo '<h2>Search</h2>';
	        
				echo '<div class="col s12 m8 offset-m2">';
					echo '<input placeholder="Enter search word or barcode here" style="text-align:center;" type="text" id="search" />';
				echo '</div>';
				echo '<div class="col s12 m12 searchres">';
				echo '</div>';
		     echo '</div>';
		echo '</div>';
	echo '</div>';
?>

<?php
    include '_footer.php';
   // echo debug::show();
?>
<script>

    $('body').on('keydown','#search',function(e){
        if(e.keyCode==13){
            runSearch();
            return false;
        }
        
    });


	
	function runSearch(){
		search=$('#search').val();
		search=search.toLowerCase();
    	data={};
	    data['search']=search;
		
		$('.searchres').load('_search.php',data);
	}



</script>

