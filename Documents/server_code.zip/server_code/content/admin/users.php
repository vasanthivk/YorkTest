<?php
    include '_top.php'; 
    
	echo '<div class="row">';
		echo '<div class="container">';
		    echo '<div class="col s12">';
		        echo '<h2>Search Users</h2>';
	        
				echo '<div class="col s12 m8 offset-m2">';
					echo '<input placeholder="Enter search name or email here" style="text-align:center;" type="text" id="usersearch" />';
				echo '</div>';
				echo '<div class="col s12 m8 offset-m2 searchres">';
				echo '</div>';
		     echo '</div>';
		echo '</div>';
	echo '</div>';

?>

<?php
    include '_footer.php';
   // echo debug::show();
?>
<script>

    $('body').on('keydown','#usersearch',function(e){
        if(e.keyCode==13){
            runSearch();
            return false;
        }
        
    });


	
	function runSearch(){
		search=$('#usersearch').val();
		search=search.toLowerCase();
    	data={};
	    data['search']=search;
		
		$('.searchres').load('_usersearch.php',data);
	}



</script>

