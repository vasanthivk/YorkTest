<?php
    include '_top.php'; 
    
	echo '<div class="row">';
		echo '<div class="container">';
			echo '<div class="col s12 m8 offset-m2">';
?>
	<h3>Skin Edit</h3>

<?php


	if(clean::post('title')!=''){
		
		$posts=clean::post();
		foreach($posts as $key=>$value){
			$fields[$key]=$value;
		}
		dbpdo::dbUpdate('skins',clean::get('ref'),$fields);
	}

	if(clean::get('ref')!=''){
		$row=ar::find('skins',clean::get('ref'));
	}else{
		$row=array('ref'=>-1);	
	}

	
   



        echo '<form action="?ref='.clean::get('ref').'" method="post">';
            echo '<input type="hidden" name="ref" value="'.h::sa($row,'ref').'" /><br/>';
            echo forms::field('title','Title',ar::get('title'));
            echo forms::field('color1','Colour 1',ar::get('color1'),'',6);
            echo forms::field('color2','Colour 2',ar::get('color2'),'',6);
            
            echo forms::field('logo','Logo (svg)',ar::get('logo'),'',12);

    		echo '<button type="submit" class="btn">Update</button>';
        echo '</form>';
        echo '<div id="qrcode">cmd:'.ar::get('title').'|'.ar::get('color1').'|'.ar::get('color2').'|'.ar::get('logo').'</div>';

        
        

    		echo '</div>';
		echo '</div>';
	echo '</div>';
?>

<?php
    include '_footer.php';
?>
<script>
	
new QRCode(document.getElementById("qrcode"), $('#qrcode').text());
</script>