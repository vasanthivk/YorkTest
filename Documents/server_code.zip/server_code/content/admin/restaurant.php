<?php
    include '_top.php'; 
    
	echo '<div class="row">';
		echo '<div class="container">';
		    echo '<div class="col s12">';
		        echo '<h2>Restaurant</h2>';
		        
		        echo 'Restraunt name,location and number of menus - What we are trying to get here is different menus for different locations';
		        
		        
		       echo '</div>'; 

		echo '</div>';
	echo '</div>';

?>

<?php
    include '_footer.php';
   // echo debug::show();
?>
