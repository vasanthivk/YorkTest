	        echo '<div class="col s12"><h5>Front of pack Traffic lighs</h5></div>';
	        
	        hint('fop.txt');
	        
	        
	        echo '<div class="col s4 m2">';
	            echo '<h6>Energy</h6>';
	            echo half('fop_energy_kj',$data,12); 
	            echo half('fop_energy_kcal',$data,12); 
	        echo '</div>';
	        
	        echo '<div class="col s4 m2">';
	            echo '<h6>Fat</h6>';
	            echo half('fop_fat_g',$data,12); 
	            echo half('fop_fat_perc',$data,12); 
	        echo '</div>';

	        echo '<div class="col s4 m2">';
	            echo '<h6>Saturates</h6>';
	            echo half('fop_saturates_g',$data,12); 
	            echo half('fop_saturates_perc',$data,12); 
	        echo '</div>';

	        echo '<div class="col s4 m2">';
	            echo '<h6>Sugars</h6>';
	            echo half('fop_sugars_g',$data,12); 
	            echo half('fop_sugars_perc',$data,12); 
	        echo '</div>';

	        echo '<div class="col s4 m2">';
	            echo '<h6>Salt</h6>';
	            echo half('fop_salt_g',$data,12); 
	            echo half('fop_salt_perc',$data,12); 
	        echo '</div>';
	        
	        
	       // echo halfx('setting_vals',$data,12);
