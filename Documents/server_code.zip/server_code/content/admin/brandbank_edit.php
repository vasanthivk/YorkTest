<?php
    include '_top.php'; 
?>

    <div class="row">
        <div class="contanier">
            <div class="col s12 m8">
                <h5>Product Edit</h5>
            </div>
            <div class="col s12 m4">
            </div>
        </div>




<?php

    include '_footer.php'; 

?>