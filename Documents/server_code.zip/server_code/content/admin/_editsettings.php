<?php
    echo '<h2>Edit</h2>';
    echo form::ajaxHash(clean::post('table'),clean::post('ref'));
	echo form::qfield('Name',clean::post('name'),12,'E');
	echo form::qfield('Exclude',clean::post('exclude'),12,'E');
    echo '<a href="#" class="btn act-save-data" data-table="'.clean::post('table').'" data-ref="'.clean::post('ref').'">Save</a>';

?>