<?php

    $barcode=clean::post('barcode_number');
    $fields=clean::post();
    
    $ingredients=clean::getStripped('ingredients');
    $fields['ingredients']=$ingredients;
    
    
    $fields['setting_vals']=getSettingVals($fields);
    
    
    
    $sql='select * from _productsx where barcode_number=:barcode limit 1';
    $parms=array(':barcode'=>$barcode);
    $data=dbpdo::getQuery($sql,$parms);
    
    if(sizeof($data)<2){
        echo '<h5>Add new</h5>';  
        dbpdo::dbInsert('_productsx',$fields,'',true,true);
    }else{
        echo '<h5>Update</h5>';  
        unset($fields['barcode_number']);
        print_r(clean::post());
        slack::message(print_r($fields,true),'#api');
        dbpdo::dbUpdate('_productsx',$barcode,$fields,'barcode_number');
        
    }
    
    if($barcode==''){
        
    }else{
        
    }

    //echo debug::show();
    
    
function getSettingVals($nutritionVals){
       $settingVals='';
       $cat=1;

          $settingVals .= $cat . ':1' . ',' . sprintf("%.2f", $nutritionVals['nutrition_numeric_calories']) .'|';
          $settingVals .= $cat . ':2' . ',' . sprintf("%.2f", $nutritionVals['nutrition_numeric_fat']) .'|';
          $settingVals .= $cat . ':3' . ',' . sprintf("%.2f", $nutritionVals['nutrition_numeric_cholesterol']) .'|';
          $settingVals .= $cat . ':4' . ',' . sprintf("%.2f", $nutritionVals['nutrition_numeric_sodium']) .'|';
          $settingVals .= $cat . ':5' . ',' . sprintf("%.2f", $nutritionVals['nutrition_numeric_sugar']) .'|';
          $settingVals .= $cat . ':6' . ',' . sprintf("%.2f", $nutritionVals['nutrition_numeric_fibre']);

       return $settingVals;
    }


?>