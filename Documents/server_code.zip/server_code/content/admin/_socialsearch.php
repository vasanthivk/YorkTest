<?php

	echo social::socialsearch(clean::post('search'));

?>