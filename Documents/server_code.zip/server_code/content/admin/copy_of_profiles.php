<?php
    include '_top.php'; 
    
	echo '<div class="row">';
		echo '<div class="container">';
        
?>
	<h3>Profiles List</h3>

<?php
   
            echo profile::listUsersTable();
        
        
        

		echo '</div>';
	echo '</div>';

?>

<?php
    include '_footer.php';
?>