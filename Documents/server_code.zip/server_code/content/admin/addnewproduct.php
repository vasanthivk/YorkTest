<?php
    include '_top.php'; 
    $data=array();
    
    
    $sql='select distinct customer from _productsx order by customer';
    $customers=array();
    
    if($stmt=dbpdo::query($sql)){
        while($row = $stmt->fetch()){
            $customers[]=$row['customer'];
        }
    }

    
?>


<?php
    
	echo '<div class="row">';
		echo '<div class="container">';
   			echo '<div class="col s12 m8 offset-m2">';
                echo '<h5>Create new product</h5>';
                echo hint('addnew.txt');
?>

	<?php
	

	        	echo half('barcode_number',$data,12);
	        	
	        	echo half('customer',$data,12);
	        	foreach($customers as $customer){
	        	    echo '<a href="#" class="customer-tag act-ctag">'.$customer.'</a>';
	        	}
	        	
	        	?>
	        </div>
	        <div class="col s12 m8 offset-m2 toolbar">

                <a href="#" class="btnol act-create-new">Create New Product<a/>

            </div>



        </div>
    </div>
</div>



<?php

	function hint($file){
		$txt=file_get_contents('../admin/hints/'.$file);
		if($txt!=''){
			echo '<div class="hint">';
				echo $txt;
			echo '</div>';
		}
	}


    function dynamicDrop($field){
        $sql='select distinct '.$field.'  from _productsx';
		if($stmt=dbpdo::query($sql)){
			while($row = $stmt->fetch()){
			    print_r($row);
			    echo '<br/>';
			}
		}
        
    }

    function halfx($field,$data,$cols=6,$value=''){
        $ret='<div class="col s12 m'.$cols.' fwrap">';
            $ret.='<label>'.$field.'</label>';
            if($value==''){
                $ret.=h::sa($data,$field);
            }else{
                $ret.=$value;
            }
        $ret.='</div>';
        return $ret;
    }
    
    function half($field,$data,$cols=6,$type='text',$value=''){
        $ret='<div class="col s12 m'.$cols.' fwrap">';
            $ret.='<label for="'.$field.'">'.$field.'</label>';
            if($value==''){
                
                $text=h::sa($data,$field);
            }else{
                $text=$value;
            }
            switch($type){
                case 'text':
                    $ret.='<input type="text" class="bbinput" id="'.$field.'" value="'.$text.'"/>';
                    break;
                case 'area':
                    echo '<textarea id="'.$field.'" class="bbinput materialize-textarea">'.$text.'</textarea>';
                    break;
                case 'html':
                    echo '<div class="bbinput editable" id="'.$field.'">'.$text.'</div>';
                    break;
            }
            
        $ret.='</div>';
        return $ret;
    }
    echo '<div class="result"></div>';

    




    include '_footer.php';
    
?>

<script>

    var body=$('body');
    

    body.on('click','.act-create-new',function(){
        barcode=$('#barcode_number').val();
        customer=$('#customer').val();
        if(barcode!='' && customer!=''){
            obb={};
            obb['barcode_number']=barcode;
            obb['customer']=customer;
            $('.result').load('../admin/_createnew.php',obb,function(){
            });
            
        }else{
            alert('Please enter a valid barcode and a customer.');    
        }
        return false;
    });
    
    body.on('click','.act-ctag',function(){
        $('#customer').val($(this).text());
        return false;
    });


</script>



