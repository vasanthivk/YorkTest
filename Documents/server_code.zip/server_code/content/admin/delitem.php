<?php



    $jwt=clean::get('jwt');
    
    $decode=JWT::decode($jwt);
    
    dbpdo::dbDelete('_productsx',$decode,'barcode_number');
?>