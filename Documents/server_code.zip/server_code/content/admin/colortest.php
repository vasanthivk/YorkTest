<?php
    include '_top.php'; 
    
	echo '<div class="row">';
		echo '<div class="container">';
			echo '<div class="col s12 m8 offset-m2">';
?>
	<h3>color</h3>
	
	
	<img class="targimg" src="../img/foodadvisr.svg" alt=""/>
	
	<div class="colors">
		
		
	</div>
	

   




        

		</div>
	</div>
</div>

<?php
    include '_footer.php';
?>
<script>


var img = document.createElement('img');
img.setAttribute('src', '../img/foodadvisr.svg')
colors=$('.colors');
var html='';
img.addEventListener('load', function() {
    var vibrant = new Vibrant(img);
    var swatches = vibrant.swatches()
    for (var swatch in swatches)
        if (swatches.hasOwnProperty(swatch) && swatches[swatch])
        	//var hex=swatches[swatch].getHex();
            console.log(swatch, swatches[swatch].getHex());
            html+='<div class="swatch" style="background:#'+swatches[swatch].getHex()+'"></div>';
            alert(html);
});
$('.colors').html(html);
</script>