<?php
	if(clean::post('pass')!=clean::post('checkpass')){
		echo 'Passwords do not match';	
	}else{
		$fields=array('password'=>password_hash(clean::post('pass'), PASSWORD_DEFAULT),
		'resethash'=>bin2hex(openssl_random_pseudo_bytes(60)));
		dbpdo::dbUpdate('appusers',clean::post('hash'),$fields,'resethash');
		echo 'Password has been updated';
	}
?>