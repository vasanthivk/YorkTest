<?php
	include_once('_autoload.php');
    debug::logErrors();
	@session_start();
	$_SESSION['LAST_ACTIVITY'] = time(); // update last activity time stamp
	debug::startTime();
	clean::setprepend();
	clean::cleanInput();
	unset($_POST);
	unset($_GET);



	if(!loginsimple::inPathList(array('admin'))){
	}else{
		if(loginsimple::isLoggedIn()){
		    debug::add('LOGGED IN');
		}else{
		    debug::add('NOT LOGGED IN');
		    if(loginsimple::inFileList(array('login','resetpassword','m'))){
		    }else{
		        if(!loginsimple::inPathList(array('onboard','m','slack','s','menu','track'))){
    		        secure::redirect('../adminlogin/login.php');
		        }
		    }
		}
	}

?>
