<?php
    include '_top.php'; 
    $email=strtolower(clean::get('email'));
    $hash=clean::get('hash');
    $sql='select * from appusers where email=:email limit 1';
    $parms=array('email'=>$email);
    if($data=dbpdo::getQuery($sql,$parms)){
        if(strtolower($data['email'])==$email && $data['resethash']==$hash){
            
        } else{
            die('Invalid password reset request.');
        }       
    }else{
            die('Invalid password reset request');
    }
?>

<style>

	img{
		margin-top:100px;
	}

	label{
		display:block;
		font-size:0.9rem;
		margin-top:10px;
		margin-bottom:10px;
		color:#707070;
	}
	
	p{
		margin-bottom:30px;
	}

	input{
		width:100%;
		line-height:1.2rem;
		font-size:1.0rem;
		border:1px solid #d0d0d0;
		color:#707070;
		border-radius:4px;
		padding:1%;
		margin-bottom:20px;
	}
	
	.btn-reset{
		display:inline-block;
		padding:5px 10px;
		background:#00B2A9;
		color:white;
		margin-top:20px;
		border-radius:4px;
	}
	
	
</style>
    

<div class="row">
    <div class="container">
        <div class="col s12 m6 offset-m3">
        	<img class="responsive-img" src="foodadvisr.svg" alt="foodadvisr logo"/>
        	<p>
        		Please Enter your new password into both boxes then press the Reset Password button
        	</p>
            <label>New password</label>
            <input type="text" id="newpass" placeholder="Enter new password"/>
             <label>Repeat new password</label>
            <input type="text" id="newpasscheck" placeholder="repeat new password"/>
            <a href="" class="act-reset btn-reset" data-hash="<?php echo $hash;?>">Reset Password</a>
            <div id="test"></div>
        </div>
    </div>
</div>






<?php
    include '_footer.php';
?>