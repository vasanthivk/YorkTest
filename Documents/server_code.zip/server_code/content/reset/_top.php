<?php debug::logErrors();?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="hash" content="<?php echo form::buildHash();?>"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>FoodAdvisr</title>

    <!-- CSS  -->
    <link href="materialize.min.css" type="text/css" rel="stylesheet"/>
    



</head>
<body>

