

  <!--  Scripts-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.3/jquery.min.js"></script>
    
    
    <script>
    	
    	$('body').on('click','.act-reset',function(){
    		t=$(this);
    		obb={};
    		obb['hash']=t.data('hash');
    		obb['pass']=$('#newpass').val();
    		obb['checkpass']=$('#newpasscheck').val();
    		$('#test').load('_reset.php',obb,function(){
    		});
    		return false;
    	});
    	
    	
    </script>
    
    
  </body>
</html>
