<?php

require_once '/var/www/html/cxx/workspace/quicr/lib/productimport.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/productimportutil.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/productimage.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/productingredients.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/dbpdo.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/debug.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/settings.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/h.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/log.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/s3util.class.php';

$sql = 'SELECT * FROM _products_import2 WHERE image <> :yes LIMIT 10000';
$params =[':yes' => 'yes'];

// $sql = 'SELECT * FROM _products_import2 WHERE barcode_number = :barcode';
// $params =[':barcode' => '5060379650119'];

	if ($stmt=dbpdo::query($sql, $params)) {

		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			$url = productimage::IMG_BASEURL . $row['image_ref'];
			$imageFilename = productimage::hashBarcode($row['barcode_number']) . '.jpg';
    		$responseCode = productimage::getHttpResponseCode($url);
    		
    			if($responseCode==200){
    				echo 'Image available on Brandbank' . "\n";
    				if(productimage::imageDownloadedToS3($imageFilename, productimage::IMG_BUCKET)==false){
    		//			echo "Image not downloaded to s3 .. Downloading image .. \n";
    					productimage::downloadImageToS3( $row['image_ref'], $imageFilename, $row['barcode_number']);
	    			}else{
	    	//			echo "Image " . $imageFilename . " downloaded to s3 .. flagging in the database..\n";
	    				productimage::saveImageFlag($row['barcode_number'],'Yes');
	    			}
    			}else{
    //				echo "Image not available from Brandbank\n";
    			}

		}
	}