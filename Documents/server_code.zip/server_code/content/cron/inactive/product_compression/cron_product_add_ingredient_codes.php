<?php
require_once '/var/www/html/cxx/workspace/quicr/lib/dbpdo.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/debug.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/settings.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/h.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/log.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/productcompression.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/productimportutil.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/slack.class.php';


productcompression::addCodesToProductTable();
