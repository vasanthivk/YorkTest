#!/bin/bash 

/usr/bin/find "/var/www/html/cxx/workspace/quicr/content/xml" -name "*.xml" -mtime +5 -delete

