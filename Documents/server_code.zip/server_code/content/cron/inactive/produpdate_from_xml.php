<?php
require_once '/var/www/html/cxx/workspace/quicr/lib/productimport.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/productimportutil.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/productimage.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/productingredients.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/dbpdo.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/debug.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/settings.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/h.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/log.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/s3util.class.php';

$downloadPath = '/var/www/html/cxx/workspace/quicr/content/xml/';

$dir = new DirectoryIterator($downloadPath);

$file = getFirstFile($dir);
$filepath = $downloadPath . $file->getFilename();
    	
  if($filepath != null){
	 	// 3. Import products
	 	productimport::import($filepath);
			    
	// 	// 4. Download images
	 	productimage::downloadProductImages($filepath, '.jpg');
			
	// 	// 5. Store ingredients
	 	productingredients::splitOutAndStoreProductIngredients($filepath);
	
		// Move xml file
		rename($filepath, '/var/www/html/cxx/workspace/quicr/content/xml_processed/'.$file->getFilename());
	
	 }
	

function getFirstFile($dir){
	$file = null;
	foreach ($dir as $fileinfo) {
		 if (!$dir->isDot() & $dir->isFile() ) {
		 	$file = $dir;
		 	break;
		 }
	}
	return $file;
}