<?php
require_once '/var/www/html/cxx/workspace/quicr/lib/productxml.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/dbpdo.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/debug.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/settings.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/h.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/log.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/s3util.class.php';

productxml::archive();	
//echo (productxml::generateS3SignedUri('2017-06-03 18:38:09.xml')) . "\n";