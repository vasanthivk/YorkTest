<?php
require_once '/var/www/html/cxx/workspace/quicr/lib/soap.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/productimport.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/productimportutil.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/productimage.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/productingredients.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/dbpdo.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/debug.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/settings.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/h.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/log.class.php';
require_once '/var/www/html/cxx/workspace/quicr/lib/s3util.class.php';


// 1. Get Content

$productRequestXMLPath = '/var/www/html/cxx/workspace/quicr/content/soap/request_get_unsent_product_data.xml';
$content=soap::doXMLCurl('https://api.brandbank.com/svc/feed/extractdata.asmx?op=GetUnsentProductData',file_get_contents($productRequestXMLPath));

// 2. Download it

$filename = 'productdata_' . date("Y-m-d H:i:s") . '.xml';
$downloadPath = '/var/www/html/cxx/workspace/quicr/content/xml/';
$filepath = productimportutil::downloadFile($downloadPath, $content, $filename);

// $filepath='/var/www/html/cxx/workspace/quicr/content/xml/productdata_2017-03-22 09:00:28.xml';  //TEST

if($filepath != null){
	// 3. Import products
	productimport::import($filepath);
	    
	// 4. Download images
	productimage::downloadProductImages($filepath, '.jpg');
	
	// 5. Store ingredients
	productingredients::splitOutAndStoreProductIngredients($filepath);
	
	// 6. Acknowledge Batch
	$xmlFilepath = '/var/www/html/cxx/workspace/quicr/content/soap/request_acknowledge.xml';
	$lastMessageId = productimport::getAcknowledgementId($filepath);
	productimport::sendBrandbankAcknoledgement($lastMessageId, $xmlFilepath);
}