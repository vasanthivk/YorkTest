<?php

	print_r(clean::post());
	
	$fields=array('response'=>clean::post('txt'),
	'resptime'=>dbpdo::now());
	dbpdo::dbUpdate('feedback',clean::post('ref'),$fields);

?>