<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>Quicr</title>
  
  <?php
  include 'dlmenu.php';
  ?>




</head>
<body>
	
	

  <!--  Scripts-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.3/jquery.min.js"></script>
    <script>
    	
    	$('body').on('click','.qsr-menu h3',function(){
    		$(this).next().next().toggle();
    		return false;
    	});
    	
 		$('body').on('click','.mnu-sub-item',function(){
 			t=$(this);
 			
 			parentRef=t.data('subref');
 			p=$('.mnu-ref-'+parentRef);
 			
    		$(this).toggleClass('selected');
    		
    		baseCalories=p.data('calories');
    		addedCalories=0;
    		console.log('Base '+baseCalories);
    		$('.mnu-sub-ref-'+parentRef).each(function(){
    			tt=$(this);
    			if(tt.hasClass('selected')){
    				console.log('found');
    				addedCalories+=parseInt(tt.data('calories'));
    			}
    		});
    		console.log('added calories='+addedCalories);
    		p.find('.mnu-targ-cal').text(baseCalories+addedCalories);
    		
    		
    		
    		
    		return false;
    	});
    	
    	
    </script>
  </body>
</html>

