<?php debug::logErrors();?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="hash" content="<?php echo form::buildHash();?>"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>Quicr</title>

    <!-- CSS  -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link href="../css/materialize.min.css" type="text/css" rel="stylesheet"/>
    

    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link href="../css/style.css?v0.1" type="text/css" rel="stylesheet"/>
    
    <style>
    	
    	.edpop{
    		position:absolute;
    		top:50px;
    		left:50%;
    		width:400px;
    		margin-left:-200px;
    		min-height:400px;
    		z-index:100;
    		background:white;
    		box-shadow:0px 0px 5px rgba(0,0,0,0.3);
    		padding:1%;
    		font-size:0.9rem;
    		
    	}
    	
    	label{
    		display:block;
    		font-size:0.9rem;
    		color:#606060
    		;
    	}
    	
    	.orgtext{
    		width:98%;
    		padding:1%;
    		border:1px solid #d0d0d0;
    		border-radius:3px;
    		margin-bottom:10px;
    	}
    	
    	textarea{
     		width:98%;
    		padding:1%;
    		border:1px solid #d0d0d0;
    		border-radius:3px;
    		margin-bottom:10px;
    		height:200px;
    		
   	
    	}
    	
    	.edbutton{
    		display:inline-block;
    		padding:3px 9px;
    		border:1px solid #707070;
    		color:#707070;
    		border-radius:3px;
    	}
    	
    	
    	
    </style>



</head>
<body>
	<div class="edpop hide">
		<h4>Edit response</h4>
		<label>Feedback</label>
		<div class="orgtext"></div>
		<label>Response</label>
		<textarea></textarea>
		<a href="#" class="edbutton act-update-response">Update</a>
		<a href="#" class="edbutton act-cancel">Cancel</a>
	</div>
	<div class="row">
			<div class="container">
	<table class="striped" style="font-size:0.9rem;">
		<thead>
			<tr>
				<td>Ref</td>
				<td>Email</td>
				<td>Feedback</td>
				<td>Date</td>
				<td>Response</td>
				<td>Resp Date</td>
				<td>Device</td>
				<td>Version</td>
			</tr>
		</thead>
		<tbody>
	<?php
		
		
		$sql='select * from feedback order by msgdate desc';
		if($stmt=dbpdo::query($sql)){
			while($row = $stmt->fetch()){
				echo '<tr>';
					echo '<td>'.$row['ref'].'</td>';
					echo '<td>'.$row['email'].'</td>';
					echo '<td>'.$row['message'].'</td>';
					echo '<td>'.$row['msgdate'].'</td>';
					if($row['response']==''){
						$resp='Add response';
					}else{
						$resp=$row['response'];
					}
					echo '<td><a href="#'.$row['ref'].'" class="act-edit-response">'.$resp.'</a></td>';
					echo '<td>'.$row['resptime'].'</td>';
					echo '<td>'.$row['device'].'</td>';
					echo '<td>'.$row['version'].'</td>';
				echo '</tr>';
			}
		}

	
	
	
	?>
	</tbody>
	</table>
	</div>
</div>
		
<?php



?>
	
	

  <!--  Scripts-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.1/js/materialize.min.js"></script>
    <script>
    	
    	$('body').on('click','.act-edit-response',function(){
    		$('.markedupdate').removeClass('markedupdate');
    		t=$(this);
    		offs=t.offset();
    		topp=offs.top;
    		
    		t.addClass('markedupdate');
    		ref=t.attr('href').substr(1);
    		p=t.parent().prev().prev();
    		op=$('.edpop');
    		op.css({top:topp});
    		op.removeClass('hide');
    		op.find('.orgtext').text(p.text());
    		if(t.text()=='Add response'){
    			ntxt='';
    		}else{
    			ntxt=t.text();
    		}
    		op.find('textarea').val(ntxt).data('ref',ref).focus();
    		return false;
    	});
    	
    	$('body').on('click','.act-update-response',function(){
    		t=$(this);
    		t.text('Saving update..');
    		op=$('.edpop');
    		txt=op.find('textarea');
    		obb={};
    		obb['txt']=txt.val();
    		obb['ref']=txt.data('ref');
    		mu=$('.markedupdate');
    		mu.text(obb['txt']);
    		mu.parent().next().text('Updated');
    		
    		$.post('saveresponse.php',obb,function(data){
    			$('.act-update-response').text('Update');
    			$('.edpop').addClass('hide');	
    		});
    		return false;
    	});
    	
    	$('body').on('click','.act-cancel',function(){
    		$('.edpop').addClass('hide');
    		return false;
    	});
    	
    	
    	
    </script>
  </body>
</html>
