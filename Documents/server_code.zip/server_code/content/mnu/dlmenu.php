
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">

<style>




	.qsr-menu{
		position:relative;
		font-family: Tahoma, Geneva, sans-serif;
		font-size:1.0rem;
		padding:3%;
		padding-top:50px;
		background:rgba(255,255,255,0.5);
		
	}
	
	.qsr-menu small{
		font-size:0.8rem;
		display:inline-block;
		margin-left:20px;
	}
	

	.qsr-menu h3,.qsr-menu h4,.qsr-menu h5,.qsr-menu h6{
		margin:0px !important;
		padding:0px !important;
		font-family: 'Open Sans', sans-serif !important;
		font-weight:200;
		
	}
	
	.qsr-menu h3,.qsr-menu h4,.qsr-menu h5{
		color:#8fa240 !important;
	}
	
	.qsr-menu h3{
		position:relative;
		text-align:center;
		font-size:3.0rem;
		margin-top:20px !important;
		margin-bottom:5px !important;

	}
	
	.qsr-menu h4{
		text-align:center;
		font-size:1.8rem;
		margin-top:25px !important;
		margin-bottom:20px !important;
		
	}
	
	.qsr-menu h5{
		text-align:center;
		font-size:1.1rem;
		
		
	}


	
	
	
	
	.qsr-menu h6{
		text-align:center;
		font-size:0.9rem;
		color:#808080;
		
		
	}
	
.mw{
  display:inline-block;
  font-size:0.7rem;
  color:#909090;
  margin-left:20px;
  margin-top:-10px;

}

	
	.mnu-600{
		display:inline-block;
		font-size:0.7rem;
		line-height:0.8rem;
		color:#8fa240;
		padding:0px 4px !important;
		border:1px solid #8fa240;
		border-radius:3px;
		margin-left:5px;
		margin-right:5px;
	}
	
	.mnu-vegan{
		display:inline-block;
		font-size:0.7rem;
		line-height:0.8rem;
		color:#ffffff;
		padding:0px 4px !important;
		border:1px solid #8fa240;
		margin-left:5px;
		background:#8fa240;

		
	}

	.mnu-veg{
		display:inline-block;
		color:#8fa240;
		font-size:1.0rem;
		margin-left:5px;
		margin-right:5px;
	}

	
	.mnu-item{
		overflow:hidden;
		margin-top:10px;
	}
	
	.mnu-left{
		display:inline-block;
		width:80%;
		font-size:1.2rem;
	}
	
	.mnu-left p{
		padding:0px;
		margin:0px;
		color:#606060;
		font-weight:normal;
		font-size:0.9rem;
		margin-bottom:5px;
		text-align:left;
	}
	
	.mnu-left b,.mnu-sub-ite b{
		font-size:0.8rem;
		font-weight:bold;
	}
	
	.mnu-right{
		width:19%;
		display:inline-block;
		vertical-align:top;
		text-align:right;
	}
	
	.toggle{
		float:right;
	}
	
	.mnu-section{
		display:none;
		margin-top:20px;
		margin-bottom:30px;
		overflow:hidden;
	}
	
	.mnu-section.active{
		display:block;
	}
	
	.mnu-subtext{
		font-size:0.9rem;
		color:#8fa240;
	}
	
	.mnu-sub-item{
		line-height:1.8rem;
			border-left:6px solid #ffffff;
		margin-bottom:5px;
	}
	
	.mnu-sub-item.selected{
		background:#8fa240;	
		color:white;
		border-radius:20px;
	}
	
	.mnu-section-count{
		position:absolute;
		top:0px;
		left:50px;
		width:20px;
		height:20px;
		background:#303030;
		color:white;
		font-size:0.8rem;
		text-align:center;
		border-radius:50%;
		line-height:20px;
	}

	
</style>
<div class="qsr-menu">
	<a href="#" class="btn-create-new act-import-menu">Compare</a>
<?php


    $sql='SELECT menu.menu,menu.submenu, menu.description, menu_products.sort_order,menu_products.product_no,menu_products.sub_product_no,_productsdl.*
    FROM menu_products
    inner join menu on (menu.ref=menu_products.menu_ref)
    inner join _productsdl on (menu_products.barcode_number=_productsdl.barcode_number)
    order by menu_products.sort_order asc';
    $first=true;
    $firstItem=true;
    $menu='';
    $submenu='';
    echo '<div>';
    if($stmt=dbpdo::query($sql)){
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        	if($first){
            	//print_r($row);
            $first=false;
        	}
        	if($menu!=$row['menu']){
        		//if(!$firstItem){
        			echo '</div>'.PHP_EOL;
        			$firstItem=false;
        		//}
        		//echo '<h3><div class="mnu-section-count">0</div>'.$row['menu'].'</h3>';
        		echo '<h3>'.$row['menu'].'</h3>';
        		echo '<h6>'.$row['description'].'</h6>';
        		echo '<div class="mnu-section">'.PHP_EOL;
        		$menu=$row['menu'];
        	}
        	if($submenu!=$row['submenu']){
        		echo '<h4>'.$row['submenu'].'</h4>';
        		$submenu=$row['submenu'];
        		
        	}
        	
        	$dd=explode(':',$row['product_title']);
			if($row['sub_product_no']==0){
				echo '<div class="mnu-item  mnu-ref-'.$row['product_no'].'" 
					data-contains="'.$row['allergy_contains'].'" 
					data-may="'.$row['allergy_may'].'" 
					data-ref="'.$row['product_no'].'" 
					data-calories="'.$row['nutrition_numeric_energykcal'].'">';
					echo '<div class="mnu-left act-mnu-clicked">';
		            	echo '<span class="mnu-item-title">'.$dd[0].'</span>';
		            	if($row['vegetarian']=='vegetarian' or $row['vegetarian']=='vegan'){
		            		echo '<span class="mnu-veg">V</span>';
		            	}
		            	
		            	if($row['vegetarian']=='vegan'){
		            		echo '<span class="mnu-vegan">VEGAN</span>';
		            	}
		            	
						if($row['gluten_free']=='Yes'){
		            		echo '<span class="mnu-veg">NG</span>';
		            	}		            	
		            	echo '<p class="mnu-item-desc">'.h::sa($dd,1).'</p>';
		            	echo '<b><span class="mnu-targ-cal">'.$row['nutrition_numeric_energykcal'].'</span> kcal</b>';
		            	if($row['nutrition_numeric_energykcal']<600){
		            		echo '<span class="mnu-600">600</span>';
		            	}
            		echo '</div>';
            		echo '<div class="mnu-right">';
            			echo '<div class="toggle mnu-toggle"><div class="toggle-handle"></div></div>';
            			
            		echo '</div>';
            		echo '<div class="mnu-subtext">'.$row['subtext'].'</div>';
            		echo '<div class="mw">'.$row['allergy_contains'].' '.$row['allergy_may'].'</div>';
            	echo '</div>';
			}else{
				echo '<div class="mnu-sub-item mnu-sub-ref-'.$row['sub_product_no'].'" 
					data-calories="'.$row['nutrition_numeric_energykcal'].'" 
					data-contains="'.$row['allergy_contains'].'" 
					data-may="'.$row['allergy_may'].'" 
					data-subref="'.$row['sub_product_no'].'">';
				echo '<small>'.$dd[0].' <b>'.$row['nutrition_numeric_energykcal'].' kcal</b></small>';	
		            	if($row['nutrition_numeric_energykcal']<600){
		            		echo '<span class="mnu-600">600</span>';
		            		
		            	}
		            	echo '<div class="mw">'.$row['allergy_contains'].' '.$row['allergy_may'].'</div>';
		        echo '</div>';
		          //echo '<br/>';

			}
			echo PHP_EOL;
        }
    }
    echo '</div>';





?>
</div>
