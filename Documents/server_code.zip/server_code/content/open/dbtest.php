<?php
    include '_top.php'; 
    ?>
    
    <div class="container">
    	<div class="row">
    		<?php
    
    			$sql='select * from _products limit 1';		
    			$data=dbpdo::getQuery($sql);
    			print_r($data);
    			
    		
    		
    		?>
    	</div>
    </div>






<?php
    include '_footer.php';
?>

