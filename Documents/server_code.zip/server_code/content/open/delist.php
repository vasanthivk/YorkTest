
<?php


	file_put_contents('temp.txt',clean::post('ing'));
	
	$opArr=file('temp.txt');
	echo '<br/>';
	foreach($opArr as $item){
		echo strtolower(trim($item)).',';
	}


echo '<form method="post">';
	echo '<textarea name="ing" style="width:400px;height:400px;">';
	echo clean::post('ing');
	echo '</textarea>';
	echo '<button tyle="submit">Submit</button>';
echo '</form>';









?>


