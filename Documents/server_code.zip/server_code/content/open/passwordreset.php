<?php
    include '_top.php'; 
    $email=clean::get('email');
    $hash=clean::get('hash');
    $sql='select * from appusers where email=:email and resethash=:hash limit 1';
    $parms=array('email'=>$email,':hash'=>$hash);
    $data=dbpdo::getQuery($sql,$parms);
    if(dbpdo::lastRows()==1){
        if($data['email']==$email && $data['resethash']==$hash){
            echo 'Ok to reset';
        } else{
            echo 'Invalid password reset request.';
            die();
        }       
    }else{
            echo 'Invalid password reset request.';
            die();
        
    }
?>
    

<div class="row">
    <div class="container">
        <div class="col s12 m6 offset-m3">
            <label>New password</label>
            <input type="text" id="newpass"/>
             <label>Repeat new password</label>
            <input type="text" id="newpasscheck"/>
            <a href="">Reset Password</a>
        </div>
    </div>
</div>






<?php
    include '_footer.php';
?>