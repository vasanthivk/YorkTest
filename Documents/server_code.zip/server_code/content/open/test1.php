<?php


$p1=products::getBarcode('5010251595489');
echo $p1.'<br/>';
echo strlen($p1).'<br/>';

$p2= products::getBarcode('5010251595489',true);
echo $p2.'<br/>';
echo strlen($p2);


?>