<?php
    include '_top.php'; 
    
	echo '<div class="row">';
	
			echo '<div class="col s12 m8 offset-m2">';
				echo '<input placeholder="Enter search word here" style="text-align:center;" type="text" id="search" />';
			echo '</div>';
			?>
				<div class="col s12 center-align act-filters filters">
					<a href="#">Tesco</a> 
					<a href="#">Waitrose</a> 
					<a href="#">Sainsbury</a>
					<a href="#">Co-operative</a> 
					<a href="#">Morrisons</a> 
					<a href="#">Sharwood</a>
					<a href="#">Thai</a>
					<a href="#">Chinese</a>
					<a href="#">Indian</a>
					<a href="#">Risotto</a>
					<a href="#">Curry</a>
					<a href="#">Chicken</a>
					<a href="#">Beef</a>
					<a href="#">Pork</a>
					
					
					
					
					<a href="#">Clear</a> 
				</div>
			
			
			<?
	
	
	
   			echo '<div class="col s12 m12">';
     
?>
    <div class="container">
	<h3>New Products List
	    
	</h3>
	<div class="row">
	    <div class="col s12 right-align">
	    <a href="#qrcode" class="act-toggle btn-switch">Database Switch</a> 
	    <a href="#barcodes" class="act-toggle btn-switch selected">Barcodes</a>
	    </div>
	</div>
	<div class="row targ-toggles hide1" id="qrcode">
	    <div class="col s12 m2 offset-m5">
	        <img class="responsive-img" src="../img/bbtoggle.jpg"/>
	    </div>
	
	</div>
	
	<div class="row targ-toggles" id="barcodes">
	
	<?php
	
	    //echo view2::viewData('_products');
	    $sql='select * from _products order by product_title desc limit 200';
	    $parms=array();
	    $top=true;
	    $zebra='';
	    $ret='';
	    if($stmt=dbpdo::query($sql,$parms)){
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			    $ret.='<div class="col s12 m3 oneitem">';
			        if($row['product_title']!=''){
			            $ret.='<div class="col s12 prodtitle">';
    			        $ret.='<h6>'.$row['product_title'].'</h6>';
    			        $ret.='</div>';
    			        $ret.='<div style="margin-bottom:40px; !important" class="barcode col s12 m8 offset-m2  center-align">'.$row['barcode_number'].'</div>';
			            
			        }
			        //$ret.='<div class="col s12 m8 offset-m2  center-align">';
			        //$ret.='<img class="responsive-img" style="margin-left:auto;margin-right:auto;"  src="../productimages/'.$row['barcode_number'].'.jpg"/>';
			        //$ret.='</div>';
			        //$ret.=print_r($row,true);
			    $ret.='</div>';
			}
	    }
	    

	    echo $ret;

	
	?>
	</div>
	</div>




        </div>
</div>

<?php





    function title($name){
        return str_replace('_',' ',$name);
    }

    include '_footer.php';
?>

<script>
  var settings = {
          output:"bmp",
          barWidth: 2,
          barHeight: 50
        };

    $('.barcode').each(function(){
        t=$(this);
        xx=t.html();
        var code='';
        t.html('<b>'+xx+'</b>');
        switch(xx.length){
        	case 13:
        		code="ean13";
        	
        		break;
        	case 8:
        		code="ean8"
        		break;
        	default:
        		alert(xx.length);
        		code="ean13";
        		break;
        }
        t.barcode(t.text(),code,settings);

    });
  
    


	var body=$('body');
	
	body.on('click','.act-toggle',function(){
	    t=$(this);
	    $('.act-toggle').removeClass('selected');
	    t.addClass('selected');
	    $('.targ-toggles').addClass('hide1');
	    g=t.attr('href');
	    $(g).removeClass('hide1');
	    return false;
	});
	
	body.on('click','.act-filters a',function(){
		t=$(this);
		filter=t.text();
		if(filter=='Clear'){
			filter='';
		}
		$('#search').val(filter);
		runSearch(t);
		return false;
	});


    $('body').on('keydown','#search',function(e){
        if(e.keyCode==13){
            runSearch();
            return false;
        }
        
    });

	$('body').on('click','.act-search',function(){
		//alert($('#search').val());
		return false;
	});
	
	
	function runSearch(tt){
		search=$('#search').val();
		search=search.toLowerCase();
		cc=0;
		$('.oneitem').each(function(){
		    t=$(this);
		    row=t.text();
		    row=row.toLowerCase();
		    if(row.search(search)!=-1){
		        //t.show();
		        t.removeClass('slot');
		        cc++;
		    }else{
		        t.addClass('slot');
		    }
		    
		});
		if(tt!==undefined){
		    //tt.append('<div class="searchcount">'+cc+'</div>');
		}
	    
	}



</script>


