<?php



print_r(doXMLCurl('https://api.brandbank.com/svc/feed/extractdata.asmx?op=GetUnsentProductData',file_get_contents('../soap/request_get_unsent_product_data.xml')));


function doXMLCurl($url,$postXML){
    $CURL = curl_init();

    curl_setopt($CURL, CURLOPT_URL, $url); 
    curl_setopt($CURL, CURLOPT_HTTPAUTH, CURLAUTH_BASIC); 
    curl_setopt($CURL, CURLOPT_POST, 1); 
    curl_setopt($CURL, CURLOPT_POSTFIELDS, $postXML); 
    curl_setopt($CURL, CURLOPT_HEADER, false); 
    curl_setopt($CURL, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($CURL, CURLOPT_HTTPHEADER, array('Accept: text/xml','Content-Type: text/xml'));
    curl_setopt($CURL, CURLOPT_RETURNTRANSFER, true);
    $xmlResponse = curl_exec($CURL); 

    return $xmlResponse;
}





?>