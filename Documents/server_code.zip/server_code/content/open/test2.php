<?php



	$sql='select count(*) as cc,name,length(name) as ln from _product_ingredients group by name order by ln desc limit 1000';
	    if($stmt=dbpdo::query($sql)){
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				print_r($row);
				echo '<br/>';
			}
	    }
	    
	    
	    echo debug::show();
	    


?>