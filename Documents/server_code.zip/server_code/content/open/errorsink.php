<?php
$options = array(
    'encrypted' => true
  );
  $pusher = new Pusher(
    '61d633d66b7d5a7c16c8',
    'e503f4acedad98e5457d',
    '308724',
    $options
  );

  $message=clean::post('message').' - '.clean::post('lineno').' - '.clean::post('url');
  $pusher->trigger('jserrors', 'error', $message);




	
?>
