<?php


    $d=nl2br(file_get_contents('terms.html'));
    file_put_contents('terms1.html',$d);


?>