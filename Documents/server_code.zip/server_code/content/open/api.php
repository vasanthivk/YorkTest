<?php



	$sql='select ref,handle,barcode,comments,sharedate from sharing where groups like :group and status=:status order by sharedate desc limit 20';
	$parms=array(':group'=>'%'.clean::get('group').'%',':status'=>'Approve');
	if($stmt=dbpdo::query($sql,$parms)){
   		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
	}
	//print_r($result);
	foreach($result as $key=>$item){
		//echo $key.' '.$item['barcode'].'<br/>';
		$result[$key]['imghash']=getImgHash($item['barcode']);
	}
	
	echo json_encode($result);
	
	
	
	function getImgHash($barcode){
		return md5($barcode.'.xfa8flP4K03LsT3jeya3O38FCMaE3p');
	}



?>