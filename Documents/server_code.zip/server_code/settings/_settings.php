<?php 
$global_settings=array(
	
    'project'=>array(
        'imageurl'=>'imgupload',    
        'url'=>'https://code.clevertech.tv/cxx/workspace/quicr/content/',
         'resetpath'=>'http://52.56.130.182/cxx/workspace/quicr/content/reset/passwordreset.php'

    ), //project
  
	'database'=>array(
		'hostname'=>'quicrdev.c0wlb9oxesna.eu-west-2.rds.amazonaws.com',
		'username'=>'qucirdev',
		'password'=>'wooshmanwooshman',
		'dbname'=>'quicrdev'
	
	),//database
	
	'login'=>array(
	    'table'=>'person',
	    'user'=>'user',
	    'cost'=>array('cost'=>12),
	    
	    
	),//Login
	'slack'=>array(
	    'appname'=>'Quicr',
	    'key'=>'xoxp-2642909711-2642909713-47636594982-425ed9fc67',
	    'slash-ct'=>'uiVORQlJxX2tex7Oonf9nUDK'
	),//slack
	'pusher'=>array(
	    'appid'=>'215652',
	    'key'=>'5ea56d66f61c74d65aa5',
	    'secret'=>'9b3acdc9449fb2478c63'
	),//pusher
	'amazons3'=>array(
	    'accesskey'=>'AKIAIBIKVR6RZS23GBAQ',
	    'Secretkey'=>'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',
	),//s3
	
	'amazonSES'=>array(
	    'accesskey'=>'AKIAJ3J4VI2IZHONYBKA',
	    'Secretkey'=>'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',
	),//s3
	
	

	
	
	
	
	



	
	'brandbank'=>array(
	    'dev_guid'=>'6135D1A0-F3F6-4498-88EF-02B22F650784',
	    'live_guid'=>'464AF7FE-D8ED-44E8-8927-BC1E9C1BE38C',
		'image_name_secret'=>'xfa8flP4K03LsT3jeya3O38FCMaE3p'
	 ),
	'JWT'=>array(
	    'key'=>'dmWcv5cv8CcfK2xkBEEN7GrkMu52hYY6T8HEdMr747xPTDSYBy',

	    
	 ),
	'hash'=>array(
	    'key'=>'x66y3k7UaU39E10K39sSG06yf024h2gj830p432i090339s1nr',

	    
	 ),


	 

	




)//outer array
?>